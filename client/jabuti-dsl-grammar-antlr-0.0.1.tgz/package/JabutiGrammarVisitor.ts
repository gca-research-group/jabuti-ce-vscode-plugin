// Generated from ./JabutiGrammar.g4 by ANTLR 4.9.0-SNAPSHOT


import { ParseTreeVisitor } from "antlr4ts/tree/ParseTreeVisitor";

import { ContractContext } from "./JabutiGrammarParser";
import { VariablesContext } from "./JabutiGrammarParser";
import { VariableStatementContext } from "./JabutiGrammarParser";
import { DatesContext } from "./JabutiGrammarParser";
import { PartiesContext } from "./JabutiGrammarParser";
import { ClausesContext } from "./JabutiGrammarParser";
import { BeginDateContext } from "./JabutiGrammarParser";
import { DueDateContext } from "./JabutiGrammarParser";
import { ApplicationContext } from "./JabutiGrammarParser";
import { ProcessContext } from "./JabutiGrammarParser";
import { ClauseContext } from "./JabutiGrammarParser";
import { RolePlayerContext } from "./JabutiGrammarParser";
import { OperationContext } from "./JabutiGrammarParser";
import { TermsContext } from "./JabutiGrammarParser";
import { TermOrWhenContext } from "./JabutiGrammarParser";
import { TermContext } from "./JabutiGrammarParser";
import { SessionIntervalContext } from "./JabutiGrammarParser";
import { WhenContext } from "./JabutiGrammarParser";
import { TimeoutContext } from "./JabutiGrammarParser";
import { TimeIntervalContext } from "./JabutiGrammarParser";
import { WeekDaysContext } from "./JabutiGrammarParser";
import { WeekDaysIntervalContext } from "./JabutiGrammarParser";
import { MaxNumberOfOperationContext } from "./JabutiGrammarParser";
import { MessageContentContext } from "./JabutiGrammarParser";
import { MessageContentBooleanContext } from "./JabutiGrammarParser";
import { MessageContentNumericContext } from "./JabutiGrammarParser";
import { MessageContentTextContext } from "./JabutiGrammarParser";
import { EqualContext } from "./JabutiGrammarParser";
import { NotEqualContext } from "./JabutiGrammarParser";
import { GreaterThanContext } from "./JabutiGrammarParser";
import { LassThanContext } from "./JabutiGrammarParser";
import { OnBreachContext } from "./JabutiGrammarParser";
import { DatetimeContext } from "./JabutiGrammarParser";
import { TimeContext } from "./JabutiGrammarParser";
import { SecondContext } from "./JabutiGrammarParser";
import { MinuteContext } from "./JabutiGrammarParser";
import { HourContext } from "./JabutiGrammarParser";
import { DayContext } from "./JabutiGrammarParser";
import { MonthContext } from "./JabutiGrammarParser";
import { YearContext } from "./JabutiGrammarParser";
import { DigitContext } from "./JabutiGrammarParser";


/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by `JabutiGrammarParser`.
 *
 * @param <Result> The return type of the visit operation. Use `void` for
 * operations with no return type.
 */
export interface JabutiGrammarVisitor<Result> extends ParseTreeVisitor<Result> {
	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.contract`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitContract?: (ctx: ContractContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.variables`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVariables?: (ctx: VariablesContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.variableStatement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVariableStatement?: (ctx: VariableStatementContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.dates`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDates?: (ctx: DatesContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.parties`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParties?: (ctx: PartiesContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.clauses`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitClauses?: (ctx: ClausesContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.beginDate`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBeginDate?: (ctx: BeginDateContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.dueDate`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDueDate?: (ctx: DueDateContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.application`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitApplication?: (ctx: ApplicationContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.process`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitProcess?: (ctx: ProcessContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.clause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitClause?: (ctx: ClauseContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.rolePlayer`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRolePlayer?: (ctx: RolePlayerContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.operation`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOperation?: (ctx: OperationContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.terms`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTerms?: (ctx: TermsContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.termOrWhen`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTermOrWhen?: (ctx: TermOrWhenContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.term`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTerm?: (ctx: TermContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.sessionInterval`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSessionInterval?: (ctx: SessionIntervalContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.when`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitWhen?: (ctx: WhenContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.timeout`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeout?: (ctx: TimeoutContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.timeInterval`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeInterval?: (ctx: TimeIntervalContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.weekDays`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitWeekDays?: (ctx: WeekDaysContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.weekDaysInterval`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitWeekDaysInterval?: (ctx: WeekDaysIntervalContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.maxNumberOfOperation`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMaxNumberOfOperation?: (ctx: MaxNumberOfOperationContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.messageContent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMessageContent?: (ctx: MessageContentContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.messageContentBoolean`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMessageContentBoolean?: (ctx: MessageContentBooleanContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.messageContentNumeric`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMessageContentNumeric?: (ctx: MessageContentNumericContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.messageContentText`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMessageContentText?: (ctx: MessageContentTextContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.equal`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEqual?: (ctx: EqualContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.notEqual`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNotEqual?: (ctx: NotEqualContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.greaterThan`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGreaterThan?: (ctx: GreaterThanContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.lassThan`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLassThan?: (ctx: LassThanContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.onBreach`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOnBreach?: (ctx: OnBreachContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.datetime`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDatetime?: (ctx: DatetimeContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.time`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTime?: (ctx: TimeContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.second`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSecond?: (ctx: SecondContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.minute`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMinute?: (ctx: MinuteContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.hour`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHour?: (ctx: HourContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.day`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDay?: (ctx: DayContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.month`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMonth?: (ctx: MonthContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.year`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitYear?: (ctx: YearContext) => Result;

	/**
	 * Visit a parse tree produced by `JabutiGrammarParser.digit`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDigit?: (ctx: DigitContext) => Result;
}

