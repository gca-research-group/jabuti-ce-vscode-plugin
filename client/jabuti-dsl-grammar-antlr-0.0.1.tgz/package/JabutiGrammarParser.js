"use strict";
// Generated from ./JabutiGrammar.g4 by ANTLR 4.9.0-SNAPSHOT
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DigitContext = exports.YearContext = exports.MonthContext = exports.DayContext = exports.HourContext = exports.MinuteContext = exports.SecondContext = exports.TimeContext = exports.DatetimeContext = exports.OnBreachContext = exports.LassThanContext = exports.GreaterThanContext = exports.NotEqualContext = exports.EqualContext = exports.MessageContentTextContext = exports.MessageContentNumericContext = exports.MessageContentBooleanContext = exports.MessageContentContext = exports.MaxNumberOfOperationContext = exports.WeekDaysIntervalContext = exports.WeekDaysContext = exports.TimeIntervalContext = exports.TimeoutContext = exports.WhenContext = exports.SessionIntervalContext = exports.TermContext = exports.TermOrWhenContext = exports.TermsContext = exports.OperationContext = exports.RolePlayerContext = exports.ClauseContext = exports.ProcessContext = exports.ApplicationContext = exports.DueDateContext = exports.BeginDateContext = exports.ClausesContext = exports.PartiesContext = exports.DatesContext = exports.VariableStatementContext = exports.VariablesContext = exports.ContractContext = exports.JabutiGrammarParser = void 0;
const ATNDeserializer_1 = require("antlr4ts/atn/ATNDeserializer");
const FailedPredicateException_1 = require("antlr4ts/FailedPredicateException");
const NoViableAltException_1 = require("antlr4ts/NoViableAltException");
const Parser_1 = require("antlr4ts/Parser");
const ParserRuleContext_1 = require("antlr4ts/ParserRuleContext");
const ParserATNSimulator_1 = require("antlr4ts/atn/ParserATNSimulator");
const RecognitionException_1 = require("antlr4ts/RecognitionException");
const Token_1 = require("antlr4ts/Token");
const VocabularyImpl_1 = require("antlr4ts/VocabularyImpl");
const Utils = __importStar(require("antlr4ts/misc/Utils"));
class JabutiGrammarParser extends Parser_1.Parser {
    // @Override
    // @NotNull
    get vocabulary() {
        return JabutiGrammarParser.VOCABULARY;
    }
    // tslint:enable:no-trailing-whitespace
    // @Override
    get grammarFileName() { return "JabutiGrammar.g4"; }
    // @Override
    get ruleNames() { return JabutiGrammarParser.ruleNames; }
    // @Override
    get serializedATN() { return JabutiGrammarParser._serializedATN; }
    createFailedPredicateException(predicate, message) {
        return new FailedPredicateException_1.FailedPredicateException(this, predicate, message);
    }
    constructor(input) {
        super(input);
        this._interp = new ParserATNSimulator_1.ParserATNSimulator(JabutiGrammarParser._ATN, this);
    }
    // @RuleVersion(0)
    contract() {
        let _localctx = new ContractContext(this._ctx, this.state);
        this.enterRule(_localctx, 0, JabutiGrammarParser.RULE_contract);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 95;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Contract) {
                    {
                        this.state = 82;
                        this.match(JabutiGrammarParser.Contract);
                        this.state = 83;
                        this.match(JabutiGrammarParser.ID);
                        this.state = 84;
                        this.match(JabutiGrammarParser.OpenBrace);
                        this.state = 91;
                        this._errHandler.sync(this);
                        _la = this._input.LA(1);
                        while ((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Dates) | (1 << JabutiGrammarParser.Parties) | (1 << JabutiGrammarParser.Clauses) | (1 << JabutiGrammarParser.Variables))) !== 0)) {
                            {
                                this.state = 89;
                                this._errHandler.sync(this);
                                switch (this._input.LA(1)) {
                                    case JabutiGrammarParser.Variables:
                                        {
                                            this.state = 85;
                                            this.variables();
                                        }
                                        break;
                                    case JabutiGrammarParser.Dates:
                                        {
                                            this.state = 86;
                                            this.dates();
                                        }
                                        break;
                                    case JabutiGrammarParser.Parties:
                                        {
                                            this.state = 87;
                                            this.parties();
                                        }
                                        break;
                                    case JabutiGrammarParser.Clauses:
                                        {
                                            this.state = 88;
                                            this.clauses();
                                        }
                                        break;
                                    default:
                                        throw new NoViableAltException_1.NoViableAltException(this);
                                }
                            }
                            this.state = 93;
                            this._errHandler.sync(this);
                            _la = this._input.LA(1);
                        }
                        this.state = 94;
                        this.match(JabutiGrammarParser.CloseBrace);
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    variables() {
        let _localctx = new VariablesContext(this._ctx, this.state);
        this.enterRule(_localctx, 2, JabutiGrammarParser.RULE_variables);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 97;
                this.match(JabutiGrammarParser.Variables);
                this.state = 98;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 102;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                while (_la === JabutiGrammarParser.ID) {
                    {
                        {
                            this.state = 99;
                            this.variableStatement();
                        }
                    }
                    this.state = 104;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                }
                this.state = 105;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    variableStatement() {
        let _localctx = new VariableStatementContext(this._ctx, this.state);
        this.enterRule(_localctx, 4, JabutiGrammarParser.RULE_variableStatement);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 107;
                this.match(JabutiGrammarParser.ID);
                this.state = 108;
                this.match(JabutiGrammarParser.Assign);
                this.state = 112;
                this._errHandler.sync(this);
                switch (this._input.LA(1)) {
                    case JabutiGrammarParser.String:
                        {
                            this.state = 109;
                            this.match(JabutiGrammarParser.String);
                        }
                        break;
                    case JabutiGrammarParser.Digit:
                        {
                            this.state = 110;
                            this.digit();
                        }
                        break;
                    case JabutiGrammarParser.MaxNumberOfOperation:
                    case JabutiGrammarParser.MessageContent:
                    case JabutiGrammarParser.Timeout:
                    case JabutiGrammarParser.TimeInterval:
                    case JabutiGrammarParser.SessionInterval:
                    case JabutiGrammarParser.WeekDaysInterval:
                        {
                            this.state = 111;
                            this.term();
                        }
                        break;
                    default:
                        throw new NoViableAltException_1.NoViableAltException(this);
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    dates() {
        let _localctx = new DatesContext(this._ctx, this.state);
        this.enterRule(_localctx, 6, JabutiGrammarParser.RULE_dates);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 114;
                this.match(JabutiGrammarParser.Dates);
                this.state = 115;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 124;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                do {
                    {
                        this.state = 124;
                        this._errHandler.sync(this);
                        switch (this._input.LA(1)) {
                            case JabutiGrammarParser.BeginDate:
                                {
                                    this.state = 116;
                                    this.beginDate();
                                    this.state = 118;
                                    this._errHandler.sync(this);
                                    _la = this._input.LA(1);
                                    if (_la === JabutiGrammarParser.Comma) {
                                        {
                                            this.state = 117;
                                            this.match(JabutiGrammarParser.Comma);
                                        }
                                    }
                                }
                                break;
                            case JabutiGrammarParser.DueDate:
                                {
                                    this.state = 120;
                                    this.dueDate();
                                    this.state = 122;
                                    this._errHandler.sync(this);
                                    _la = this._input.LA(1);
                                    if (_la === JabutiGrammarParser.Comma) {
                                        {
                                            this.state = 121;
                                            this.match(JabutiGrammarParser.Comma);
                                        }
                                    }
                                }
                                break;
                            default:
                                throw new NoViableAltException_1.NoViableAltException(this);
                        }
                    }
                    this.state = 126;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                } while (_la === JabutiGrammarParser.BeginDate || _la === JabutiGrammarParser.DueDate);
                this.state = 128;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    parties() {
        let _localctx = new PartiesContext(this._ctx, this.state);
        this.enterRule(_localctx, 8, JabutiGrammarParser.RULE_parties);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 130;
                this.match(JabutiGrammarParser.Parties);
                this.state = 131;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 140;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                do {
                    {
                        this.state = 140;
                        this._errHandler.sync(this);
                        switch (this._input.LA(1)) {
                            case JabutiGrammarParser.Application:
                                {
                                    this.state = 132;
                                    this.application();
                                    this.state = 134;
                                    this._errHandler.sync(this);
                                    _la = this._input.LA(1);
                                    if (_la === JabutiGrammarParser.Comma) {
                                        {
                                            this.state = 133;
                                            this.match(JabutiGrammarParser.Comma);
                                        }
                                    }
                                }
                                break;
                            case JabutiGrammarParser.Process:
                                {
                                    this.state = 136;
                                    this.process();
                                    this.state = 138;
                                    this._errHandler.sync(this);
                                    _la = this._input.LA(1);
                                    if (_la === JabutiGrammarParser.Comma) {
                                        {
                                            this.state = 137;
                                            this.match(JabutiGrammarParser.Comma);
                                        }
                                    }
                                }
                                break;
                            default:
                                throw new NoViableAltException_1.NoViableAltException(this);
                        }
                    }
                    this.state = 142;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                } while (_la === JabutiGrammarParser.Application || _la === JabutiGrammarParser.Process);
                this.state = 144;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    clauses() {
        let _localctx = new ClausesContext(this._ctx, this.state);
        this.enterRule(_localctx, 10, JabutiGrammarParser.RULE_clauses);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 146;
                this.match(JabutiGrammarParser.Clauses);
                this.state = 147;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 149;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                do {
                    {
                        {
                            this.state = 148;
                            this.clause();
                        }
                    }
                    this.state = 151;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                } while ((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Right) | (1 << JabutiGrammarParser.Prohibition) | (1 << JabutiGrammarParser.Obligation))) !== 0));
                this.state = 153;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    beginDate() {
        let _localctx = new BeginDateContext(this._ctx, this.state);
        this.enterRule(_localctx, 12, JabutiGrammarParser.RULE_beginDate);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 155;
                this.match(JabutiGrammarParser.BeginDate);
                this.state = 156;
                this.match(JabutiGrammarParser.Assign);
                this.state = 157;
                this.datetime();
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    dueDate() {
        let _localctx = new DueDateContext(this._ctx, this.state);
        this.enterRule(_localctx, 14, JabutiGrammarParser.RULE_dueDate);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 159;
                this.match(JabutiGrammarParser.DueDate);
                this.state = 160;
                this.match(JabutiGrammarParser.Assign);
                this.state = 161;
                this.datetime();
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    application() {
        let _localctx = new ApplicationContext(this._ctx, this.state);
        this.enterRule(_localctx, 16, JabutiGrammarParser.RULE_application);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 163;
                this.match(JabutiGrammarParser.Application);
                this.state = 164;
                this.match(JabutiGrammarParser.Assign);
                this.state = 165;
                this.match(JabutiGrammarParser.String);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    process() {
        let _localctx = new ProcessContext(this._ctx, this.state);
        this.enterRule(_localctx, 18, JabutiGrammarParser.RULE_process);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 167;
                this.match(JabutiGrammarParser.Process);
                this.state = 168;
                this.match(JabutiGrammarParser.Assign);
                this.state = 169;
                this.match(JabutiGrammarParser.String);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    clause() {
        let _localctx = new ClauseContext(this._ctx, this.state);
        this.enterRule(_localctx, 20, JabutiGrammarParser.RULE_clause);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 171;
                _la = this._input.LA(1);
                if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Right) | (1 << JabutiGrammarParser.Prohibition) | (1 << JabutiGrammarParser.Obligation))) !== 0))) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
                this.state = 172;
                this.match(JabutiGrammarParser.ID);
                this.state = 173;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 174;
                this.rolePlayer();
                this.state = 176;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Comma) {
                    {
                        this.state = 175;
                        this.match(JabutiGrammarParser.Comma);
                    }
                }
                this.state = 178;
                this.operation();
                this.state = 180;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Comma) {
                    {
                        this.state = 179;
                        this.match(JabutiGrammarParser.Comma);
                    }
                }
                this.state = 182;
                this.terms();
                this.state = 185;
                this._errHandler.sync(this);
                switch (this._input.LA(1)) {
                    case JabutiGrammarParser.OnBreach:
                        {
                            this.state = 183;
                            this.onBreach();
                        }
                        break;
                    case JabutiGrammarParser.OnSuccess:
                        {
                            this.state = 184;
                            this.match(JabutiGrammarParser.OnSuccess);
                        }
                        break;
                    case JabutiGrammarParser.CloseBrace:
                        break;
                    default:
                        break;
                }
                this.state = 187;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    rolePlayer() {
        let _localctx = new RolePlayerContext(this._ctx, this.state);
        this.enterRule(_localctx, 22, JabutiGrammarParser.RULE_rolePlayer);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 189;
                this.match(JabutiGrammarParser.RolePlayer);
                this.state = 190;
                this.match(JabutiGrammarParser.Assign);
                this.state = 191;
                _la = this._input.LA(1);
                if (!(_la === JabutiGrammarParser.Application || _la === JabutiGrammarParser.Process)) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    operation() {
        let _localctx = new OperationContext(this._ctx, this.state);
        this.enterRule(_localctx, 24, JabutiGrammarParser.RULE_operation);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 193;
                this.match(JabutiGrammarParser.Operation);
                this.state = 194;
                this.match(JabutiGrammarParser.Assign);
                this.state = 195;
                _la = this._input.LA(1);
                if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Push) | (1 << JabutiGrammarParser.Poll) | (1 << JabutiGrammarParser.Read) | (1 << JabutiGrammarParser.Write) | (1 << JabutiGrammarParser.Request) | (1 << JabutiGrammarParser.Response))) !== 0))) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    terms() {
        let _localctx = new TermsContext(this._ctx, this.state);
        this.enterRule(_localctx, 26, JabutiGrammarParser.RULE_terms);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 197;
                this.match(JabutiGrammarParser.Terms);
                this.state = 198;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 216;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                do {
                    {
                        this.state = 216;
                        this._errHandler.sync(this);
                        switch (this._input.LA(1)) {
                            case JabutiGrammarParser.MaxNumberOfOperation:
                            case JabutiGrammarParser.MessageContent:
                            case JabutiGrammarParser.Timeout:
                            case JabutiGrammarParser.TimeInterval:
                            case JabutiGrammarParser.SessionInterval:
                            case JabutiGrammarParser.WeekDaysInterval:
                            case JabutiGrammarParser.When:
                                {
                                    {
                                        {
                                            this.state = 199;
                                            this.termOrWhen();
                                        }
                                        this.state = 201;
                                        this._errHandler.sync(this);
                                        _la = this._input.LA(1);
                                        if (_la === JabutiGrammarParser.Comma) {
                                            {
                                                this.state = 200;
                                                this.match(JabutiGrammarParser.Comma);
                                            }
                                        }
                                    }
                                }
                                break;
                            case JabutiGrammarParser.OpenParen:
                                {
                                    {
                                        this.state = 203;
                                        this.match(JabutiGrammarParser.OpenParen);
                                        this.state = 204;
                                        this.term();
                                        this.state = 209;
                                        this._errHandler.sync(this);
                                        _la = this._input.LA(1);
                                        while (_la === JabutiGrammarParser.Or) {
                                            {
                                                {
                                                    this.state = 205;
                                                    this.match(JabutiGrammarParser.Or);
                                                    this.state = 206;
                                                    this.termOrWhen();
                                                }
                                            }
                                            this.state = 211;
                                            this._errHandler.sync(this);
                                            _la = this._input.LA(1);
                                        }
                                        this.state = 212;
                                        this.match(JabutiGrammarParser.CloseParen);
                                        this.state = 214;
                                        this._errHandler.sync(this);
                                        _la = this._input.LA(1);
                                        if (_la === JabutiGrammarParser.Comma) {
                                            {
                                                this.state = 213;
                                                this.match(JabutiGrammarParser.Comma);
                                            }
                                        }
                                    }
                                }
                                break;
                            default:
                                throw new NoViableAltException_1.NoViableAltException(this);
                        }
                    }
                    this.state = 218;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                } while ((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.MaxNumberOfOperation) | (1 << JabutiGrammarParser.MessageContent) | (1 << JabutiGrammarParser.Timeout) | (1 << JabutiGrammarParser.TimeInterval) | (1 << JabutiGrammarParser.SessionInterval) | (1 << JabutiGrammarParser.WeekDaysInterval))) !== 0) || _la === JabutiGrammarParser.When || _la === JabutiGrammarParser.OpenParen);
                this.state = 220;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    termOrWhen() {
        let _localctx = new TermOrWhenContext(this._ctx, this.state);
        this.enterRule(_localctx, 28, JabutiGrammarParser.RULE_termOrWhen);
        try {
            this.state = 224;
            this._errHandler.sync(this);
            switch (this._input.LA(1)) {
                case JabutiGrammarParser.MaxNumberOfOperation:
                case JabutiGrammarParser.MessageContent:
                case JabutiGrammarParser.Timeout:
                case JabutiGrammarParser.TimeInterval:
                case JabutiGrammarParser.SessionInterval:
                case JabutiGrammarParser.WeekDaysInterval:
                    this.enterOuterAlt(_localctx, 1);
                    {
                        this.state = 222;
                        this.term();
                    }
                    break;
                case JabutiGrammarParser.When:
                    this.enterOuterAlt(_localctx, 2);
                    {
                        this.state = 223;
                        this.when();
                    }
                    break;
                default:
                    throw new NoViableAltException_1.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    term() {
        let _localctx = new TermContext(this._ctx, this.state);
        this.enterRule(_localctx, 30, JabutiGrammarParser.RULE_term);
        try {
            this.state = 232;
            this._errHandler.sync(this);
            switch (this._input.LA(1)) {
                case JabutiGrammarParser.MaxNumberOfOperation:
                    this.enterOuterAlt(_localctx, 1);
                    {
                        this.state = 226;
                        this.maxNumberOfOperation();
                    }
                    break;
                case JabutiGrammarParser.MessageContent:
                    this.enterOuterAlt(_localctx, 2);
                    {
                        this.state = 227;
                        this.messageContent();
                    }
                    break;
                case JabutiGrammarParser.WeekDaysInterval:
                    this.enterOuterAlt(_localctx, 3);
                    {
                        this.state = 228;
                        this.weekDaysInterval();
                    }
                    break;
                case JabutiGrammarParser.TimeInterval:
                    this.enterOuterAlt(_localctx, 4);
                    {
                        this.state = 229;
                        this.timeInterval();
                    }
                    break;
                case JabutiGrammarParser.Timeout:
                    this.enterOuterAlt(_localctx, 5);
                    {
                        this.state = 230;
                        this.timeout();
                    }
                    break;
                case JabutiGrammarParser.SessionInterval:
                    this.enterOuterAlt(_localctx, 6);
                    {
                        this.state = 231;
                        this.sessionInterval();
                    }
                    break;
                default:
                    throw new NoViableAltException_1.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    sessionInterval() {
        let _localctx = new SessionIntervalContext(this._ctx, this.state);
        this.enterRule(_localctx, 32, JabutiGrammarParser.RULE_sessionInterval);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 234;
                this.match(JabutiGrammarParser.SessionInterval);
                this.state = 235;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 236;
                this.digit();
                this.state = 237;
                _la = this._input.LA(1);
                if (!(((((_la - 42)) & ~0x1F) === 0 && ((1 << (_la - 42)) & ((1 << (JabutiGrammarParser.Month - 42)) | (1 << (JabutiGrammarParser.Week - 42)) | (1 << (JabutiGrammarParser.Day - 42)) | (1 << (JabutiGrammarParser.Minute - 42)) | (1 << (JabutiGrammarParser.Second - 42)))) !== 0))) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
                this.state = 238;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    when() {
        let _localctx = new WhenContext(this._ctx, this.state);
        this.enterRule(_localctx, 34, JabutiGrammarParser.RULE_when);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 240;
                this.match(JabutiGrammarParser.When);
                this.state = 241;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 244;
                this._errHandler.sync(this);
                switch (this._input.LA(1)) {
                    case JabutiGrammarParser.MaxNumberOfOperation:
                    case JabutiGrammarParser.MessageContent:
                    case JabutiGrammarParser.Timeout:
                    case JabutiGrammarParser.TimeInterval:
                    case JabutiGrammarParser.SessionInterval:
                    case JabutiGrammarParser.WeekDaysInterval:
                    case JabutiGrammarParser.When:
                        {
                            this.state = 242;
                            this.termOrWhen();
                        }
                        break;
                    case JabutiGrammarParser.ID:
                        {
                            this.state = 243;
                            this.match(JabutiGrammarParser.ID);
                        }
                        break;
                    default:
                        throw new NoViableAltException_1.NoViableAltException(this);
                }
                this.state = 246;
                this.match(JabutiGrammarParser.CloseParen);
                this.state = 247;
                this.match(JabutiGrammarParser.Do);
                this.state = 248;
                this.match(JabutiGrammarParser.OpenBrace);
                this.state = 249;
                this.termOrWhen();
                this.state = 250;
                this.match(JabutiGrammarParser.CloseBrace);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    timeout() {
        let _localctx = new TimeoutContext(this._ctx, this.state);
        this.enterRule(_localctx, 36, JabutiGrammarParser.RULE_timeout);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 252;
                this.match(JabutiGrammarParser.Timeout);
                this.state = 253;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 254;
                this.digit();
                this.state = 255;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    timeInterval() {
        let _localctx = new TimeIntervalContext(this._ctx, this.state);
        this.enterRule(_localctx, 38, JabutiGrammarParser.RULE_timeInterval);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 257;
                this.match(JabutiGrammarParser.TimeInterval);
                this.state = 258;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 259;
                this.time();
                this.state = 260;
                this.match(JabutiGrammarParser.To);
                this.state = 261;
                this.time();
                this.state = 262;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    weekDays() {
        let _localctx = new WeekDaysContext(this._ctx, this.state);
        this.enterRule(_localctx, 40, JabutiGrammarParser.RULE_weekDays);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 264;
                _la = this._input.LA(1);
                if (!(((((_la - 34)) & ~0x1F) === 0 && ((1 << (_la - 34)) & ((1 << (JabutiGrammarParser.Monday - 34)) | (1 << (JabutiGrammarParser.Tuesday - 34)) | (1 << (JabutiGrammarParser.Wednesday - 34)) | (1 << (JabutiGrammarParser.Thursday - 34)) | (1 << (JabutiGrammarParser.Friday - 34)) | (1 << (JabutiGrammarParser.Saturday - 34)) | (1 << (JabutiGrammarParser.Sunday - 34)))) !== 0))) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    weekDaysInterval() {
        let _localctx = new WeekDaysIntervalContext(this._ctx, this.state);
        this.enterRule(_localctx, 42, JabutiGrammarParser.RULE_weekDaysInterval);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 266;
                this.match(JabutiGrammarParser.WeekDaysInterval);
                this.state = 267;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 268;
                this.weekDays();
                this.state = 269;
                this.match(JabutiGrammarParser.To);
                this.state = 270;
                this.weekDays();
                this.state = 271;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    maxNumberOfOperation() {
        let _localctx = new MaxNumberOfOperationContext(this._ctx, this.state);
        this.enterRule(_localctx, 44, JabutiGrammarParser.RULE_maxNumberOfOperation);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 273;
                this.match(JabutiGrammarParser.MaxNumberOfOperation);
                this.state = 274;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 275;
                this.digit();
                this.state = 276;
                this.match(JabutiGrammarParser.Per);
                this.state = 277;
                _la = this._input.LA(1);
                if (!(((((_la - 42)) & ~0x1F) === 0 && ((1 << (_la - 42)) & ((1 << (JabutiGrammarParser.Month - 42)) | (1 << (JabutiGrammarParser.Week - 42)) | (1 << (JabutiGrammarParser.Day - 42)) | (1 << (JabutiGrammarParser.Hour - 42)) | (1 << (JabutiGrammarParser.Minute - 42)) | (1 << (JabutiGrammarParser.Second - 42)))) !== 0))) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
                this.state = 278;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    messageContent() {
        let _localctx = new MessageContentContext(this._ctx, this.state);
        this.enterRule(_localctx, 46, JabutiGrammarParser.RULE_messageContent);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 280;
                this.match(JabutiGrammarParser.MessageContent);
                this.state = 281;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 308;
                this._errHandler.sync(this);
                switch (this.interpreter.adaptivePredict(this._input, 28, this._ctx)) {
                    case 1:
                        {
                            this.state = 282;
                            this.messageContentBoolean();
                        }
                        break;
                    case 2:
                        {
                            {
                                this.state = 283;
                                this.messageContentBoolean();
                            }
                            this.state = 286;
                            this._errHandler.sync(this);
                            switch (this._input.LA(1)) {
                                case JabutiGrammarParser.Assign:
                                    {
                                        this.state = 284;
                                        this.equal();
                                    }
                                    break;
                                case JabutiGrammarParser.Exclamation:
                                    {
                                        this.state = 285;
                                        this.notEqual();
                                    }
                                    break;
                                default:
                                    throw new NoViableAltException_1.NoViableAltException(this);
                            }
                            {
                                this.state = 288;
                                this.messageContentBoolean();
                            }
                        }
                        break;
                    case 3:
                        {
                            {
                                this.state = 290;
                                this.messageContentNumeric();
                            }
                            this.state = 297;
                            this._errHandler.sync(this);
                            switch (this.interpreter.adaptivePredict(this._input, 26, this._ctx)) {
                                case 1:
                                    {
                                        this.state = 291;
                                        this.equal();
                                    }
                                    break;
                                case 2:
                                    {
                                        this.state = 292;
                                        this.notEqual();
                                    }
                                    break;
                                case 3:
                                    {
                                        this.state = 293;
                                        this.greaterThan();
                                    }
                                    break;
                                case 4:
                                    {
                                        this.state = 294;
                                        this.lassThan();
                                    }
                                    break;
                                case 5:
                                    {
                                        this.state = 295;
                                        this.match(JabutiGrammarParser.Greater);
                                    }
                                    break;
                                case 6:
                                    {
                                        this.state = 296;
                                        this.match(JabutiGrammarParser.Lass);
                                    }
                                    break;
                            }
                            {
                                this.state = 299;
                                this.messageContentNumeric();
                            }
                        }
                        break;
                    case 4:
                        {
                            {
                                this.state = 301;
                                this.messageContentText();
                            }
                            this.state = 304;
                            this._errHandler.sync(this);
                            switch (this._input.LA(1)) {
                                case JabutiGrammarParser.Assign:
                                    {
                                        this.state = 302;
                                        this.equal();
                                    }
                                    break;
                                case JabutiGrammarParser.Exclamation:
                                    {
                                        this.state = 303;
                                        this.notEqual();
                                    }
                                    break;
                                default:
                                    throw new NoViableAltException_1.NoViableAltException(this);
                            }
                            {
                                this.state = 306;
                                this.messageContentText();
                            }
                        }
                        break;
                }
                this.state = 310;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    messageContentBoolean() {
        let _localctx = new MessageContentBooleanContext(this._ctx, this.state);
        this.enterRule(_localctx, 48, JabutiGrammarParser.RULE_messageContentBoolean);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 312;
                this.match(JabutiGrammarParser.Boolean);
                this.state = 313;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 314;
                _la = this._input.LA(1);
                if (!(_la === JabutiGrammarParser.String || _la === JabutiGrammarParser.ID)) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    if (this._input.LA(1) === Token_1.Token.EOF) {
                        this.matchedEOF = true;
                    }
                    this._errHandler.reportMatch(this);
                    this.consume();
                }
                this.state = 315;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    messageContentNumeric() {
        let _localctx = new MessageContentNumericContext(this._ctx, this.state);
        this.enterRule(_localctx, 50, JabutiGrammarParser.RULE_messageContentNumeric);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 322;
                this._errHandler.sync(this);
                switch (this._input.LA(1)) {
                    case JabutiGrammarParser.Numeric:
                        {
                            this.state = 317;
                            this.match(JabutiGrammarParser.Numeric);
                            this.state = 318;
                            this.match(JabutiGrammarParser.OpenParen);
                            this.state = 319;
                            _la = this._input.LA(1);
                            if (!(_la === JabutiGrammarParser.String || _la === JabutiGrammarParser.ID)) {
                                this._errHandler.recoverInline(this);
                            }
                            else {
                                if (this._input.LA(1) === Token_1.Token.EOF) {
                                    this.matchedEOF = true;
                                }
                                this._errHandler.reportMatch(this);
                                this.consume();
                            }
                            this.state = 320;
                            this.match(JabutiGrammarParser.CloseParen);
                        }
                        break;
                    case JabutiGrammarParser.Digit:
                        {
                            this.state = 321;
                            this.digit();
                        }
                        break;
                    default:
                        throw new NoViableAltException_1.NoViableAltException(this);
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    messageContentText() {
        let _localctx = new MessageContentTextContext(this._ctx, this.state);
        this.enterRule(_localctx, 52, JabutiGrammarParser.RULE_messageContentText);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 329;
                this._errHandler.sync(this);
                switch (this._input.LA(1)) {
                    case JabutiGrammarParser.Text:
                        {
                            this.state = 324;
                            this.match(JabutiGrammarParser.Text);
                            this.state = 325;
                            this.match(JabutiGrammarParser.OpenParen);
                            this.state = 326;
                            _la = this._input.LA(1);
                            if (!(_la === JabutiGrammarParser.String || _la === JabutiGrammarParser.ID)) {
                                this._errHandler.recoverInline(this);
                            }
                            else {
                                if (this._input.LA(1) === Token_1.Token.EOF) {
                                    this.matchedEOF = true;
                                }
                                this._errHandler.reportMatch(this);
                                this.consume();
                            }
                            this.state = 327;
                            this.match(JabutiGrammarParser.CloseParen);
                        }
                        break;
                    case JabutiGrammarParser.String:
                        {
                            this.state = 328;
                            this.match(JabutiGrammarParser.String);
                        }
                        break;
                    default:
                        throw new NoViableAltException_1.NoViableAltException(this);
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    equal() {
        let _localctx = new EqualContext(this._ctx, this.state);
        this.enterRule(_localctx, 54, JabutiGrammarParser.RULE_equal);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 331;
                this.match(JabutiGrammarParser.Assign);
                this.state = 332;
                this.match(JabutiGrammarParser.Assign);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    notEqual() {
        let _localctx = new NotEqualContext(this._ctx, this.state);
        this.enterRule(_localctx, 56, JabutiGrammarParser.RULE_notEqual);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 334;
                this.match(JabutiGrammarParser.Exclamation);
                this.state = 335;
                this.match(JabutiGrammarParser.Assign);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    greaterThan() {
        let _localctx = new GreaterThanContext(this._ctx, this.state);
        this.enterRule(_localctx, 58, JabutiGrammarParser.RULE_greaterThan);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 337;
                this.match(JabutiGrammarParser.Greater);
                this.state = 338;
                this.match(JabutiGrammarParser.Assign);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    lassThan() {
        let _localctx = new LassThanContext(this._ctx, this.state);
        this.enterRule(_localctx, 60, JabutiGrammarParser.RULE_lassThan);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 340;
                this.match(JabutiGrammarParser.Lass);
                this.state = 341;
                this.match(JabutiGrammarParser.Assign);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    onBreach() {
        let _localctx = new OnBreachContext(this._ctx, this.state);
        this.enterRule(_localctx, 62, JabutiGrammarParser.RULE_onBreach);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 343;
                this.match(JabutiGrammarParser.OnBreach);
                this.state = 344;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 345;
                this.match(JabutiGrammarParser.Log);
                this.state = 346;
                this.match(JabutiGrammarParser.OpenParen);
                this.state = 347;
                this.match(JabutiGrammarParser.String);
                this.state = 348;
                this.match(JabutiGrammarParser.CloseParen);
                this.state = 349;
                this.match(JabutiGrammarParser.CloseParen);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    datetime() {
        let _localctx = new DatetimeContext(this._ctx, this.state);
        this.enterRule(_localctx, 64, JabutiGrammarParser.RULE_datetime);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 351;
                this.year();
                this.state = 352;
                this.match(JabutiGrammarParser.Minus);
                this.state = 353;
                this.month();
                this.state = 354;
                this.match(JabutiGrammarParser.Minus);
                this.state = 355;
                this.day();
                this.state = 357;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Digit) {
                    {
                        this.state = 356;
                        this.time();
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    time() {
        let _localctx = new TimeContext(this._ctx, this.state);
        this.enterRule(_localctx, 66, JabutiGrammarParser.RULE_time);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 359;
                this.hour();
                this.state = 360;
                this.match(JabutiGrammarParser.Colon);
                this.state = 361;
                this.minute();
                this.state = 364;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Colon) {
                    {
                        this.state = 362;
                        this.match(JabutiGrammarParser.Colon);
                        this.state = 363;
                        this.second();
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    second() {
        let _localctx = new SecondContext(this._ctx, this.state);
        this.enterRule(_localctx, 68, JabutiGrammarParser.RULE_second);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 366;
                this.match(JabutiGrammarParser.Digit);
                this.state = 368;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Digit) {
                    {
                        this.state = 367;
                        this.match(JabutiGrammarParser.Digit);
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    minute() {
        let _localctx = new MinuteContext(this._ctx, this.state);
        this.enterRule(_localctx, 70, JabutiGrammarParser.RULE_minute);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 370;
                this.match(JabutiGrammarParser.Digit);
                this.state = 372;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Digit) {
                    {
                        this.state = 371;
                        this.match(JabutiGrammarParser.Digit);
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    hour() {
        let _localctx = new HourContext(this._ctx, this.state);
        this.enterRule(_localctx, 72, JabutiGrammarParser.RULE_hour);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 374;
                this.match(JabutiGrammarParser.Digit);
                this.state = 376;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Digit) {
                    {
                        this.state = 375;
                        this.match(JabutiGrammarParser.Digit);
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    day() {
        let _localctx = new DayContext(this._ctx, this.state);
        this.enterRule(_localctx, 74, JabutiGrammarParser.RULE_day);
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 378;
                this.match(JabutiGrammarParser.Digit);
                this.state = 380;
                this._errHandler.sync(this);
                switch (this.interpreter.adaptivePredict(this._input, 36, this._ctx)) {
                    case 1:
                        {
                            this.state = 379;
                            this.match(JabutiGrammarParser.Digit);
                        }
                        break;
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    month() {
        let _localctx = new MonthContext(this._ctx, this.state);
        this.enterRule(_localctx, 76, JabutiGrammarParser.RULE_month);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 382;
                this.match(JabutiGrammarParser.Digit);
                this.state = 384;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                if (_la === JabutiGrammarParser.Digit) {
                    {
                        this.state = 383;
                        this.match(JabutiGrammarParser.Digit);
                    }
                }
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    year() {
        let _localctx = new YearContext(this._ctx, this.state);
        this.enterRule(_localctx, 78, JabutiGrammarParser.RULE_year);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 387;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                do {
                    {
                        {
                            this.state = 386;
                            this.match(JabutiGrammarParser.Digit);
                        }
                    }
                    this.state = 389;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                } while (_la === JabutiGrammarParser.Digit);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    // @RuleVersion(0)
    digit() {
        let _localctx = new DigitContext(this._ctx, this.state);
        this.enterRule(_localctx, 80, JabutiGrammarParser.RULE_digit);
        let _la;
        try {
            this.enterOuterAlt(_localctx, 1);
            {
                this.state = 392;
                this._errHandler.sync(this);
                _la = this._input.LA(1);
                do {
                    {
                        {
                            this.state = 391;
                            this.match(JabutiGrammarParser.Digit);
                        }
                    }
                    this.state = 394;
                    this._errHandler.sync(this);
                    _la = this._input.LA(1);
                } while (_la === JabutiGrammarParser.Digit);
            }
        }
        catch (re) {
            if (re instanceof RecognitionException_1.RecognitionException) {
                _localctx.exception = re;
                this._errHandler.reportError(this, re);
                this._errHandler.recover(this, re);
            }
            else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    static get _ATN() {
        if (!JabutiGrammarParser.__ATN) {
            JabutiGrammarParser.__ATN = new ATNDeserializer_1.ATNDeserializer().deserialize(Utils.toCharArray(JabutiGrammarParser._serializedATN));
        }
        return JabutiGrammarParser.__ATN;
    }
}
exports.JabutiGrammarParser = JabutiGrammarParser;
JabutiGrammarParser.Contract = 1;
JabutiGrammarParser.BeginDate = 2;
JabutiGrammarParser.DueDate = 3;
JabutiGrammarParser.Dates = 4;
JabutiGrammarParser.Parties = 5;
JabutiGrammarParser.Application = 6;
JabutiGrammarParser.Process = 7;
JabutiGrammarParser.Clauses = 8;
JabutiGrammarParser.Right = 9;
JabutiGrammarParser.Prohibition = 10;
JabutiGrammarParser.Obligation = 11;
JabutiGrammarParser.RolePlayer = 12;
JabutiGrammarParser.Operation = 13;
JabutiGrammarParser.OnBreach = 14;
JabutiGrammarParser.OnSuccess = 15;
JabutiGrammarParser.Push = 16;
JabutiGrammarParser.Poll = 17;
JabutiGrammarParser.Read = 18;
JabutiGrammarParser.Write = 19;
JabutiGrammarParser.Request = 20;
JabutiGrammarParser.Response = 21;
JabutiGrammarParser.Condition = 22;
JabutiGrammarParser.MaxNumberOfOperation = 23;
JabutiGrammarParser.MessageContent = 24;
JabutiGrammarParser.Log = 25;
JabutiGrammarParser.Timeout = 26;
JabutiGrammarParser.TimeInterval = 27;
JabutiGrammarParser.SessionInterval = 28;
JabutiGrammarParser.WeekDaysInterval = 29;
JabutiGrammarParser.Variables = 30;
JabutiGrammarParser.Per = 31;
JabutiGrammarParser.To = 32;
JabutiGrammarParser.Or = 33;
JabutiGrammarParser.Monday = 34;
JabutiGrammarParser.Tuesday = 35;
JabutiGrammarParser.Wednesday = 36;
JabutiGrammarParser.Thursday = 37;
JabutiGrammarParser.Friday = 38;
JabutiGrammarParser.Saturday = 39;
JabutiGrammarParser.Sunday = 40;
JabutiGrammarParser.Terms = 41;
JabutiGrammarParser.Month = 42;
JabutiGrammarParser.Week = 43;
JabutiGrammarParser.Day = 44;
JabutiGrammarParser.Hour = 45;
JabutiGrammarParser.Minute = 46;
JabutiGrammarParser.Second = 47;
JabutiGrammarParser.When = 48;
JabutiGrammarParser.Do = 49;
JabutiGrammarParser.Text = 50;
JabutiGrammarParser.Numeric = 51;
JabutiGrammarParser.Boolean = 52;
JabutiGrammarParser.Comma = 53;
JabutiGrammarParser.SemiColon = 54;
JabutiGrammarParser.OpenParen = 55;
JabutiGrammarParser.CloseParen = 56;
JabutiGrammarParser.OpenBrace = 57;
JabutiGrammarParser.CloseBrace = 58;
JabutiGrammarParser.Colon = 59;
JabutiGrammarParser.Divide = 60;
JabutiGrammarParser.Minus = 61;
JabutiGrammarParser.Assign = 62;
JabutiGrammarParser.Exclamation = 63;
JabutiGrammarParser.Greater = 64;
JabutiGrammarParser.Lass = 65;
JabutiGrammarParser.Under = 66;
JabutiGrammarParser.String = 67;
JabutiGrammarParser.ID = 68;
JabutiGrammarParser.Digit = 69;
JabutiGrammarParser.Word = 70;
JabutiGrammarParser.WHITESPACE = 71;
JabutiGrammarParser.SINGLE_COMMENT = 72;
JabutiGrammarParser.MULTI_COMMENT = 73;
JabutiGrammarParser.RULE_contract = 0;
JabutiGrammarParser.RULE_variables = 1;
JabutiGrammarParser.RULE_variableStatement = 2;
JabutiGrammarParser.RULE_dates = 3;
JabutiGrammarParser.RULE_parties = 4;
JabutiGrammarParser.RULE_clauses = 5;
JabutiGrammarParser.RULE_beginDate = 6;
JabutiGrammarParser.RULE_dueDate = 7;
JabutiGrammarParser.RULE_application = 8;
JabutiGrammarParser.RULE_process = 9;
JabutiGrammarParser.RULE_clause = 10;
JabutiGrammarParser.RULE_rolePlayer = 11;
JabutiGrammarParser.RULE_operation = 12;
JabutiGrammarParser.RULE_terms = 13;
JabutiGrammarParser.RULE_termOrWhen = 14;
JabutiGrammarParser.RULE_term = 15;
JabutiGrammarParser.RULE_sessionInterval = 16;
JabutiGrammarParser.RULE_when = 17;
JabutiGrammarParser.RULE_timeout = 18;
JabutiGrammarParser.RULE_timeInterval = 19;
JabutiGrammarParser.RULE_weekDays = 20;
JabutiGrammarParser.RULE_weekDaysInterval = 21;
JabutiGrammarParser.RULE_maxNumberOfOperation = 22;
JabutiGrammarParser.RULE_messageContent = 23;
JabutiGrammarParser.RULE_messageContentBoolean = 24;
JabutiGrammarParser.RULE_messageContentNumeric = 25;
JabutiGrammarParser.RULE_messageContentText = 26;
JabutiGrammarParser.RULE_equal = 27;
JabutiGrammarParser.RULE_notEqual = 28;
JabutiGrammarParser.RULE_greaterThan = 29;
JabutiGrammarParser.RULE_lassThan = 30;
JabutiGrammarParser.RULE_onBreach = 31;
JabutiGrammarParser.RULE_datetime = 32;
JabutiGrammarParser.RULE_time = 33;
JabutiGrammarParser.RULE_second = 34;
JabutiGrammarParser.RULE_minute = 35;
JabutiGrammarParser.RULE_hour = 36;
JabutiGrammarParser.RULE_day = 37;
JabutiGrammarParser.RULE_month = 38;
JabutiGrammarParser.RULE_year = 39;
JabutiGrammarParser.RULE_digit = 40;
// tslint:disable:no-trailing-whitespace
JabutiGrammarParser.ruleNames = [
    "contract", "variables", "variableStatement", "dates", "parties", "clauses",
    "beginDate", "dueDate", "application", "process", "clause", "rolePlayer",
    "operation", "terms", "termOrWhen", "term", "sessionInterval", "when",
    "timeout", "timeInterval", "weekDays", "weekDaysInterval", "maxNumberOfOperation",
    "messageContent", "messageContentBoolean", "messageContentNumeric", "messageContentText",
    "equal", "notEqual", "greaterThan", "lassThan", "onBreach", "datetime",
    "time", "second", "minute", "hour", "day", "month", "year", "digit",
];
JabutiGrammarParser._LITERAL_NAMES = [
    undefined, "'contract'", "'beginDate'", "'dueDate'", "'dates'", "'parties'",
    "'application'", "'process'", "'clauses'", "'right'", "'prohibition'",
    "'obligation'", "'rolePlayer'", "'operation'", "'onBreach'", "'OnSuccess'",
    "'push'", "'poll'", "'read'", "'write'", "'request'", "'response'", "'condition'",
    "'MaxNumberOfOperation'", "'MessageContent'", "'log'", "'Timeout'", "'TimeInterval'",
    "'SessionInterval'", "'WeekDaysInterval'", "'variables'", "'per'", "'to'",
    "'OR'", "'Monday'", "'Tuesday'", "'Wednesday'", "'Thursday'", "'Friday'",
    "'Saturday'", "'Sunday'", "'terms'", "'Month'", "'Week'", "'Day'", "'Hour'",
    "'Minute'", "'Second'", "'when'", "'do'", "'text'", "'numeric'", "'boolean'",
    "','", "';'", "'('", "')'", "'{'", "'}'", "':'", "'/'", "'-'", "'='",
    "'!'", "'>'", "'<'", "'_'",
];
JabutiGrammarParser._SYMBOLIC_NAMES = [
    undefined, "Contract", "BeginDate", "DueDate", "Dates", "Parties", "Application",
    "Process", "Clauses", "Right", "Prohibition", "Obligation", "RolePlayer",
    "Operation", "OnBreach", "OnSuccess", "Push", "Poll", "Read", "Write",
    "Request", "Response", "Condition", "MaxNumberOfOperation", "MessageContent",
    "Log", "Timeout", "TimeInterval", "SessionInterval", "WeekDaysInterval",
    "Variables", "Per", "To", "Or", "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday", "Terms", "Month", "Week", "Day", "Hour",
    "Minute", "Second", "When", "Do", "Text", "Numeric", "Boolean", "Comma",
    "SemiColon", "OpenParen", "CloseParen", "OpenBrace", "CloseBrace", "Colon",
    "Divide", "Minus", "Assign", "Exclamation", "Greater", "Lass", "Under",
    "String", "ID", "Digit", "Word", "WHITESPACE", "SINGLE_COMMENT", "MULTI_COMMENT",
];
JabutiGrammarParser.VOCABULARY = new VocabularyImpl_1.VocabularyImpl(JabutiGrammarParser._LITERAL_NAMES, JabutiGrammarParser._SYMBOLIC_NAMES, []);
JabutiGrammarParser._serializedATN = "\x03\uC91D\uCABA\u058D\uAFBA\u4F53\u0607\uEA8B\uC241\x03K\u018F\x04\x02" +
    "\t\x02\x04\x03\t\x03\x04\x04\t\x04\x04\x05\t\x05\x04\x06\t\x06\x04\x07" +
    "\t\x07\x04\b\t\b\x04\t\t\t\x04\n\t\n\x04\v\t\v\x04\f\t\f\x04\r\t\r\x04" +
    "\x0E\t\x0E\x04\x0F\t\x0F\x04\x10\t\x10\x04\x11\t\x11\x04\x12\t\x12\x04" +
    "\x13\t\x13\x04\x14\t\x14\x04\x15\t\x15\x04\x16\t\x16\x04\x17\t\x17\x04" +
    "\x18\t\x18\x04\x19\t\x19\x04\x1A\t\x1A\x04\x1B\t\x1B\x04\x1C\t\x1C\x04" +
    "\x1D\t\x1D\x04\x1E\t\x1E\x04\x1F\t\x1F\x04 \t \x04!\t!\x04\"\t\"\x04#" +
    "\t#\x04$\t$\x04%\t%\x04&\t&\x04\'\t\'\x04(\t(\x04)\t)\x04*\t*\x03\x02" +
    "\x03\x02\x03\x02\x03\x02\x03\x02\x03\x02\x03\x02\x07\x02\\\n\x02\f\x02" +
    "\x0E\x02_\v\x02\x03\x02\x05\x02b\n\x02\x03\x03\x03\x03\x03\x03\x07\x03" +
    "g\n\x03\f\x03\x0E\x03j\v\x03\x03\x03\x03\x03\x03\x04\x03\x04\x03\x04\x03" +
    "\x04\x03\x04\x05\x04s\n\x04\x03\x05\x03\x05\x03\x05\x03\x05\x05\x05y\n" +
    "\x05\x03\x05\x03\x05\x05\x05}\n\x05\x06\x05\x7F\n\x05\r\x05\x0E\x05\x80" +
    "\x03\x05\x03\x05\x03\x06\x03\x06\x03\x06\x03\x06\x05\x06\x89\n\x06\x03" +
    "\x06\x03\x06\x05\x06\x8D\n\x06\x06\x06\x8F\n\x06\r\x06\x0E\x06\x90\x03" +
    "\x06\x03\x06\x03\x07\x03\x07\x03\x07\x06\x07\x98\n\x07\r\x07\x0E\x07\x99" +
    "\x03\x07\x03\x07\x03\b\x03\b\x03\b\x03\b\x03\t\x03\t\x03\t\x03\t\x03\n" +
    "\x03\n\x03\n\x03\n\x03\v\x03\v\x03\v\x03\v\x03\f\x03\f\x03\f\x03\f\x03" +
    "\f\x05\f\xB3\n\f\x03\f\x03\f\x05\f\xB7\n\f\x03\f\x03\f\x03\f\x05\f\xBC" +
    "\n\f\x03\f\x03\f\x03\r\x03\r\x03\r\x03\r\x03\x0E\x03\x0E\x03\x0E\x03\x0E" +
    "\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x05\x0F\xCC\n\x0F\x03\x0F\x03\x0F\x03" +
    "\x0F\x03\x0F\x07\x0F\xD2\n\x0F\f\x0F\x0E\x0F\xD5\v\x0F\x03\x0F\x03\x0F" +
    "\x05\x0F\xD9\n\x0F\x06\x0F\xDB\n\x0F\r\x0F\x0E\x0F\xDC\x03\x0F\x03\x0F" +
    "\x03\x10\x03\x10\x05\x10\xE3\n\x10\x03\x11\x03\x11\x03\x11\x03\x11\x03" +
    "\x11\x03\x11\x05\x11\xEB\n\x11\x03\x12\x03\x12\x03\x12\x03\x12\x03\x12" +
    "\x03\x12\x03\x13\x03\x13\x03\x13\x03\x13\x05\x13\xF7\n\x13\x03\x13\x03" +
    "\x13\x03\x13\x03\x13\x03\x13\x03\x13\x03\x14\x03\x14\x03\x14\x03\x14\x03" +
    "\x14\x03\x15\x03\x15\x03\x15\x03\x15\x03\x15\x03\x15\x03\x15\x03\x16\x03" +
    "\x16\x03\x17\x03\x17\x03\x17\x03\x17\x03\x17\x03\x17\x03\x17\x03\x18\x03" +
    "\x18\x03\x18\x03\x18\x03\x18\x03\x18\x03\x18\x03\x19\x03\x19\x03\x19\x03" +
    "\x19\x03\x19\x03\x19\x05\x19\u0121\n\x19\x03\x19\x03\x19\x03\x19\x03\x19" +
    "\x03\x19\x03\x19\x03\x19\x03\x19\x03\x19\x05\x19\u012C\n\x19\x03\x19\x03" +
    "\x19\x03\x19\x03\x19\x03\x19\x05\x19\u0133\n\x19\x03\x19\x03\x19\x05\x19" +
    "\u0137\n\x19\x03\x19\x03\x19\x03\x1A\x03\x1A\x03\x1A\x03\x1A\x03\x1A\x03" +
    "\x1B\x03\x1B\x03\x1B\x03\x1B\x03\x1B\x05\x1B\u0145\n\x1B\x03\x1C\x03\x1C" +
    "\x03\x1C\x03\x1C\x03\x1C\x05\x1C\u014C\n\x1C\x03\x1D\x03\x1D\x03\x1D\x03" +
    "\x1E\x03\x1E\x03\x1E\x03\x1F\x03\x1F\x03\x1F\x03 \x03 \x03 \x03!\x03!" +
    "\x03!\x03!\x03!\x03!\x03!\x03!\x03\"\x03\"\x03\"\x03\"\x03\"\x03\"\x05" +
    "\"\u0168\n\"\x03#\x03#\x03#\x03#\x03#\x05#\u016F\n#\x03$\x03$\x05$\u0173" +
    "\n$\x03%\x03%\x05%\u0177\n%\x03&\x03&\x05&\u017B\n&\x03\'\x03\'\x05\'" +
    "\u017F\n\'\x03(\x03(\x05(\u0183\n(\x03)\x06)\u0186\n)\r)\x0E)\u0187\x03" +
    "*\x06*\u018B\n*\r*\x0E*\u018C\x03*\x02\x02\x02+\x02\x02\x04\x02\x06\x02" +
    "\b\x02\n\x02\f\x02\x0E\x02\x10\x02\x12\x02\x14\x02\x16\x02\x18\x02\x1A" +
    "\x02\x1C\x02\x1E\x02 \x02\"\x02$\x02&\x02(\x02*\x02,\x02.\x020\x022\x02" +
    "4\x026\x028\x02:\x02<\x02>\x02@\x02B\x02D\x02F\x02H\x02J\x02L\x02N\x02" +
    "P\x02R\x02\x02\t\x03\x02\v\r\x03\x02\b\t\x03\x02\x12\x17\x04\x02,.01\x03" +
    "\x02$*\x03\x02,1\x03\x02EF\x02\u019B\x02a\x03\x02\x02\x02\x04c\x03\x02" +
    "\x02\x02\x06m\x03\x02\x02\x02\bt\x03\x02\x02\x02\n\x84\x03\x02\x02\x02" +
    "\f\x94\x03\x02\x02\x02\x0E\x9D\x03\x02\x02\x02\x10\xA1\x03\x02\x02\x02" +
    "\x12\xA5\x03\x02\x02\x02\x14\xA9\x03\x02\x02\x02\x16\xAD\x03\x02\x02\x02" +
    "\x18\xBF\x03\x02\x02\x02\x1A\xC3\x03\x02\x02\x02\x1C\xC7\x03\x02\x02\x02" +
    "\x1E\xE2\x03\x02\x02\x02 \xEA\x03\x02\x02\x02\"\xEC\x03\x02\x02\x02$\xF2" +
    "\x03\x02\x02\x02&\xFE\x03\x02\x02\x02(\u0103\x03\x02\x02\x02*\u010A\x03" +
    "\x02\x02\x02,\u010C\x03\x02\x02\x02.\u0113\x03\x02\x02\x020\u011A\x03" +
    "\x02\x02\x022\u013A\x03\x02\x02\x024\u0144\x03\x02\x02\x026\u014B\x03" +
    "\x02\x02\x028\u014D\x03\x02\x02\x02:\u0150\x03\x02\x02\x02<\u0153\x03" +
    "\x02\x02\x02>\u0156\x03\x02\x02\x02@\u0159\x03\x02\x02\x02B\u0161\x03" +
    "\x02\x02\x02D\u0169\x03\x02\x02\x02F\u0170\x03\x02\x02\x02H\u0174\x03" +
    "\x02\x02\x02J\u0178\x03\x02\x02\x02L\u017C\x03\x02\x02\x02N\u0180\x03" +
    "\x02\x02\x02P\u0185\x03\x02\x02\x02R\u018A\x03\x02\x02\x02TU\x07\x03\x02" +
    "\x02UV\x07F\x02\x02V]\x07;\x02\x02W\\\x05\x04\x03\x02X\\\x05\b\x05\x02" +
    "Y\\\x05\n\x06\x02Z\\\x05\f\x07\x02[W\x03\x02\x02\x02[X\x03\x02\x02\x02" +
    "[Y\x03\x02\x02\x02[Z\x03\x02\x02\x02\\_\x03\x02\x02\x02][\x03\x02\x02" +
    "\x02]^\x03\x02\x02\x02^`\x03\x02\x02\x02_]\x03\x02\x02\x02`b\x07<\x02" +
    "\x02aT\x03\x02\x02\x02ab\x03\x02\x02\x02b\x03\x03\x02\x02\x02cd\x07 \x02" +
    "\x02dh\x07;\x02\x02eg\x05\x06\x04\x02fe\x03\x02\x02\x02gj\x03\x02\x02" +
    "\x02hf\x03\x02\x02\x02hi\x03\x02\x02\x02ik\x03\x02\x02\x02jh\x03\x02\x02" +
    "\x02kl\x07<\x02\x02l\x05\x03\x02\x02\x02mn\x07F\x02\x02nr\x07@\x02\x02" +
    "os\x07E\x02\x02ps\x05R*\x02qs\x05 \x11\x02ro\x03\x02\x02\x02rp\x03\x02" +
    "\x02\x02rq\x03\x02\x02\x02s\x07\x03\x02\x02\x02tu\x07\x06\x02\x02u~\x07" +
    ";\x02\x02vx\x05\x0E\b\x02wy\x077\x02\x02xw\x03\x02\x02\x02xy\x03\x02\x02" +
    "\x02y\x7F\x03\x02\x02\x02z|\x05\x10\t\x02{}\x077\x02\x02|{\x03\x02\x02" +
    "\x02|}\x03\x02\x02\x02}\x7F\x03\x02\x02\x02~v\x03\x02\x02\x02~z\x03\x02" +
    "\x02\x02\x7F\x80\x03\x02\x02\x02\x80~\x03\x02\x02\x02\x80\x81\x03\x02" +
    "\x02\x02\x81\x82\x03\x02\x02\x02\x82\x83\x07<\x02\x02\x83\t\x03\x02\x02" +
    "\x02\x84\x85\x07\x07\x02\x02\x85\x8E\x07;\x02\x02\x86\x88\x05\x12\n\x02" +
    "\x87\x89\x077\x02\x02\x88\x87\x03\x02\x02\x02\x88\x89\x03\x02\x02\x02" +
    "\x89\x8F\x03\x02\x02\x02\x8A\x8C\x05\x14\v\x02\x8B\x8D\x077\x02\x02\x8C" +
    "\x8B\x03\x02\x02\x02\x8C\x8D\x03\x02\x02\x02\x8D\x8F\x03\x02\x02\x02\x8E" +
    "\x86\x03\x02\x02\x02\x8E\x8A\x03\x02\x02\x02\x8F\x90\x03\x02\x02\x02\x90" +
    "\x8E\x03\x02\x02\x02\x90\x91\x03\x02\x02\x02\x91\x92\x03\x02\x02\x02\x92" +
    "\x93\x07<\x02\x02\x93\v\x03\x02\x02\x02\x94\x95\x07\n\x02\x02\x95\x97" +
    "\x07;\x02\x02\x96\x98\x05\x16\f\x02\x97\x96\x03\x02\x02\x02\x98\x99\x03" +
    "\x02\x02\x02\x99\x97\x03\x02\x02\x02\x99\x9A\x03\x02\x02\x02\x9A\x9B\x03" +
    "\x02\x02\x02\x9B\x9C\x07<\x02\x02\x9C\r\x03\x02\x02\x02\x9D\x9E\x07\x04" +
    "\x02\x02\x9E\x9F\x07@\x02\x02\x9F\xA0\x05B\"\x02\xA0\x0F\x03\x02\x02\x02" +
    "\xA1\xA2\x07\x05\x02\x02\xA2\xA3\x07@\x02\x02\xA3\xA4\x05B\"\x02\xA4\x11" +
    "\x03\x02\x02\x02\xA5\xA6\x07\b\x02\x02\xA6\xA7\x07@\x02\x02\xA7\xA8\x07" +
    "E\x02\x02\xA8\x13\x03\x02\x02\x02\xA9\xAA\x07\t\x02\x02\xAA\xAB\x07@\x02" +
    "\x02\xAB\xAC\x07E\x02\x02\xAC\x15\x03\x02\x02\x02\xAD\xAE\t\x02\x02\x02" +
    "\xAE\xAF\x07F\x02\x02\xAF\xB0\x07;\x02\x02\xB0\xB2\x05\x18\r\x02\xB1\xB3" +
    "\x077\x02\x02\xB2\xB1\x03\x02\x02\x02\xB2\xB3\x03\x02\x02\x02\xB3\xB4" +
    "\x03\x02\x02\x02\xB4\xB6\x05\x1A\x0E\x02\xB5\xB7\x077\x02\x02\xB6\xB5" +
    "\x03\x02\x02\x02\xB6\xB7\x03\x02\x02\x02\xB7\xB8\x03\x02\x02\x02\xB8\xBB" +
    "\x05\x1C\x0F\x02\xB9\xBC\x05@!\x02\xBA\xBC\x07\x11\x02\x02\xBB\xB9\x03" +
    "\x02\x02\x02\xBB\xBA\x03\x02\x02\x02\xBB\xBC\x03\x02\x02\x02\xBC\xBD\x03" +
    "\x02\x02\x02\xBD\xBE\x07<\x02\x02\xBE\x17\x03\x02\x02\x02\xBF\xC0\x07" +
    "\x0E\x02\x02\xC0\xC1\x07@\x02\x02\xC1\xC2\t\x03\x02\x02\xC2\x19\x03\x02" +
    "\x02\x02\xC3\xC4\x07\x0F\x02\x02\xC4\xC5\x07@\x02\x02\xC5\xC6\t\x04\x02" +
    "\x02\xC6\x1B\x03\x02\x02\x02\xC7\xC8\x07+\x02\x02\xC8\xDA\x07;\x02\x02" +
    "\xC9\xCB\x05\x1E\x10\x02\xCA\xCC\x077\x02\x02\xCB\xCA\x03\x02\x02\x02" +
    "\xCB\xCC\x03\x02\x02\x02\xCC\xDB\x03\x02\x02\x02\xCD\xCE\x079\x02\x02" +
    "\xCE\xD3\x05 \x11\x02\xCF\xD0\x07#\x02\x02\xD0\xD2\x05\x1E\x10\x02\xD1" +
    "\xCF\x03\x02\x02\x02\xD2\xD5\x03\x02\x02\x02\xD3\xD1\x03\x02\x02\x02\xD3" +
    "\xD4\x03\x02\x02\x02\xD4\xD6\x03\x02\x02\x02\xD5\xD3\x03\x02\x02\x02\xD6" +
    "\xD8\x07:\x02\x02\xD7\xD9\x077\x02\x02\xD8\xD7\x03\x02\x02\x02\xD8\xD9" +
    "\x03\x02\x02\x02\xD9\xDB\x03\x02\x02\x02\xDA\xC9\x03\x02\x02\x02\xDA\xCD" +
    "\x03\x02\x02\x02\xDB\xDC\x03\x02\x02\x02\xDC\xDA\x03\x02\x02\x02\xDC\xDD" +
    "\x03\x02\x02\x02\xDD\xDE\x03\x02\x02\x02\xDE\xDF\x07<\x02\x02\xDF\x1D" +
    "\x03\x02\x02\x02\xE0\xE3\x05 \x11\x02\xE1\xE3\x05$\x13\x02\xE2\xE0\x03" +
    "\x02\x02\x02\xE2\xE1\x03\x02\x02\x02\xE3\x1F\x03\x02\x02\x02\xE4\xEB\x05" +
    ".\x18\x02\xE5\xEB\x050\x19\x02\xE6\xEB\x05,\x17\x02\xE7\xEB\x05(\x15\x02" +
    "\xE8\xEB\x05&\x14\x02\xE9\xEB\x05\"\x12\x02\xEA\xE4\x03\x02\x02\x02\xEA" +
    "\xE5\x03\x02\x02\x02\xEA\xE6\x03\x02\x02\x02\xEA\xE7\x03\x02\x02\x02\xEA" +
    "\xE8\x03\x02\x02\x02\xEA\xE9\x03\x02\x02\x02\xEB!\x03\x02\x02\x02\xEC" +
    "\xED\x07\x1E\x02\x02\xED\xEE\x079\x02\x02\xEE\xEF\x05R*\x02\xEF\xF0\t" +
    "\x05\x02\x02\xF0\xF1\x07:\x02\x02\xF1#\x03\x02\x02\x02\xF2\xF3\x072\x02" +
    "\x02\xF3\xF6\x079\x02\x02\xF4\xF7\x05\x1E\x10\x02\xF5\xF7\x07F\x02\x02" +
    "\xF6\xF4\x03\x02\x02\x02\xF6\xF5\x03\x02\x02\x02\xF7\xF8\x03\x02\x02\x02" +
    "\xF8\xF9\x07:\x02\x02\xF9\xFA\x073\x02\x02\xFA\xFB\x07;\x02\x02\xFB\xFC" +
    "\x05\x1E\x10\x02\xFC\xFD\x07<\x02\x02\xFD%\x03\x02\x02\x02\xFE\xFF\x07" +
    "\x1C\x02\x02\xFF\u0100\x079\x02\x02\u0100\u0101\x05R*\x02\u0101\u0102" +
    "\x07:\x02\x02\u0102\'\x03\x02\x02\x02\u0103\u0104\x07\x1D\x02\x02\u0104" +
    "\u0105\x079\x02\x02\u0105\u0106\x05D#\x02\u0106\u0107\x07\"\x02\x02\u0107" +
    "\u0108\x05D#\x02\u0108\u0109\x07:\x02\x02\u0109)\x03\x02\x02\x02\u010A" +
    "\u010B\t\x06\x02\x02\u010B+\x03\x02\x02\x02\u010C\u010D\x07\x1F\x02\x02" +
    "\u010D\u010E\x079\x02\x02\u010E\u010F\x05*\x16\x02\u010F\u0110\x07\"\x02" +
    "\x02\u0110\u0111\x05*\x16\x02\u0111\u0112\x07:\x02\x02\u0112-\x03\x02" +
    "\x02\x02\u0113\u0114\x07\x19\x02\x02\u0114\u0115\x079\x02\x02\u0115\u0116" +
    "\x05R*\x02\u0116\u0117\x07!\x02\x02\u0117\u0118\t\x07\x02\x02\u0118\u0119" +
    "\x07:\x02\x02\u0119/\x03\x02\x02\x02\u011A\u011B\x07\x1A\x02\x02\u011B" +
    "\u0136\x079\x02\x02\u011C\u0137\x052\x1A\x02\u011D\u0120\x052\x1A\x02" +
    "\u011E\u0121\x058\x1D\x02\u011F\u0121\x05:\x1E\x02\u0120\u011E\x03\x02" +
    "\x02\x02\u0120\u011F\x03\x02\x02\x02\u0121\u0122\x03\x02\x02\x02\u0122" +
    "\u0123\x052\x1A\x02\u0123\u0137\x03\x02\x02\x02\u0124\u012B\x054\x1B\x02" +
    "\u0125\u012C\x058\x1D\x02\u0126\u012C\x05:\x1E\x02\u0127\u012C\x05<\x1F" +
    "\x02\u0128\u012C\x05> \x02\u0129\u012C\x07B\x02\x02\u012A\u012C\x07C\x02" +
    "\x02\u012B\u0125\x03\x02\x02\x02\u012B\u0126\x03\x02\x02\x02\u012B\u0127" +
    "\x03\x02\x02\x02\u012B\u0128\x03\x02\x02\x02\u012B\u0129\x03\x02\x02\x02" +
    "\u012B\u012A\x03\x02\x02\x02\u012C\u012D\x03\x02\x02\x02\u012D\u012E\x05" +
    "4\x1B\x02\u012E\u0137\x03\x02\x02\x02\u012F\u0132\x056\x1C\x02\u0130\u0133" +
    "\x058\x1D\x02\u0131\u0133\x05:\x1E\x02\u0132\u0130\x03\x02\x02\x02\u0132" +
    "\u0131\x03\x02\x02\x02\u0133\u0134\x03\x02\x02\x02\u0134\u0135\x056\x1C" +
    "\x02\u0135\u0137\x03\x02\x02\x02\u0136\u011C\x03\x02\x02\x02\u0136\u011D" +
    "\x03\x02\x02\x02\u0136\u0124\x03\x02\x02\x02\u0136\u012F\x03\x02\x02\x02" +
    "\u0137\u0138\x03\x02\x02\x02\u0138\u0139\x07:\x02\x02\u01391\x03\x02\x02" +
    "\x02\u013A\u013B\x076\x02\x02\u013B\u013C\x079\x02\x02\u013C\u013D\t\b" +
    "\x02\x02\u013D\u013E\x07:\x02\x02\u013E3\x03\x02\x02\x02\u013F\u0140\x07" +
    "5\x02\x02\u0140\u0141\x079\x02\x02\u0141\u0142\t\b\x02\x02\u0142\u0145" +
    "\x07:\x02\x02\u0143\u0145\x05R*\x02\u0144\u013F\x03\x02\x02\x02\u0144" +
    "\u0143\x03\x02\x02\x02\u01455\x03\x02\x02\x02\u0146\u0147\x074\x02\x02" +
    "\u0147\u0148\x079\x02\x02\u0148\u0149\t\b\x02\x02\u0149\u014C\x07:\x02" +
    "\x02\u014A\u014C\x07E\x02\x02\u014B\u0146\x03\x02\x02\x02\u014B\u014A" +
    "\x03\x02\x02\x02\u014C7\x03\x02\x02\x02\u014D\u014E\x07@\x02\x02\u014E" +
    "\u014F\x07@\x02\x02\u014F9\x03\x02\x02\x02\u0150\u0151\x07A\x02\x02\u0151" +
    "\u0152\x07@\x02\x02\u0152;\x03\x02\x02\x02\u0153\u0154\x07B\x02\x02\u0154" +
    "\u0155\x07@\x02\x02\u0155=\x03\x02\x02\x02\u0156\u0157\x07C\x02\x02\u0157" +
    "\u0158\x07@\x02\x02\u0158?\x03\x02\x02\x02\u0159\u015A\x07\x10\x02\x02" +
    "\u015A\u015B\x079\x02\x02\u015B\u015C\x07\x1B\x02\x02\u015C\u015D\x07" +
    "9\x02\x02\u015D\u015E\x07E\x02\x02\u015E\u015F\x07:\x02\x02\u015F\u0160" +
    "\x07:\x02\x02\u0160A\x03\x02\x02\x02\u0161\u0162\x05P)\x02\u0162\u0163" +
    "\x07?\x02\x02\u0163\u0164\x05N(\x02\u0164\u0165\x07?\x02\x02\u0165\u0167" +
    "\x05L\'\x02\u0166\u0168\x05D#\x02\u0167\u0166\x03\x02\x02\x02\u0167\u0168" +
    "\x03\x02\x02\x02\u0168C\x03\x02\x02\x02\u0169\u016A\x05J&\x02\u016A\u016B" +
    "\x07=\x02\x02\u016B\u016E\x05H%\x02\u016C\u016D\x07=\x02\x02\u016D\u016F" +
    "\x05F$\x02\u016E\u016C\x03\x02\x02\x02\u016E\u016F\x03\x02\x02\x02\u016F" +
    "E\x03\x02\x02\x02\u0170\u0172\x07G\x02\x02\u0171\u0173\x07G\x02\x02\u0172" +
    "\u0171\x03\x02\x02\x02\u0172\u0173\x03\x02\x02\x02\u0173G\x03\x02\x02" +
    "\x02\u0174\u0176\x07G\x02\x02\u0175\u0177\x07G\x02\x02\u0176\u0175\x03" +
    "\x02\x02\x02\u0176\u0177\x03\x02\x02\x02\u0177I\x03\x02\x02\x02\u0178" +
    "\u017A\x07G\x02\x02\u0179\u017B\x07G\x02\x02\u017A\u0179\x03\x02\x02\x02" +
    "\u017A\u017B\x03\x02\x02\x02\u017BK\x03\x02\x02\x02\u017C\u017E\x07G\x02" +
    "\x02\u017D\u017F\x07G\x02\x02\u017E\u017D\x03\x02\x02\x02\u017E\u017F" +
    "\x03\x02\x02\x02\u017FM\x03\x02\x02\x02\u0180\u0182\x07G\x02\x02\u0181" +
    "\u0183\x07G\x02\x02\u0182\u0181\x03\x02\x02\x02\u0182\u0183\x03\x02\x02" +
    "\x02\u0183O\x03\x02\x02\x02\u0184\u0186\x07G\x02\x02\u0185\u0184\x03\x02" +
    "\x02\x02\u0186\u0187\x03\x02\x02\x02\u0187\u0185\x03\x02\x02\x02\u0187" +
    "\u0188\x03\x02\x02\x02\u0188Q\x03\x02\x02\x02\u0189\u018B\x07G\x02\x02" +
    "\u018A\u0189\x03\x02\x02\x02\u018B\u018C\x03\x02\x02\x02\u018C\u018A\x03" +
    "\x02\x02\x02\u018C\u018D\x03\x02\x02\x02\u018DS\x03\x02\x02\x02*[]ahr" +
    "x|~\x80\x88\x8C\x8E\x90\x99\xB2\xB6\xBB\xCB\xD3\xD8\xDA\xDC\xE2\xEA\xF6" +
    "\u0120\u012B\u0132\u0136\u0144\u014B\u0167\u016E\u0172\u0176\u017A\u017E" +
    "\u0182\u0187\u018C";
class ContractContext extends ParserRuleContext_1.ParserRuleContext {
    Contract() { return this.tryGetToken(JabutiGrammarParser.Contract, 0); }
    ID() { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
    OpenBrace() { return this.tryGetToken(JabutiGrammarParser.OpenBrace, 0); }
    CloseBrace() { return this.tryGetToken(JabutiGrammarParser.CloseBrace, 0); }
    variables(i) {
        if (i === undefined) {
            return this.getRuleContexts(VariablesContext);
        }
        else {
            return this.getRuleContext(i, VariablesContext);
        }
    }
    dates(i) {
        if (i === undefined) {
            return this.getRuleContexts(DatesContext);
        }
        else {
            return this.getRuleContext(i, DatesContext);
        }
    }
    parties(i) {
        if (i === undefined) {
            return this.getRuleContexts(PartiesContext);
        }
        else {
            return this.getRuleContext(i, PartiesContext);
        }
    }
    clauses(i) {
        if (i === undefined) {
            return this.getRuleContexts(ClausesContext);
        }
        else {
            return this.getRuleContext(i, ClausesContext);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_contract; }
    // @Override
    enterRule(listener) {
        if (listener.enterContract) {
            listener.enterContract(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitContract) {
            listener.exitContract(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitContract) {
            return visitor.visitContract(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.ContractContext = ContractContext;
class VariablesContext extends ParserRuleContext_1.ParserRuleContext {
    Variables() { return this.getToken(JabutiGrammarParser.Variables, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    variableStatement(i) {
        if (i === undefined) {
            return this.getRuleContexts(VariableStatementContext);
        }
        else {
            return this.getRuleContext(i, VariableStatementContext);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_variables; }
    // @Override
    enterRule(listener) {
        if (listener.enterVariables) {
            listener.enterVariables(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitVariables) {
            listener.exitVariables(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitVariables) {
            return visitor.visitVariables(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.VariablesContext = VariablesContext;
class VariableStatementContext extends ParserRuleContext_1.ParserRuleContext {
    ID() { return this.getToken(JabutiGrammarParser.ID, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    String() { return this.tryGetToken(JabutiGrammarParser.String, 0); }
    digit() {
        return this.tryGetRuleContext(0, DigitContext);
    }
    term() {
        return this.tryGetRuleContext(0, TermContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_variableStatement; }
    // @Override
    enterRule(listener) {
        if (listener.enterVariableStatement) {
            listener.enterVariableStatement(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitVariableStatement) {
            listener.exitVariableStatement(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitVariableStatement) {
            return visitor.visitVariableStatement(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.VariableStatementContext = VariableStatementContext;
class DatesContext extends ParserRuleContext_1.ParserRuleContext {
    Dates() { return this.getToken(JabutiGrammarParser.Dates, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    beginDate(i) {
        if (i === undefined) {
            return this.getRuleContexts(BeginDateContext);
        }
        else {
            return this.getRuleContext(i, BeginDateContext);
        }
    }
    dueDate(i) {
        if (i === undefined) {
            return this.getRuleContexts(DueDateContext);
        }
        else {
            return this.getRuleContext(i, DueDateContext);
        }
    }
    Comma(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Comma);
        }
        else {
            return this.getToken(JabutiGrammarParser.Comma, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_dates; }
    // @Override
    enterRule(listener) {
        if (listener.enterDates) {
            listener.enterDates(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitDates) {
            listener.exitDates(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitDates) {
            return visitor.visitDates(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.DatesContext = DatesContext;
class PartiesContext extends ParserRuleContext_1.ParserRuleContext {
    Parties() { return this.getToken(JabutiGrammarParser.Parties, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    application(i) {
        if (i === undefined) {
            return this.getRuleContexts(ApplicationContext);
        }
        else {
            return this.getRuleContext(i, ApplicationContext);
        }
    }
    process(i) {
        if (i === undefined) {
            return this.getRuleContexts(ProcessContext);
        }
        else {
            return this.getRuleContext(i, ProcessContext);
        }
    }
    Comma(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Comma);
        }
        else {
            return this.getToken(JabutiGrammarParser.Comma, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_parties; }
    // @Override
    enterRule(listener) {
        if (listener.enterParties) {
            listener.enterParties(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitParties) {
            listener.exitParties(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitParties) {
            return visitor.visitParties(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.PartiesContext = PartiesContext;
class ClausesContext extends ParserRuleContext_1.ParserRuleContext {
    Clauses() { return this.getToken(JabutiGrammarParser.Clauses, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    clause(i) {
        if (i === undefined) {
            return this.getRuleContexts(ClauseContext);
        }
        else {
            return this.getRuleContext(i, ClauseContext);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_clauses; }
    // @Override
    enterRule(listener) {
        if (listener.enterClauses) {
            listener.enterClauses(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitClauses) {
            listener.exitClauses(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitClauses) {
            return visitor.visitClauses(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.ClausesContext = ClausesContext;
class BeginDateContext extends ParserRuleContext_1.ParserRuleContext {
    BeginDate() { return this.getToken(JabutiGrammarParser.BeginDate, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    datetime() {
        return this.getRuleContext(0, DatetimeContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_beginDate; }
    // @Override
    enterRule(listener) {
        if (listener.enterBeginDate) {
            listener.enterBeginDate(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitBeginDate) {
            listener.exitBeginDate(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitBeginDate) {
            return visitor.visitBeginDate(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.BeginDateContext = BeginDateContext;
class DueDateContext extends ParserRuleContext_1.ParserRuleContext {
    DueDate() { return this.getToken(JabutiGrammarParser.DueDate, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    datetime() {
        return this.getRuleContext(0, DatetimeContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_dueDate; }
    // @Override
    enterRule(listener) {
        if (listener.enterDueDate) {
            listener.enterDueDate(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitDueDate) {
            listener.exitDueDate(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitDueDate) {
            return visitor.visitDueDate(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.DueDateContext = DueDateContext;
class ApplicationContext extends ParserRuleContext_1.ParserRuleContext {
    Application() { return this.getToken(JabutiGrammarParser.Application, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    String() { return this.getToken(JabutiGrammarParser.String, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_application; }
    // @Override
    enterRule(listener) {
        if (listener.enterApplication) {
            listener.enterApplication(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitApplication) {
            listener.exitApplication(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitApplication) {
            return visitor.visitApplication(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.ApplicationContext = ApplicationContext;
class ProcessContext extends ParserRuleContext_1.ParserRuleContext {
    Process() { return this.getToken(JabutiGrammarParser.Process, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    String() { return this.getToken(JabutiGrammarParser.String, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_process; }
    // @Override
    enterRule(listener) {
        if (listener.enterProcess) {
            listener.enterProcess(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitProcess) {
            listener.exitProcess(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitProcess) {
            return visitor.visitProcess(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.ProcessContext = ProcessContext;
class ClauseContext extends ParserRuleContext_1.ParserRuleContext {
    ID() { return this.getToken(JabutiGrammarParser.ID, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    rolePlayer() {
        return this.getRuleContext(0, RolePlayerContext);
    }
    operation() {
        return this.getRuleContext(0, OperationContext);
    }
    terms() {
        return this.getRuleContext(0, TermsContext);
    }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    Right() { return this.tryGetToken(JabutiGrammarParser.Right, 0); }
    Prohibition() { return this.tryGetToken(JabutiGrammarParser.Prohibition, 0); }
    Obligation() { return this.tryGetToken(JabutiGrammarParser.Obligation, 0); }
    Comma(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Comma);
        }
        else {
            return this.getToken(JabutiGrammarParser.Comma, i);
        }
    }
    onBreach() {
        return this.tryGetRuleContext(0, OnBreachContext);
    }
    OnSuccess() { return this.tryGetToken(JabutiGrammarParser.OnSuccess, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_clause; }
    // @Override
    enterRule(listener) {
        if (listener.enterClause) {
            listener.enterClause(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitClause) {
            listener.exitClause(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitClause) {
            return visitor.visitClause(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.ClauseContext = ClauseContext;
class RolePlayerContext extends ParserRuleContext_1.ParserRuleContext {
    RolePlayer() { return this.getToken(JabutiGrammarParser.RolePlayer, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    Process() { return this.tryGetToken(JabutiGrammarParser.Process, 0); }
    Application() { return this.tryGetToken(JabutiGrammarParser.Application, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_rolePlayer; }
    // @Override
    enterRule(listener) {
        if (listener.enterRolePlayer) {
            listener.enterRolePlayer(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitRolePlayer) {
            listener.exitRolePlayer(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitRolePlayer) {
            return visitor.visitRolePlayer(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.RolePlayerContext = RolePlayerContext;
class OperationContext extends ParserRuleContext_1.ParserRuleContext {
    Operation() { return this.getToken(JabutiGrammarParser.Operation, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    Push() { return this.tryGetToken(JabutiGrammarParser.Push, 0); }
    Poll() { return this.tryGetToken(JabutiGrammarParser.Poll, 0); }
    Read() { return this.tryGetToken(JabutiGrammarParser.Read, 0); }
    Write() { return this.tryGetToken(JabutiGrammarParser.Write, 0); }
    Request() { return this.tryGetToken(JabutiGrammarParser.Request, 0); }
    Response() { return this.tryGetToken(JabutiGrammarParser.Response, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_operation; }
    // @Override
    enterRule(listener) {
        if (listener.enterOperation) {
            listener.enterOperation(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitOperation) {
            listener.exitOperation(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitOperation) {
            return visitor.visitOperation(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.OperationContext = OperationContext;
class TermsContext extends ParserRuleContext_1.ParserRuleContext {
    Terms() { return this.getToken(JabutiGrammarParser.Terms, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    OpenParen(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.OpenParen);
        }
        else {
            return this.getToken(JabutiGrammarParser.OpenParen, i);
        }
    }
    term(i) {
        if (i === undefined) {
            return this.getRuleContexts(TermContext);
        }
        else {
            return this.getRuleContext(i, TermContext);
        }
    }
    CloseParen(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.CloseParen);
        }
        else {
            return this.getToken(JabutiGrammarParser.CloseParen, i);
        }
    }
    termOrWhen(i) {
        if (i === undefined) {
            return this.getRuleContexts(TermOrWhenContext);
        }
        else {
            return this.getRuleContext(i, TermOrWhenContext);
        }
    }
    Comma(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Comma);
        }
        else {
            return this.getToken(JabutiGrammarParser.Comma, i);
        }
    }
    Or(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Or);
        }
        else {
            return this.getToken(JabutiGrammarParser.Or, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_terms; }
    // @Override
    enterRule(listener) {
        if (listener.enterTerms) {
            listener.enterTerms(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitTerms) {
            listener.exitTerms(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitTerms) {
            return visitor.visitTerms(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.TermsContext = TermsContext;
class TermOrWhenContext extends ParserRuleContext_1.ParserRuleContext {
    term() {
        return this.tryGetRuleContext(0, TermContext);
    }
    when() {
        return this.tryGetRuleContext(0, WhenContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_termOrWhen; }
    // @Override
    enterRule(listener) {
        if (listener.enterTermOrWhen) {
            listener.enterTermOrWhen(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitTermOrWhen) {
            listener.exitTermOrWhen(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitTermOrWhen) {
            return visitor.visitTermOrWhen(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.TermOrWhenContext = TermOrWhenContext;
class TermContext extends ParserRuleContext_1.ParserRuleContext {
    maxNumberOfOperation() {
        return this.tryGetRuleContext(0, MaxNumberOfOperationContext);
    }
    messageContent() {
        return this.tryGetRuleContext(0, MessageContentContext);
    }
    weekDaysInterval() {
        return this.tryGetRuleContext(0, WeekDaysIntervalContext);
    }
    timeInterval() {
        return this.tryGetRuleContext(0, TimeIntervalContext);
    }
    timeout() {
        return this.tryGetRuleContext(0, TimeoutContext);
    }
    sessionInterval() {
        return this.tryGetRuleContext(0, SessionIntervalContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_term; }
    // @Override
    enterRule(listener) {
        if (listener.enterTerm) {
            listener.enterTerm(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitTerm) {
            listener.exitTerm(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitTerm) {
            return visitor.visitTerm(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.TermContext = TermContext;
class SessionIntervalContext extends ParserRuleContext_1.ParserRuleContext {
    SessionInterval() { return this.getToken(JabutiGrammarParser.SessionInterval, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    digit() {
        return this.getRuleContext(0, DigitContext);
    }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    Second() { return this.tryGetToken(JabutiGrammarParser.Second, 0); }
    Minute() { return this.tryGetToken(JabutiGrammarParser.Minute, 0); }
    Day() { return this.tryGetToken(JabutiGrammarParser.Day, 0); }
    Week() { return this.tryGetToken(JabutiGrammarParser.Week, 0); }
    Month() { return this.tryGetToken(JabutiGrammarParser.Month, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_sessionInterval; }
    // @Override
    enterRule(listener) {
        if (listener.enterSessionInterval) {
            listener.enterSessionInterval(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitSessionInterval) {
            listener.exitSessionInterval(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitSessionInterval) {
            return visitor.visitSessionInterval(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.SessionIntervalContext = SessionIntervalContext;
class WhenContext extends ParserRuleContext_1.ParserRuleContext {
    When() { return this.getToken(JabutiGrammarParser.When, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    Do() { return this.getToken(JabutiGrammarParser.Do, 0); }
    OpenBrace() { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
    termOrWhen(i) {
        if (i === undefined) {
            return this.getRuleContexts(TermOrWhenContext);
        }
        else {
            return this.getRuleContext(i, TermOrWhenContext);
        }
    }
    CloseBrace() { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
    ID() { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_when; }
    // @Override
    enterRule(listener) {
        if (listener.enterWhen) {
            listener.enterWhen(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitWhen) {
            listener.exitWhen(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitWhen) {
            return visitor.visitWhen(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.WhenContext = WhenContext;
class TimeoutContext extends ParserRuleContext_1.ParserRuleContext {
    Timeout() { return this.getToken(JabutiGrammarParser.Timeout, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    digit() {
        return this.getRuleContext(0, DigitContext);
    }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_timeout; }
    // @Override
    enterRule(listener) {
        if (listener.enterTimeout) {
            listener.enterTimeout(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitTimeout) {
            listener.exitTimeout(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitTimeout) {
            return visitor.visitTimeout(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.TimeoutContext = TimeoutContext;
class TimeIntervalContext extends ParserRuleContext_1.ParserRuleContext {
    TimeInterval() { return this.getToken(JabutiGrammarParser.TimeInterval, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    time(i) {
        if (i === undefined) {
            return this.getRuleContexts(TimeContext);
        }
        else {
            return this.getRuleContext(i, TimeContext);
        }
    }
    To() { return this.getToken(JabutiGrammarParser.To, 0); }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_timeInterval; }
    // @Override
    enterRule(listener) {
        if (listener.enterTimeInterval) {
            listener.enterTimeInterval(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitTimeInterval) {
            listener.exitTimeInterval(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitTimeInterval) {
            return visitor.visitTimeInterval(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.TimeIntervalContext = TimeIntervalContext;
class WeekDaysContext extends ParserRuleContext_1.ParserRuleContext {
    Monday() { return this.tryGetToken(JabutiGrammarParser.Monday, 0); }
    Tuesday() { return this.tryGetToken(JabutiGrammarParser.Tuesday, 0); }
    Wednesday() { return this.tryGetToken(JabutiGrammarParser.Wednesday, 0); }
    Thursday() { return this.tryGetToken(JabutiGrammarParser.Thursday, 0); }
    Friday() { return this.tryGetToken(JabutiGrammarParser.Friday, 0); }
    Saturday() { return this.tryGetToken(JabutiGrammarParser.Saturday, 0); }
    Sunday() { return this.tryGetToken(JabutiGrammarParser.Sunday, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_weekDays; }
    // @Override
    enterRule(listener) {
        if (listener.enterWeekDays) {
            listener.enterWeekDays(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitWeekDays) {
            listener.exitWeekDays(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitWeekDays) {
            return visitor.visitWeekDays(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.WeekDaysContext = WeekDaysContext;
class WeekDaysIntervalContext extends ParserRuleContext_1.ParserRuleContext {
    WeekDaysInterval() { return this.getToken(JabutiGrammarParser.WeekDaysInterval, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    weekDays(i) {
        if (i === undefined) {
            return this.getRuleContexts(WeekDaysContext);
        }
        else {
            return this.getRuleContext(i, WeekDaysContext);
        }
    }
    To() { return this.getToken(JabutiGrammarParser.To, 0); }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_weekDaysInterval; }
    // @Override
    enterRule(listener) {
        if (listener.enterWeekDaysInterval) {
            listener.enterWeekDaysInterval(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitWeekDaysInterval) {
            listener.exitWeekDaysInterval(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitWeekDaysInterval) {
            return visitor.visitWeekDaysInterval(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.WeekDaysIntervalContext = WeekDaysIntervalContext;
class MaxNumberOfOperationContext extends ParserRuleContext_1.ParserRuleContext {
    MaxNumberOfOperation() { return this.getToken(JabutiGrammarParser.MaxNumberOfOperation, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    digit() {
        return this.getRuleContext(0, DigitContext);
    }
    Per() { return this.getToken(JabutiGrammarParser.Per, 0); }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    Second() { return this.tryGetToken(JabutiGrammarParser.Second, 0); }
    Hour() { return this.tryGetToken(JabutiGrammarParser.Hour, 0); }
    Minute() { return this.tryGetToken(JabutiGrammarParser.Minute, 0); }
    Day() { return this.tryGetToken(JabutiGrammarParser.Day, 0); }
    Week() { return this.tryGetToken(JabutiGrammarParser.Week, 0); }
    Month() { return this.tryGetToken(JabutiGrammarParser.Month, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_maxNumberOfOperation; }
    // @Override
    enterRule(listener) {
        if (listener.enterMaxNumberOfOperation) {
            listener.enterMaxNumberOfOperation(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMaxNumberOfOperation) {
            listener.exitMaxNumberOfOperation(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMaxNumberOfOperation) {
            return visitor.visitMaxNumberOfOperation(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MaxNumberOfOperationContext = MaxNumberOfOperationContext;
class MessageContentContext extends ParserRuleContext_1.ParserRuleContext {
    MessageContent() { return this.getToken(JabutiGrammarParser.MessageContent, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    messageContentBoolean(i) {
        if (i === undefined) {
            return this.getRuleContexts(MessageContentBooleanContext);
        }
        else {
            return this.getRuleContext(i, MessageContentBooleanContext);
        }
    }
    equal() {
        return this.tryGetRuleContext(0, EqualContext);
    }
    notEqual() {
        return this.tryGetRuleContext(0, NotEqualContext);
    }
    messageContentNumeric(i) {
        if (i === undefined) {
            return this.getRuleContexts(MessageContentNumericContext);
        }
        else {
            return this.getRuleContext(i, MessageContentNumericContext);
        }
    }
    greaterThan() {
        return this.tryGetRuleContext(0, GreaterThanContext);
    }
    lassThan() {
        return this.tryGetRuleContext(0, LassThanContext);
    }
    Greater() { return this.tryGetToken(JabutiGrammarParser.Greater, 0); }
    Lass() { return this.tryGetToken(JabutiGrammarParser.Lass, 0); }
    messageContentText(i) {
        if (i === undefined) {
            return this.getRuleContexts(MessageContentTextContext);
        }
        else {
            return this.getRuleContext(i, MessageContentTextContext);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_messageContent; }
    // @Override
    enterRule(listener) {
        if (listener.enterMessageContent) {
            listener.enterMessageContent(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMessageContent) {
            listener.exitMessageContent(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMessageContent) {
            return visitor.visitMessageContent(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MessageContentContext = MessageContentContext;
class MessageContentBooleanContext extends ParserRuleContext_1.ParserRuleContext {
    Boolean() { return this.getToken(JabutiGrammarParser.Boolean, 0); }
    OpenParen() { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
    CloseParen() { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
    ID() { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
    String() { return this.tryGetToken(JabutiGrammarParser.String, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_messageContentBoolean; }
    // @Override
    enterRule(listener) {
        if (listener.enterMessageContentBoolean) {
            listener.enterMessageContentBoolean(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMessageContentBoolean) {
            listener.exitMessageContentBoolean(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMessageContentBoolean) {
            return visitor.visitMessageContentBoolean(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MessageContentBooleanContext = MessageContentBooleanContext;
class MessageContentNumericContext extends ParserRuleContext_1.ParserRuleContext {
    Numeric() { return this.tryGetToken(JabutiGrammarParser.Numeric, 0); }
    OpenParen() { return this.tryGetToken(JabutiGrammarParser.OpenParen, 0); }
    CloseParen() { return this.tryGetToken(JabutiGrammarParser.CloseParen, 0); }
    digit() {
        return this.tryGetRuleContext(0, DigitContext);
    }
    ID() { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
    String() { return this.tryGetToken(JabutiGrammarParser.String, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_messageContentNumeric; }
    // @Override
    enterRule(listener) {
        if (listener.enterMessageContentNumeric) {
            listener.enterMessageContentNumeric(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMessageContentNumeric) {
            listener.exitMessageContentNumeric(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMessageContentNumeric) {
            return visitor.visitMessageContentNumeric(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MessageContentNumericContext = MessageContentNumericContext;
class MessageContentTextContext extends ParserRuleContext_1.ParserRuleContext {
    Text() { return this.tryGetToken(JabutiGrammarParser.Text, 0); }
    OpenParen() { return this.tryGetToken(JabutiGrammarParser.OpenParen, 0); }
    CloseParen() { return this.tryGetToken(JabutiGrammarParser.CloseParen, 0); }
    String() { return this.tryGetToken(JabutiGrammarParser.String, 0); }
    ID() { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_messageContentText; }
    // @Override
    enterRule(listener) {
        if (listener.enterMessageContentText) {
            listener.enterMessageContentText(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMessageContentText) {
            listener.exitMessageContentText(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMessageContentText) {
            return visitor.visitMessageContentText(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MessageContentTextContext = MessageContentTextContext;
class EqualContext extends ParserRuleContext_1.ParserRuleContext {
    Assign(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Assign);
        }
        else {
            return this.getToken(JabutiGrammarParser.Assign, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_equal; }
    // @Override
    enterRule(listener) {
        if (listener.enterEqual) {
            listener.enterEqual(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitEqual) {
            listener.exitEqual(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitEqual) {
            return visitor.visitEqual(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.EqualContext = EqualContext;
class NotEqualContext extends ParserRuleContext_1.ParserRuleContext {
    Exclamation() { return this.getToken(JabutiGrammarParser.Exclamation, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_notEqual; }
    // @Override
    enterRule(listener) {
        if (listener.enterNotEqual) {
            listener.enterNotEqual(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitNotEqual) {
            listener.exitNotEqual(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitNotEqual) {
            return visitor.visitNotEqual(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.NotEqualContext = NotEqualContext;
class GreaterThanContext extends ParserRuleContext_1.ParserRuleContext {
    Greater() { return this.getToken(JabutiGrammarParser.Greater, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_greaterThan; }
    // @Override
    enterRule(listener) {
        if (listener.enterGreaterThan) {
            listener.enterGreaterThan(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitGreaterThan) {
            listener.exitGreaterThan(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitGreaterThan) {
            return visitor.visitGreaterThan(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.GreaterThanContext = GreaterThanContext;
class LassThanContext extends ParserRuleContext_1.ParserRuleContext {
    Lass() { return this.getToken(JabutiGrammarParser.Lass, 0); }
    Assign() { return this.getToken(JabutiGrammarParser.Assign, 0); }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_lassThan; }
    // @Override
    enterRule(listener) {
        if (listener.enterLassThan) {
            listener.enterLassThan(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitLassThan) {
            listener.exitLassThan(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitLassThan) {
            return visitor.visitLassThan(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.LassThanContext = LassThanContext;
class OnBreachContext extends ParserRuleContext_1.ParserRuleContext {
    OnBreach() { return this.getToken(JabutiGrammarParser.OnBreach, 0); }
    OpenParen(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.OpenParen);
        }
        else {
            return this.getToken(JabutiGrammarParser.OpenParen, i);
        }
    }
    Log() { return this.getToken(JabutiGrammarParser.Log, 0); }
    String() { return this.getToken(JabutiGrammarParser.String, 0); }
    CloseParen(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.CloseParen);
        }
        else {
            return this.getToken(JabutiGrammarParser.CloseParen, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_onBreach; }
    // @Override
    enterRule(listener) {
        if (listener.enterOnBreach) {
            listener.enterOnBreach(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitOnBreach) {
            listener.exitOnBreach(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitOnBreach) {
            return visitor.visitOnBreach(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.OnBreachContext = OnBreachContext;
class DatetimeContext extends ParserRuleContext_1.ParserRuleContext {
    year() {
        return this.getRuleContext(0, YearContext);
    }
    Minus(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Minus);
        }
        else {
            return this.getToken(JabutiGrammarParser.Minus, i);
        }
    }
    month() {
        return this.getRuleContext(0, MonthContext);
    }
    day() {
        return this.getRuleContext(0, DayContext);
    }
    time() {
        return this.tryGetRuleContext(0, TimeContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_datetime; }
    // @Override
    enterRule(listener) {
        if (listener.enterDatetime) {
            listener.enterDatetime(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitDatetime) {
            listener.exitDatetime(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitDatetime) {
            return visitor.visitDatetime(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.DatetimeContext = DatetimeContext;
class TimeContext extends ParserRuleContext_1.ParserRuleContext {
    hour() {
        return this.getRuleContext(0, HourContext);
    }
    Colon(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Colon);
        }
        else {
            return this.getToken(JabutiGrammarParser.Colon, i);
        }
    }
    minute() {
        return this.getRuleContext(0, MinuteContext);
    }
    second() {
        return this.tryGetRuleContext(0, SecondContext);
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_time; }
    // @Override
    enterRule(listener) {
        if (listener.enterTime) {
            listener.enterTime(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitTime) {
            listener.exitTime(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitTime) {
            return visitor.visitTime(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.TimeContext = TimeContext;
class SecondContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_second; }
    // @Override
    enterRule(listener) {
        if (listener.enterSecond) {
            listener.enterSecond(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitSecond) {
            listener.exitSecond(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitSecond) {
            return visitor.visitSecond(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.SecondContext = SecondContext;
class MinuteContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_minute; }
    // @Override
    enterRule(listener) {
        if (listener.enterMinute) {
            listener.enterMinute(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMinute) {
            listener.exitMinute(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMinute) {
            return visitor.visitMinute(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MinuteContext = MinuteContext;
class HourContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_hour; }
    // @Override
    enterRule(listener) {
        if (listener.enterHour) {
            listener.enterHour(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitHour) {
            listener.exitHour(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitHour) {
            return visitor.visitHour(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.HourContext = HourContext;
class DayContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_day; }
    // @Override
    enterRule(listener) {
        if (listener.enterDay) {
            listener.enterDay(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitDay) {
            listener.exitDay(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitDay) {
            return visitor.visitDay(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.DayContext = DayContext;
class MonthContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_month; }
    // @Override
    enterRule(listener) {
        if (listener.enterMonth) {
            listener.enterMonth(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitMonth) {
            listener.exitMonth(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitMonth) {
            return visitor.visitMonth(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.MonthContext = MonthContext;
class YearContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_year; }
    // @Override
    enterRule(listener) {
        if (listener.enterYear) {
            listener.enterYear(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitYear) {
            listener.exitYear(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitYear) {
            return visitor.visitYear(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.YearContext = YearContext;
class DigitContext extends ParserRuleContext_1.ParserRuleContext {
    Digit(i) {
        if (i === undefined) {
            return this.getTokens(JabutiGrammarParser.Digit);
        }
        else {
            return this.getToken(JabutiGrammarParser.Digit, i);
        }
    }
    constructor(parent, invokingState) {
        super(parent, invokingState);
    }
    // @Override
    get ruleIndex() { return JabutiGrammarParser.RULE_digit; }
    // @Override
    enterRule(listener) {
        if (listener.enterDigit) {
            listener.enterDigit(this);
        }
    }
    // @Override
    exitRule(listener) {
        if (listener.exitDigit) {
            listener.exitDigit(this);
        }
    }
    // @Override
    accept(visitor) {
        if (visitor.visitDigit) {
            return visitor.visitDigit(this);
        }
        else {
            return visitor.visitChildren(this);
        }
    }
}
exports.DigitContext = DigitContext;
