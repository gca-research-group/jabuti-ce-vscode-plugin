// Generated from ./JabutiGrammar.g4 by ANTLR 4.9.0-SNAPSHOT


import { ATN } from "antlr4ts/atn/ATN";
import { ATNDeserializer } from "antlr4ts/atn/ATNDeserializer";
import { FailedPredicateException } from "antlr4ts/FailedPredicateException";
import { NotNull } from "antlr4ts/Decorators";
import { NoViableAltException } from "antlr4ts/NoViableAltException";
import { Override } from "antlr4ts/Decorators";
import { Parser } from "antlr4ts/Parser";
import { ParserRuleContext } from "antlr4ts/ParserRuleContext";
import { ParserATNSimulator } from "antlr4ts/atn/ParserATNSimulator";
import { ParseTreeListener } from "antlr4ts/tree/ParseTreeListener";
import { ParseTreeVisitor } from "antlr4ts/tree/ParseTreeVisitor";
import { RecognitionException } from "antlr4ts/RecognitionException";
import { RuleContext } from "antlr4ts/RuleContext";
//import { RuleVersion } from "antlr4ts/RuleVersion";
import { TerminalNode } from "antlr4ts/tree/TerminalNode";
import { Token } from "antlr4ts/Token";
import { TokenStream } from "antlr4ts/TokenStream";
import { Vocabulary } from "antlr4ts/Vocabulary";
import { VocabularyImpl } from "antlr4ts/VocabularyImpl";

import * as Utils from "antlr4ts/misc/Utils";

import { JabutiGrammarListener } from "./JabutiGrammarListener";
import { JabutiGrammarVisitor } from "./JabutiGrammarVisitor";


export class JabutiGrammarParser extends Parser {
	public static readonly Contract = 1;
	public static readonly BeginDate = 2;
	public static readonly DueDate = 3;
	public static readonly Dates = 4;
	public static readonly Parties = 5;
	public static readonly Application = 6;
	public static readonly Process = 7;
	public static readonly Clauses = 8;
	public static readonly Right = 9;
	public static readonly Prohibition = 10;
	public static readonly Obligation = 11;
	public static readonly RolePlayer = 12;
	public static readonly Operation = 13;
	public static readonly OnBreach = 14;
	public static readonly OnSuccess = 15;
	public static readonly Push = 16;
	public static readonly Poll = 17;
	public static readonly Read = 18;
	public static readonly Write = 19;
	public static readonly Request = 20;
	public static readonly Response = 21;
	public static readonly Condition = 22;
	public static readonly MaxNumberOfOperation = 23;
	public static readonly MessageContent = 24;
	public static readonly Log = 25;
	public static readonly Timeout = 26;
	public static readonly TimeInterval = 27;
	public static readonly SessionInterval = 28;
	public static readonly WeekDaysInterval = 29;
	public static readonly Variables = 30;
	public static readonly Per = 31;
	public static readonly To = 32;
	public static readonly Or = 33;
	public static readonly Monday = 34;
	public static readonly Tuesday = 35;
	public static readonly Wednesday = 36;
	public static readonly Thursday = 37;
	public static readonly Friday = 38;
	public static readonly Saturday = 39;
	public static readonly Sunday = 40;
	public static readonly Terms = 41;
	public static readonly Month = 42;
	public static readonly Week = 43;
	public static readonly Day = 44;
	public static readonly Hour = 45;
	public static readonly Minute = 46;
	public static readonly Second = 47;
	public static readonly When = 48;
	public static readonly Do = 49;
	public static readonly Text = 50;
	public static readonly Numeric = 51;
	public static readonly Boolean = 52;
	public static readonly Comma = 53;
	public static readonly SemiColon = 54;
	public static readonly OpenParen = 55;
	public static readonly CloseParen = 56;
	public static readonly OpenBrace = 57;
	public static readonly CloseBrace = 58;
	public static readonly Colon = 59;
	public static readonly Divide = 60;
	public static readonly Minus = 61;
	public static readonly Assign = 62;
	public static readonly Exclamation = 63;
	public static readonly Greater = 64;
	public static readonly Lass = 65;
	public static readonly Under = 66;
	public static readonly String = 67;
	public static readonly ID = 68;
	public static readonly Digit = 69;
	public static readonly Word = 70;
	public static readonly WHITESPACE = 71;
	public static readonly SINGLE_COMMENT = 72;
	public static readonly MULTI_COMMENT = 73;
	public static readonly RULE_contract = 0;
	public static readonly RULE_variables = 1;
	public static readonly RULE_variableStatement = 2;
	public static readonly RULE_dates = 3;
	public static readonly RULE_parties = 4;
	public static readonly RULE_clauses = 5;
	public static readonly RULE_beginDate = 6;
	public static readonly RULE_dueDate = 7;
	public static readonly RULE_application = 8;
	public static readonly RULE_process = 9;
	public static readonly RULE_clause = 10;
	public static readonly RULE_rolePlayer = 11;
	public static readonly RULE_operation = 12;
	public static readonly RULE_terms = 13;
	public static readonly RULE_termOrWhen = 14;
	public static readonly RULE_term = 15;
	public static readonly RULE_sessionInterval = 16;
	public static readonly RULE_when = 17;
	public static readonly RULE_timeout = 18;
	public static readonly RULE_timeInterval = 19;
	public static readonly RULE_weekDays = 20;
	public static readonly RULE_weekDaysInterval = 21;
	public static readonly RULE_maxNumberOfOperation = 22;
	public static readonly RULE_messageContent = 23;
	public static readonly RULE_messageContentBoolean = 24;
	public static readonly RULE_messageContentNumeric = 25;
	public static readonly RULE_messageContentText = 26;
	public static readonly RULE_equal = 27;
	public static readonly RULE_notEqual = 28;
	public static readonly RULE_greaterThan = 29;
	public static readonly RULE_lassThan = 30;
	public static readonly RULE_onBreach = 31;
	public static readonly RULE_datetime = 32;
	public static readonly RULE_time = 33;
	public static readonly RULE_second = 34;
	public static readonly RULE_minute = 35;
	public static readonly RULE_hour = 36;
	public static readonly RULE_day = 37;
	public static readonly RULE_month = 38;
	public static readonly RULE_year = 39;
	public static readonly RULE_digit = 40;
	// tslint:disable:no-trailing-whitespace
	public static readonly ruleNames: string[] = [
		"contract", "variables", "variableStatement", "dates", "parties", "clauses", 
		"beginDate", "dueDate", "application", "process", "clause", "rolePlayer", 
		"operation", "terms", "termOrWhen", "term", "sessionInterval", "when", 
		"timeout", "timeInterval", "weekDays", "weekDaysInterval", "maxNumberOfOperation", 
		"messageContent", "messageContentBoolean", "messageContentNumeric", "messageContentText", 
		"equal", "notEqual", "greaterThan", "lassThan", "onBreach", "datetime", 
		"time", "second", "minute", "hour", "day", "month", "year", "digit",
	];

	private static readonly _LITERAL_NAMES: Array<string | undefined> = [
		undefined, "'contract'", "'beginDate'", "'dueDate'", "'dates'", "'parties'", 
		"'application'", "'process'", "'clauses'", "'right'", "'prohibition'", 
		"'obligation'", "'rolePlayer'", "'operation'", "'onBreach'", "'OnSuccess'", 
		"'push'", "'poll'", "'read'", "'write'", "'request'", "'response'", "'condition'", 
		"'MaxNumberOfOperation'", "'MessageContent'", "'log'", "'Timeout'", "'TimeInterval'", 
		"'SessionInterval'", "'WeekDaysInterval'", "'variables'", "'per'", "'to'", 
		"'OR'", "'Monday'", "'Tuesday'", "'Wednesday'", "'Thursday'", "'Friday'", 
		"'Saturday'", "'Sunday'", "'terms'", "'Month'", "'Week'", "'Day'", "'Hour'", 
		"'Minute'", "'Second'", "'when'", "'do'", "'text'", "'numeric'", "'boolean'", 
		"','", "';'", "'('", "')'", "'{'", "'}'", "':'", "'/'", "'-'", "'='", 
		"'!'", "'>'", "'<'", "'_'",
	];
	private static readonly _SYMBOLIC_NAMES: Array<string | undefined> = [
		undefined, "Contract", "BeginDate", "DueDate", "Dates", "Parties", "Application", 
		"Process", "Clauses", "Right", "Prohibition", "Obligation", "RolePlayer", 
		"Operation", "OnBreach", "OnSuccess", "Push", "Poll", "Read", "Write", 
		"Request", "Response", "Condition", "MaxNumberOfOperation", "MessageContent", 
		"Log", "Timeout", "TimeInterval", "SessionInterval", "WeekDaysInterval", 
		"Variables", "Per", "To", "Or", "Monday", "Tuesday", "Wednesday", "Thursday", 
		"Friday", "Saturday", "Sunday", "Terms", "Month", "Week", "Day", "Hour", 
		"Minute", "Second", "When", "Do", "Text", "Numeric", "Boolean", "Comma", 
		"SemiColon", "OpenParen", "CloseParen", "OpenBrace", "CloseBrace", "Colon", 
		"Divide", "Minus", "Assign", "Exclamation", "Greater", "Lass", "Under", 
		"String", "ID", "Digit", "Word", "WHITESPACE", "SINGLE_COMMENT", "MULTI_COMMENT",
	];
	public static readonly VOCABULARY: Vocabulary = new VocabularyImpl(JabutiGrammarParser._LITERAL_NAMES, JabutiGrammarParser._SYMBOLIC_NAMES, []);

	// @Override
	// @NotNull
	public get vocabulary(): Vocabulary {
		return JabutiGrammarParser.VOCABULARY;
	}
	// tslint:enable:no-trailing-whitespace

	// @Override
	public get grammarFileName(): string { return "JabutiGrammar.g4"; }

	// @Override
	public get ruleNames(): string[] { return JabutiGrammarParser.ruleNames; }

	// @Override
	public get serializedATN(): string { return JabutiGrammarParser._serializedATN; }

	protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException {
		return new FailedPredicateException(this, predicate, message);
	}

	constructor(input: TokenStream) {
		super(input);
		this._interp = new ParserATNSimulator(JabutiGrammarParser._ATN, this);
	}
	// @RuleVersion(0)
	public contract(): ContractContext {
		let _localctx: ContractContext = new ContractContext(this._ctx, this.state);
		this.enterRule(_localctx, 0, JabutiGrammarParser.RULE_contract);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 95;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Contract) {
				{
				this.state = 82;
				this.match(JabutiGrammarParser.Contract);
				this.state = 83;
				this.match(JabutiGrammarParser.ID);
				this.state = 84;
				this.match(JabutiGrammarParser.OpenBrace);
				this.state = 91;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while ((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Dates) | (1 << JabutiGrammarParser.Parties) | (1 << JabutiGrammarParser.Clauses) | (1 << JabutiGrammarParser.Variables))) !== 0)) {
					{
					this.state = 89;
					this._errHandler.sync(this);
					switch (this._input.LA(1)) {
					case JabutiGrammarParser.Variables:
						{
						this.state = 85;
						this.variables();
						}
						break;
					case JabutiGrammarParser.Dates:
						{
						this.state = 86;
						this.dates();
						}
						break;
					case JabutiGrammarParser.Parties:
						{
						this.state = 87;
						this.parties();
						}
						break;
					case JabutiGrammarParser.Clauses:
						{
						this.state = 88;
						this.clauses();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					this.state = 93;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 94;
				this.match(JabutiGrammarParser.CloseBrace);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public variables(): VariablesContext {
		let _localctx: VariablesContext = new VariablesContext(this._ctx, this.state);
		this.enterRule(_localctx, 2, JabutiGrammarParser.RULE_variables);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 97;
			this.match(JabutiGrammarParser.Variables);
			this.state = 98;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 102;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la === JabutiGrammarParser.ID) {
				{
				{
				this.state = 99;
				this.variableStatement();
				}
				}
				this.state = 104;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 105;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public variableStatement(): VariableStatementContext {
		let _localctx: VariableStatementContext = new VariableStatementContext(this._ctx, this.state);
		this.enterRule(_localctx, 4, JabutiGrammarParser.RULE_variableStatement);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 107;
			this.match(JabutiGrammarParser.ID);
			this.state = 108;
			this.match(JabutiGrammarParser.Assign);
			this.state = 112;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.String:
				{
				this.state = 109;
				this.match(JabutiGrammarParser.String);
				}
				break;
			case JabutiGrammarParser.Digit:
				{
				this.state = 110;
				this.digit();
				}
				break;
			case JabutiGrammarParser.MaxNumberOfOperation:
			case JabutiGrammarParser.MessageContent:
			case JabutiGrammarParser.Timeout:
			case JabutiGrammarParser.TimeInterval:
			case JabutiGrammarParser.SessionInterval:
			case JabutiGrammarParser.WeekDaysInterval:
				{
				this.state = 111;
				this.term();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public dates(): DatesContext {
		let _localctx: DatesContext = new DatesContext(this._ctx, this.state);
		this.enterRule(_localctx, 6, JabutiGrammarParser.RULE_dates);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 114;
			this.match(JabutiGrammarParser.Dates);
			this.state = 115;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 124;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			do {
				{
				this.state = 124;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case JabutiGrammarParser.BeginDate:
					{
					this.state = 116;
					this.beginDate();
					this.state = 118;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === JabutiGrammarParser.Comma) {
						{
						this.state = 117;
						this.match(JabutiGrammarParser.Comma);
						}
					}

					}
					break;
				case JabutiGrammarParser.DueDate:
					{
					this.state = 120;
					this.dueDate();
					this.state = 122;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === JabutiGrammarParser.Comma) {
						{
						this.state = 121;
						this.match(JabutiGrammarParser.Comma);
						}
					}

					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				this.state = 126;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			} while (_la === JabutiGrammarParser.BeginDate || _la === JabutiGrammarParser.DueDate);
			this.state = 128;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public parties(): PartiesContext {
		let _localctx: PartiesContext = new PartiesContext(this._ctx, this.state);
		this.enterRule(_localctx, 8, JabutiGrammarParser.RULE_parties);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 130;
			this.match(JabutiGrammarParser.Parties);
			this.state = 131;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 140;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			do {
				{
				this.state = 140;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case JabutiGrammarParser.Application:
					{
					this.state = 132;
					this.application();
					this.state = 134;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === JabutiGrammarParser.Comma) {
						{
						this.state = 133;
						this.match(JabutiGrammarParser.Comma);
						}
					}

					}
					break;
				case JabutiGrammarParser.Process:
					{
					this.state = 136;
					this.process();
					this.state = 138;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === JabutiGrammarParser.Comma) {
						{
						this.state = 137;
						this.match(JabutiGrammarParser.Comma);
						}
					}

					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				this.state = 142;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			} while (_la === JabutiGrammarParser.Application || _la === JabutiGrammarParser.Process);
			this.state = 144;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public clauses(): ClausesContext {
		let _localctx: ClausesContext = new ClausesContext(this._ctx, this.state);
		this.enterRule(_localctx, 10, JabutiGrammarParser.RULE_clauses);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 146;
			this.match(JabutiGrammarParser.Clauses);
			this.state = 147;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 149;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			do {
				{
				{
				this.state = 148;
				this.clause();
				}
				}
				this.state = 151;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			} while ((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Right) | (1 << JabutiGrammarParser.Prohibition) | (1 << JabutiGrammarParser.Obligation))) !== 0));
			this.state = 153;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public beginDate(): BeginDateContext {
		let _localctx: BeginDateContext = new BeginDateContext(this._ctx, this.state);
		this.enterRule(_localctx, 12, JabutiGrammarParser.RULE_beginDate);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 155;
			this.match(JabutiGrammarParser.BeginDate);
			this.state = 156;
			this.match(JabutiGrammarParser.Assign);
			this.state = 157;
			this.datetime();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public dueDate(): DueDateContext {
		let _localctx: DueDateContext = new DueDateContext(this._ctx, this.state);
		this.enterRule(_localctx, 14, JabutiGrammarParser.RULE_dueDate);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 159;
			this.match(JabutiGrammarParser.DueDate);
			this.state = 160;
			this.match(JabutiGrammarParser.Assign);
			this.state = 161;
			this.datetime();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public application(): ApplicationContext {
		let _localctx: ApplicationContext = new ApplicationContext(this._ctx, this.state);
		this.enterRule(_localctx, 16, JabutiGrammarParser.RULE_application);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 163;
			this.match(JabutiGrammarParser.Application);
			this.state = 164;
			this.match(JabutiGrammarParser.Assign);
			this.state = 165;
			this.match(JabutiGrammarParser.String);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public process(): ProcessContext {
		let _localctx: ProcessContext = new ProcessContext(this._ctx, this.state);
		this.enterRule(_localctx, 18, JabutiGrammarParser.RULE_process);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 167;
			this.match(JabutiGrammarParser.Process);
			this.state = 168;
			this.match(JabutiGrammarParser.Assign);
			this.state = 169;
			this.match(JabutiGrammarParser.String);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public clause(): ClauseContext {
		let _localctx: ClauseContext = new ClauseContext(this._ctx, this.state);
		this.enterRule(_localctx, 20, JabutiGrammarParser.RULE_clause);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 171;
			_la = this._input.LA(1);
			if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Right) | (1 << JabutiGrammarParser.Prohibition) | (1 << JabutiGrammarParser.Obligation))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			this.state = 172;
			this.match(JabutiGrammarParser.ID);
			this.state = 173;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 174;
			this.rolePlayer();
			this.state = 176;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Comma) {
				{
				this.state = 175;
				this.match(JabutiGrammarParser.Comma);
				}
			}

			this.state = 178;
			this.operation();
			this.state = 180;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Comma) {
				{
				this.state = 179;
				this.match(JabutiGrammarParser.Comma);
				}
			}

			this.state = 182;
			this.terms();
			this.state = 185;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.OnBreach:
				{
				this.state = 183;
				this.onBreach();
				}
				break;
			case JabutiGrammarParser.OnSuccess:
				{
				this.state = 184;
				this.match(JabutiGrammarParser.OnSuccess);
				}
				break;
			case JabutiGrammarParser.CloseBrace:
				break;
			default:
				break;
			}
			this.state = 187;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public rolePlayer(): RolePlayerContext {
		let _localctx: RolePlayerContext = new RolePlayerContext(this._ctx, this.state);
		this.enterRule(_localctx, 22, JabutiGrammarParser.RULE_rolePlayer);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 189;
			this.match(JabutiGrammarParser.RolePlayer);
			this.state = 190;
			this.match(JabutiGrammarParser.Assign);
			this.state = 191;
			_la = this._input.LA(1);
			if (!(_la === JabutiGrammarParser.Application || _la === JabutiGrammarParser.Process)) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public operation(): OperationContext {
		let _localctx: OperationContext = new OperationContext(this._ctx, this.state);
		this.enterRule(_localctx, 24, JabutiGrammarParser.RULE_operation);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 193;
			this.match(JabutiGrammarParser.Operation);
			this.state = 194;
			this.match(JabutiGrammarParser.Assign);
			this.state = 195;
			_la = this._input.LA(1);
			if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.Push) | (1 << JabutiGrammarParser.Poll) | (1 << JabutiGrammarParser.Read) | (1 << JabutiGrammarParser.Write) | (1 << JabutiGrammarParser.Request) | (1 << JabutiGrammarParser.Response))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public terms(): TermsContext {
		let _localctx: TermsContext = new TermsContext(this._ctx, this.state);
		this.enterRule(_localctx, 26, JabutiGrammarParser.RULE_terms);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 197;
			this.match(JabutiGrammarParser.Terms);
			this.state = 198;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 216;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			do {
				{
				this.state = 216;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case JabutiGrammarParser.MaxNumberOfOperation:
				case JabutiGrammarParser.MessageContent:
				case JabutiGrammarParser.Timeout:
				case JabutiGrammarParser.TimeInterval:
				case JabutiGrammarParser.SessionInterval:
				case JabutiGrammarParser.WeekDaysInterval:
				case JabutiGrammarParser.When:
					{
					{
					{
					this.state = 199;
					this.termOrWhen();
					}
					this.state = 201;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === JabutiGrammarParser.Comma) {
						{
						this.state = 200;
						this.match(JabutiGrammarParser.Comma);
						}
					}

					}
					}
					break;
				case JabutiGrammarParser.OpenParen:
					{
					{
					this.state = 203;
					this.match(JabutiGrammarParser.OpenParen);
					this.state = 204;
					this.term();
					this.state = 209;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la === JabutiGrammarParser.Or) {
						{
						{
						this.state = 205;
						this.match(JabutiGrammarParser.Or);
						this.state = 206;
						this.termOrWhen();
						}
						}
						this.state = 211;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 212;
					this.match(JabutiGrammarParser.CloseParen);
					this.state = 214;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === JabutiGrammarParser.Comma) {
						{
						this.state = 213;
						this.match(JabutiGrammarParser.Comma);
						}
					}

					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				this.state = 218;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			} while ((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << JabutiGrammarParser.MaxNumberOfOperation) | (1 << JabutiGrammarParser.MessageContent) | (1 << JabutiGrammarParser.Timeout) | (1 << JabutiGrammarParser.TimeInterval) | (1 << JabutiGrammarParser.SessionInterval) | (1 << JabutiGrammarParser.WeekDaysInterval))) !== 0) || _la === JabutiGrammarParser.When || _la === JabutiGrammarParser.OpenParen);
			this.state = 220;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public termOrWhen(): TermOrWhenContext {
		let _localctx: TermOrWhenContext = new TermOrWhenContext(this._ctx, this.state);
		this.enterRule(_localctx, 28, JabutiGrammarParser.RULE_termOrWhen);
		try {
			this.state = 224;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.MaxNumberOfOperation:
			case JabutiGrammarParser.MessageContent:
			case JabutiGrammarParser.Timeout:
			case JabutiGrammarParser.TimeInterval:
			case JabutiGrammarParser.SessionInterval:
			case JabutiGrammarParser.WeekDaysInterval:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 222;
				this.term();
				}
				break;
			case JabutiGrammarParser.When:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 223;
				this.when();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public term(): TermContext {
		let _localctx: TermContext = new TermContext(this._ctx, this.state);
		this.enterRule(_localctx, 30, JabutiGrammarParser.RULE_term);
		try {
			this.state = 232;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.MaxNumberOfOperation:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 226;
				this.maxNumberOfOperation();
				}
				break;
			case JabutiGrammarParser.MessageContent:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 227;
				this.messageContent();
				}
				break;
			case JabutiGrammarParser.WeekDaysInterval:
				this.enterOuterAlt(_localctx, 3);
				{
				this.state = 228;
				this.weekDaysInterval();
				}
				break;
			case JabutiGrammarParser.TimeInterval:
				this.enterOuterAlt(_localctx, 4);
				{
				this.state = 229;
				this.timeInterval();
				}
				break;
			case JabutiGrammarParser.Timeout:
				this.enterOuterAlt(_localctx, 5);
				{
				this.state = 230;
				this.timeout();
				}
				break;
			case JabutiGrammarParser.SessionInterval:
				this.enterOuterAlt(_localctx, 6);
				{
				this.state = 231;
				this.sessionInterval();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public sessionInterval(): SessionIntervalContext {
		let _localctx: SessionIntervalContext = new SessionIntervalContext(this._ctx, this.state);
		this.enterRule(_localctx, 32, JabutiGrammarParser.RULE_sessionInterval);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 234;
			this.match(JabutiGrammarParser.SessionInterval);
			this.state = 235;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 236;
			this.digit();
			this.state = 237;
			_la = this._input.LA(1);
			if (!(((((_la - 42)) & ~0x1F) === 0 && ((1 << (_la - 42)) & ((1 << (JabutiGrammarParser.Month - 42)) | (1 << (JabutiGrammarParser.Week - 42)) | (1 << (JabutiGrammarParser.Day - 42)) | (1 << (JabutiGrammarParser.Minute - 42)) | (1 << (JabutiGrammarParser.Second - 42)))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			this.state = 238;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public when(): WhenContext {
		let _localctx: WhenContext = new WhenContext(this._ctx, this.state);
		this.enterRule(_localctx, 34, JabutiGrammarParser.RULE_when);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 240;
			this.match(JabutiGrammarParser.When);
			this.state = 241;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 244;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.MaxNumberOfOperation:
			case JabutiGrammarParser.MessageContent:
			case JabutiGrammarParser.Timeout:
			case JabutiGrammarParser.TimeInterval:
			case JabutiGrammarParser.SessionInterval:
			case JabutiGrammarParser.WeekDaysInterval:
			case JabutiGrammarParser.When:
				{
				this.state = 242;
				this.termOrWhen();
				}
				break;
			case JabutiGrammarParser.ID:
				{
				this.state = 243;
				this.match(JabutiGrammarParser.ID);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			this.state = 246;
			this.match(JabutiGrammarParser.CloseParen);
			this.state = 247;
			this.match(JabutiGrammarParser.Do);
			this.state = 248;
			this.match(JabutiGrammarParser.OpenBrace);
			this.state = 249;
			this.termOrWhen();
			this.state = 250;
			this.match(JabutiGrammarParser.CloseBrace);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public timeout(): TimeoutContext {
		let _localctx: TimeoutContext = new TimeoutContext(this._ctx, this.state);
		this.enterRule(_localctx, 36, JabutiGrammarParser.RULE_timeout);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 252;
			this.match(JabutiGrammarParser.Timeout);
			this.state = 253;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 254;
			this.digit();
			this.state = 255;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public timeInterval(): TimeIntervalContext {
		let _localctx: TimeIntervalContext = new TimeIntervalContext(this._ctx, this.state);
		this.enterRule(_localctx, 38, JabutiGrammarParser.RULE_timeInterval);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 257;
			this.match(JabutiGrammarParser.TimeInterval);
			this.state = 258;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 259;
			this.time();
			this.state = 260;
			this.match(JabutiGrammarParser.To);
			this.state = 261;
			this.time();
			this.state = 262;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public weekDays(): WeekDaysContext {
		let _localctx: WeekDaysContext = new WeekDaysContext(this._ctx, this.state);
		this.enterRule(_localctx, 40, JabutiGrammarParser.RULE_weekDays);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 264;
			_la = this._input.LA(1);
			if (!(((((_la - 34)) & ~0x1F) === 0 && ((1 << (_la - 34)) & ((1 << (JabutiGrammarParser.Monday - 34)) | (1 << (JabutiGrammarParser.Tuesday - 34)) | (1 << (JabutiGrammarParser.Wednesday - 34)) | (1 << (JabutiGrammarParser.Thursday - 34)) | (1 << (JabutiGrammarParser.Friday - 34)) | (1 << (JabutiGrammarParser.Saturday - 34)) | (1 << (JabutiGrammarParser.Sunday - 34)))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public weekDaysInterval(): WeekDaysIntervalContext {
		let _localctx: WeekDaysIntervalContext = new WeekDaysIntervalContext(this._ctx, this.state);
		this.enterRule(_localctx, 42, JabutiGrammarParser.RULE_weekDaysInterval);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 266;
			this.match(JabutiGrammarParser.WeekDaysInterval);
			this.state = 267;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 268;
			this.weekDays();
			this.state = 269;
			this.match(JabutiGrammarParser.To);
			this.state = 270;
			this.weekDays();
			this.state = 271;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public maxNumberOfOperation(): MaxNumberOfOperationContext {
		let _localctx: MaxNumberOfOperationContext = new MaxNumberOfOperationContext(this._ctx, this.state);
		this.enterRule(_localctx, 44, JabutiGrammarParser.RULE_maxNumberOfOperation);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 273;
			this.match(JabutiGrammarParser.MaxNumberOfOperation);
			this.state = 274;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 275;
			this.digit();
			this.state = 276;
			this.match(JabutiGrammarParser.Per);
			this.state = 277;
			_la = this._input.LA(1);
			if (!(((((_la - 42)) & ~0x1F) === 0 && ((1 << (_la - 42)) & ((1 << (JabutiGrammarParser.Month - 42)) | (1 << (JabutiGrammarParser.Week - 42)) | (1 << (JabutiGrammarParser.Day - 42)) | (1 << (JabutiGrammarParser.Hour - 42)) | (1 << (JabutiGrammarParser.Minute - 42)) | (1 << (JabutiGrammarParser.Second - 42)))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			this.state = 278;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public messageContent(): MessageContentContext {
		let _localctx: MessageContentContext = new MessageContentContext(this._ctx, this.state);
		this.enterRule(_localctx, 46, JabutiGrammarParser.RULE_messageContent);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 280;
			this.match(JabutiGrammarParser.MessageContent);
			this.state = 281;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 308;
			this._errHandler.sync(this);
			switch ( this.interpreter.adaptivePredict(this._input, 28, this._ctx) ) {
			case 1:
				{
				this.state = 282;
				this.messageContentBoolean();
				}
				break;

			case 2:
				{
				{
				this.state = 283;
				this.messageContentBoolean();
				}
				this.state = 286;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case JabutiGrammarParser.Assign:
					{
					this.state = 284;
					this.equal();
					}
					break;
				case JabutiGrammarParser.Exclamation:
					{
					this.state = 285;
					this.notEqual();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				{
				this.state = 288;
				this.messageContentBoolean();
				}
				}
				break;

			case 3:
				{
				{
				this.state = 290;
				this.messageContentNumeric();
				}
				this.state = 297;
				this._errHandler.sync(this);
				switch ( this.interpreter.adaptivePredict(this._input, 26, this._ctx) ) {
				case 1:
					{
					this.state = 291;
					this.equal();
					}
					break;

				case 2:
					{
					this.state = 292;
					this.notEqual();
					}
					break;

				case 3:
					{
					this.state = 293;
					this.greaterThan();
					}
					break;

				case 4:
					{
					this.state = 294;
					this.lassThan();
					}
					break;

				case 5:
					{
					this.state = 295;
					this.match(JabutiGrammarParser.Greater);
					}
					break;

				case 6:
					{
					this.state = 296;
					this.match(JabutiGrammarParser.Lass);
					}
					break;
				}
				{
				this.state = 299;
				this.messageContentNumeric();
				}
				}
				break;

			case 4:
				{
				{
				this.state = 301;
				this.messageContentText();
				}
				this.state = 304;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case JabutiGrammarParser.Assign:
					{
					this.state = 302;
					this.equal();
					}
					break;
				case JabutiGrammarParser.Exclamation:
					{
					this.state = 303;
					this.notEqual();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				{
				this.state = 306;
				this.messageContentText();
				}
				}
				break;
			}
			this.state = 310;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public messageContentBoolean(): MessageContentBooleanContext {
		let _localctx: MessageContentBooleanContext = new MessageContentBooleanContext(this._ctx, this.state);
		this.enterRule(_localctx, 48, JabutiGrammarParser.RULE_messageContentBoolean);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 312;
			this.match(JabutiGrammarParser.Boolean);
			this.state = 313;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 314;
			_la = this._input.LA(1);
			if (!(_la === JabutiGrammarParser.String || _la === JabutiGrammarParser.ID)) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			this.state = 315;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public messageContentNumeric(): MessageContentNumericContext {
		let _localctx: MessageContentNumericContext = new MessageContentNumericContext(this._ctx, this.state);
		this.enterRule(_localctx, 50, JabutiGrammarParser.RULE_messageContentNumeric);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 322;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.Numeric:
				{
				this.state = 317;
				this.match(JabutiGrammarParser.Numeric);
				this.state = 318;
				this.match(JabutiGrammarParser.OpenParen);
				this.state = 319;
				_la = this._input.LA(1);
				if (!(_la === JabutiGrammarParser.String || _la === JabutiGrammarParser.ID)) {
				this._errHandler.recoverInline(this);
				} else {
					if (this._input.LA(1) === Token.EOF) {
						this.matchedEOF = true;
					}

					this._errHandler.reportMatch(this);
					this.consume();
				}
				this.state = 320;
				this.match(JabutiGrammarParser.CloseParen);
				}
				break;
			case JabutiGrammarParser.Digit:
				{
				this.state = 321;
				this.digit();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public messageContentText(): MessageContentTextContext {
		let _localctx: MessageContentTextContext = new MessageContentTextContext(this._ctx, this.state);
		this.enterRule(_localctx, 52, JabutiGrammarParser.RULE_messageContentText);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 329;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case JabutiGrammarParser.Text:
				{
				this.state = 324;
				this.match(JabutiGrammarParser.Text);
				this.state = 325;
				this.match(JabutiGrammarParser.OpenParen);
				this.state = 326;
				_la = this._input.LA(1);
				if (!(_la === JabutiGrammarParser.String || _la === JabutiGrammarParser.ID)) {
				this._errHandler.recoverInline(this);
				} else {
					if (this._input.LA(1) === Token.EOF) {
						this.matchedEOF = true;
					}

					this._errHandler.reportMatch(this);
					this.consume();
				}
				this.state = 327;
				this.match(JabutiGrammarParser.CloseParen);
				}
				break;
			case JabutiGrammarParser.String:
				{
				this.state = 328;
				this.match(JabutiGrammarParser.String);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public equal(): EqualContext {
		let _localctx: EqualContext = new EqualContext(this._ctx, this.state);
		this.enterRule(_localctx, 54, JabutiGrammarParser.RULE_equal);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 331;
			this.match(JabutiGrammarParser.Assign);
			this.state = 332;
			this.match(JabutiGrammarParser.Assign);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public notEqual(): NotEqualContext {
		let _localctx: NotEqualContext = new NotEqualContext(this._ctx, this.state);
		this.enterRule(_localctx, 56, JabutiGrammarParser.RULE_notEqual);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 334;
			this.match(JabutiGrammarParser.Exclamation);
			this.state = 335;
			this.match(JabutiGrammarParser.Assign);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public greaterThan(): GreaterThanContext {
		let _localctx: GreaterThanContext = new GreaterThanContext(this._ctx, this.state);
		this.enterRule(_localctx, 58, JabutiGrammarParser.RULE_greaterThan);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 337;
			this.match(JabutiGrammarParser.Greater);
			this.state = 338;
			this.match(JabutiGrammarParser.Assign);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public lassThan(): LassThanContext {
		let _localctx: LassThanContext = new LassThanContext(this._ctx, this.state);
		this.enterRule(_localctx, 60, JabutiGrammarParser.RULE_lassThan);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 340;
			this.match(JabutiGrammarParser.Lass);
			this.state = 341;
			this.match(JabutiGrammarParser.Assign);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public onBreach(): OnBreachContext {
		let _localctx: OnBreachContext = new OnBreachContext(this._ctx, this.state);
		this.enterRule(_localctx, 62, JabutiGrammarParser.RULE_onBreach);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 343;
			this.match(JabutiGrammarParser.OnBreach);
			this.state = 344;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 345;
			this.match(JabutiGrammarParser.Log);
			this.state = 346;
			this.match(JabutiGrammarParser.OpenParen);
			this.state = 347;
			this.match(JabutiGrammarParser.String);
			this.state = 348;
			this.match(JabutiGrammarParser.CloseParen);
			this.state = 349;
			this.match(JabutiGrammarParser.CloseParen);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public datetime(): DatetimeContext {
		let _localctx: DatetimeContext = new DatetimeContext(this._ctx, this.state);
		this.enterRule(_localctx, 64, JabutiGrammarParser.RULE_datetime);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 351;
			this.year();
			this.state = 352;
			this.match(JabutiGrammarParser.Minus);
			this.state = 353;
			this.month();
			this.state = 354;
			this.match(JabutiGrammarParser.Minus);
			this.state = 355;
			this.day();
			this.state = 357;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Digit) {
				{
				this.state = 356;
				this.time();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public time(): TimeContext {
		let _localctx: TimeContext = new TimeContext(this._ctx, this.state);
		this.enterRule(_localctx, 66, JabutiGrammarParser.RULE_time);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 359;
			this.hour();
			this.state = 360;
			this.match(JabutiGrammarParser.Colon);
			this.state = 361;
			this.minute();
			this.state = 364;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Colon) {
				{
				this.state = 362;
				this.match(JabutiGrammarParser.Colon);
				this.state = 363;
				this.second();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public second(): SecondContext {
		let _localctx: SecondContext = new SecondContext(this._ctx, this.state);
		this.enterRule(_localctx, 68, JabutiGrammarParser.RULE_second);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 366;
			this.match(JabutiGrammarParser.Digit);
			this.state = 368;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Digit) {
				{
				this.state = 367;
				this.match(JabutiGrammarParser.Digit);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public minute(): MinuteContext {
		let _localctx: MinuteContext = new MinuteContext(this._ctx, this.state);
		this.enterRule(_localctx, 70, JabutiGrammarParser.RULE_minute);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 370;
			this.match(JabutiGrammarParser.Digit);
			this.state = 372;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Digit) {
				{
				this.state = 371;
				this.match(JabutiGrammarParser.Digit);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public hour(): HourContext {
		let _localctx: HourContext = new HourContext(this._ctx, this.state);
		this.enterRule(_localctx, 72, JabutiGrammarParser.RULE_hour);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 374;
			this.match(JabutiGrammarParser.Digit);
			this.state = 376;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Digit) {
				{
				this.state = 375;
				this.match(JabutiGrammarParser.Digit);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public day(): DayContext {
		let _localctx: DayContext = new DayContext(this._ctx, this.state);
		this.enterRule(_localctx, 74, JabutiGrammarParser.RULE_day);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 378;
			this.match(JabutiGrammarParser.Digit);
			this.state = 380;
			this._errHandler.sync(this);
			switch ( this.interpreter.adaptivePredict(this._input, 36, this._ctx) ) {
			case 1:
				{
				this.state = 379;
				this.match(JabutiGrammarParser.Digit);
				}
				break;
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public month(): MonthContext {
		let _localctx: MonthContext = new MonthContext(this._ctx, this.state);
		this.enterRule(_localctx, 76, JabutiGrammarParser.RULE_month);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 382;
			this.match(JabutiGrammarParser.Digit);
			this.state = 384;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === JabutiGrammarParser.Digit) {
				{
				this.state = 383;
				this.match(JabutiGrammarParser.Digit);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public year(): YearContext {
		let _localctx: YearContext = new YearContext(this._ctx, this.state);
		this.enterRule(_localctx, 78, JabutiGrammarParser.RULE_year);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 387;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			do {
				{
				{
				this.state = 386;
				this.match(JabutiGrammarParser.Digit);
				}
				}
				this.state = 389;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			} while (_la === JabutiGrammarParser.Digit);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public digit(): DigitContext {
		let _localctx: DigitContext = new DigitContext(this._ctx, this.state);
		this.enterRule(_localctx, 80, JabutiGrammarParser.RULE_digit);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 392;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			do {
				{
				{
				this.state = 391;
				this.match(JabutiGrammarParser.Digit);
				}
				}
				this.state = 394;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			} while (_la === JabutiGrammarParser.Digit);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}

	public static readonly _serializedATN: string =
		"\x03\uC91D\uCABA\u058D\uAFBA\u4F53\u0607\uEA8B\uC241\x03K\u018F\x04\x02" +
		"\t\x02\x04\x03\t\x03\x04\x04\t\x04\x04\x05\t\x05\x04\x06\t\x06\x04\x07" +
		"\t\x07\x04\b\t\b\x04\t\t\t\x04\n\t\n\x04\v\t\v\x04\f\t\f\x04\r\t\r\x04" +
		"\x0E\t\x0E\x04\x0F\t\x0F\x04\x10\t\x10\x04\x11\t\x11\x04\x12\t\x12\x04" +
		"\x13\t\x13\x04\x14\t\x14\x04\x15\t\x15\x04\x16\t\x16\x04\x17\t\x17\x04" +
		"\x18\t\x18\x04\x19\t\x19\x04\x1A\t\x1A\x04\x1B\t\x1B\x04\x1C\t\x1C\x04" +
		"\x1D\t\x1D\x04\x1E\t\x1E\x04\x1F\t\x1F\x04 \t \x04!\t!\x04\"\t\"\x04#" +
		"\t#\x04$\t$\x04%\t%\x04&\t&\x04\'\t\'\x04(\t(\x04)\t)\x04*\t*\x03\x02" +
		"\x03\x02\x03\x02\x03\x02\x03\x02\x03\x02\x03\x02\x07\x02\\\n\x02\f\x02" +
		"\x0E\x02_\v\x02\x03\x02\x05\x02b\n\x02\x03\x03\x03\x03\x03\x03\x07\x03" +
		"g\n\x03\f\x03\x0E\x03j\v\x03\x03\x03\x03\x03\x03\x04\x03\x04\x03\x04\x03" +
		"\x04\x03\x04\x05\x04s\n\x04\x03\x05\x03\x05\x03\x05\x03\x05\x05\x05y\n" +
		"\x05\x03\x05\x03\x05\x05\x05}\n\x05\x06\x05\x7F\n\x05\r\x05\x0E\x05\x80" +
		"\x03\x05\x03\x05\x03\x06\x03\x06\x03\x06\x03\x06\x05\x06\x89\n\x06\x03" +
		"\x06\x03\x06\x05\x06\x8D\n\x06\x06\x06\x8F\n\x06\r\x06\x0E\x06\x90\x03" +
		"\x06\x03\x06\x03\x07\x03\x07\x03\x07\x06\x07\x98\n\x07\r\x07\x0E\x07\x99" +
		"\x03\x07\x03\x07\x03\b\x03\b\x03\b\x03\b\x03\t\x03\t\x03\t\x03\t\x03\n" +
		"\x03\n\x03\n\x03\n\x03\v\x03\v\x03\v\x03\v\x03\f\x03\f\x03\f\x03\f\x03" +
		"\f\x05\f\xB3\n\f\x03\f\x03\f\x05\f\xB7\n\f\x03\f\x03\f\x03\f\x05\f\xBC" +
		"\n\f\x03\f\x03\f\x03\r\x03\r\x03\r\x03\r\x03\x0E\x03\x0E\x03\x0E\x03\x0E" +
		"\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x05\x0F\xCC\n\x0F\x03\x0F\x03\x0F\x03" +
		"\x0F\x03\x0F\x07\x0F\xD2\n\x0F\f\x0F\x0E\x0F\xD5\v\x0F\x03\x0F\x03\x0F" +
		"\x05\x0F\xD9\n\x0F\x06\x0F\xDB\n\x0F\r\x0F\x0E\x0F\xDC\x03\x0F\x03\x0F" +
		"\x03\x10\x03\x10\x05\x10\xE3\n\x10\x03\x11\x03\x11\x03\x11\x03\x11\x03" +
		"\x11\x03\x11\x05\x11\xEB\n\x11\x03\x12\x03\x12\x03\x12\x03\x12\x03\x12" +
		"\x03\x12\x03\x13\x03\x13\x03\x13\x03\x13\x05\x13\xF7\n\x13\x03\x13\x03" +
		"\x13\x03\x13\x03\x13\x03\x13\x03\x13\x03\x14\x03\x14\x03\x14\x03\x14\x03" +
		"\x14\x03\x15\x03\x15\x03\x15\x03\x15\x03\x15\x03\x15\x03\x15\x03\x16\x03" +
		"\x16\x03\x17\x03\x17\x03\x17\x03\x17\x03\x17\x03\x17\x03\x17\x03\x18\x03" +
		"\x18\x03\x18\x03\x18\x03\x18\x03\x18\x03\x18\x03\x19\x03\x19\x03\x19\x03" +
		"\x19\x03\x19\x03\x19\x05\x19\u0121\n\x19\x03\x19\x03\x19\x03\x19\x03\x19" +
		"\x03\x19\x03\x19\x03\x19\x03\x19\x03\x19\x05\x19\u012C\n\x19\x03\x19\x03" +
		"\x19\x03\x19\x03\x19\x03\x19\x05\x19\u0133\n\x19\x03\x19\x03\x19\x05\x19" +
		"\u0137\n\x19\x03\x19\x03\x19\x03\x1A\x03\x1A\x03\x1A\x03\x1A\x03\x1A\x03" +
		"\x1B\x03\x1B\x03\x1B\x03\x1B\x03\x1B\x05\x1B\u0145\n\x1B\x03\x1C\x03\x1C" +
		"\x03\x1C\x03\x1C\x03\x1C\x05\x1C\u014C\n\x1C\x03\x1D\x03\x1D\x03\x1D\x03" +
		"\x1E\x03\x1E\x03\x1E\x03\x1F\x03\x1F\x03\x1F\x03 \x03 \x03 \x03!\x03!" +
		"\x03!\x03!\x03!\x03!\x03!\x03!\x03\"\x03\"\x03\"\x03\"\x03\"\x03\"\x05" +
		"\"\u0168\n\"\x03#\x03#\x03#\x03#\x03#\x05#\u016F\n#\x03$\x03$\x05$\u0173" +
		"\n$\x03%\x03%\x05%\u0177\n%\x03&\x03&\x05&\u017B\n&\x03\'\x03\'\x05\'" +
		"\u017F\n\'\x03(\x03(\x05(\u0183\n(\x03)\x06)\u0186\n)\r)\x0E)\u0187\x03" +
		"*\x06*\u018B\n*\r*\x0E*\u018C\x03*\x02\x02\x02+\x02\x02\x04\x02\x06\x02" +
		"\b\x02\n\x02\f\x02\x0E\x02\x10\x02\x12\x02\x14\x02\x16\x02\x18\x02\x1A" +
		"\x02\x1C\x02\x1E\x02 \x02\"\x02$\x02&\x02(\x02*\x02,\x02.\x020\x022\x02" +
		"4\x026\x028\x02:\x02<\x02>\x02@\x02B\x02D\x02F\x02H\x02J\x02L\x02N\x02" +
		"P\x02R\x02\x02\t\x03\x02\v\r\x03\x02\b\t\x03\x02\x12\x17\x04\x02,.01\x03" +
		"\x02$*\x03\x02,1\x03\x02EF\x02\u019B\x02a\x03\x02\x02\x02\x04c\x03\x02" +
		"\x02\x02\x06m\x03\x02\x02\x02\bt\x03\x02\x02\x02\n\x84\x03\x02\x02\x02" +
		"\f\x94\x03\x02\x02\x02\x0E\x9D\x03\x02\x02\x02\x10\xA1\x03\x02\x02\x02" +
		"\x12\xA5\x03\x02\x02\x02\x14\xA9\x03\x02\x02\x02\x16\xAD\x03\x02\x02\x02" +
		"\x18\xBF\x03\x02\x02\x02\x1A\xC3\x03\x02\x02\x02\x1C\xC7\x03\x02\x02\x02" +
		"\x1E\xE2\x03\x02\x02\x02 \xEA\x03\x02\x02\x02\"\xEC\x03\x02\x02\x02$\xF2" +
		"\x03\x02\x02\x02&\xFE\x03\x02\x02\x02(\u0103\x03\x02\x02\x02*\u010A\x03" +
		"\x02\x02\x02,\u010C\x03\x02\x02\x02.\u0113\x03\x02\x02\x020\u011A\x03" +
		"\x02\x02\x022\u013A\x03\x02\x02\x024\u0144\x03\x02\x02\x026\u014B\x03" +
		"\x02\x02\x028\u014D\x03\x02\x02\x02:\u0150\x03\x02\x02\x02<\u0153\x03" +
		"\x02\x02\x02>\u0156\x03\x02\x02\x02@\u0159\x03\x02\x02\x02B\u0161\x03" +
		"\x02\x02\x02D\u0169\x03\x02\x02\x02F\u0170\x03\x02\x02\x02H\u0174\x03" +
		"\x02\x02\x02J\u0178\x03\x02\x02\x02L\u017C\x03\x02\x02\x02N\u0180\x03" +
		"\x02\x02\x02P\u0185\x03\x02\x02\x02R\u018A\x03\x02\x02\x02TU\x07\x03\x02" +
		"\x02UV\x07F\x02\x02V]\x07;\x02\x02W\\\x05\x04\x03\x02X\\\x05\b\x05\x02" +
		"Y\\\x05\n\x06\x02Z\\\x05\f\x07\x02[W\x03\x02\x02\x02[X\x03\x02\x02\x02" +
		"[Y\x03\x02\x02\x02[Z\x03\x02\x02\x02\\_\x03\x02\x02\x02][\x03\x02\x02" +
		"\x02]^\x03\x02\x02\x02^`\x03\x02\x02\x02_]\x03\x02\x02\x02`b\x07<\x02" +
		"\x02aT\x03\x02\x02\x02ab\x03\x02\x02\x02b\x03\x03\x02\x02\x02cd\x07 \x02" +
		"\x02dh\x07;\x02\x02eg\x05\x06\x04\x02fe\x03\x02\x02\x02gj\x03\x02\x02" +
		"\x02hf\x03\x02\x02\x02hi\x03\x02\x02\x02ik\x03\x02\x02\x02jh\x03\x02\x02" +
		"\x02kl\x07<\x02\x02l\x05\x03\x02\x02\x02mn\x07F\x02\x02nr\x07@\x02\x02" +
		"os\x07E\x02\x02ps\x05R*\x02qs\x05 \x11\x02ro\x03\x02\x02\x02rp\x03\x02" +
		"\x02\x02rq\x03\x02\x02\x02s\x07\x03\x02\x02\x02tu\x07\x06\x02\x02u~\x07" +
		";\x02\x02vx\x05\x0E\b\x02wy\x077\x02\x02xw\x03\x02\x02\x02xy\x03\x02\x02" +
		"\x02y\x7F\x03\x02\x02\x02z|\x05\x10\t\x02{}\x077\x02\x02|{\x03\x02\x02" +
		"\x02|}\x03\x02\x02\x02}\x7F\x03\x02\x02\x02~v\x03\x02\x02\x02~z\x03\x02" +
		"\x02\x02\x7F\x80\x03\x02\x02\x02\x80~\x03\x02\x02\x02\x80\x81\x03\x02" +
		"\x02\x02\x81\x82\x03\x02\x02\x02\x82\x83\x07<\x02\x02\x83\t\x03\x02\x02" +
		"\x02\x84\x85\x07\x07\x02\x02\x85\x8E\x07;\x02\x02\x86\x88\x05\x12\n\x02" +
		"\x87\x89\x077\x02\x02\x88\x87\x03\x02\x02\x02\x88\x89\x03\x02\x02\x02" +
		"\x89\x8F\x03\x02\x02\x02\x8A\x8C\x05\x14\v\x02\x8B\x8D\x077\x02\x02\x8C" +
		"\x8B\x03\x02\x02\x02\x8C\x8D\x03\x02\x02\x02\x8D\x8F\x03\x02\x02\x02\x8E" +
		"\x86\x03\x02\x02\x02\x8E\x8A\x03\x02\x02\x02\x8F\x90\x03\x02\x02\x02\x90" +
		"\x8E\x03\x02\x02\x02\x90\x91\x03\x02\x02\x02\x91\x92\x03\x02\x02\x02\x92" +
		"\x93\x07<\x02\x02\x93\v\x03\x02\x02\x02\x94\x95\x07\n\x02\x02\x95\x97" +
		"\x07;\x02\x02\x96\x98\x05\x16\f\x02\x97\x96\x03\x02\x02\x02\x98\x99\x03" +
		"\x02\x02\x02\x99\x97\x03\x02\x02\x02\x99\x9A\x03\x02\x02\x02\x9A\x9B\x03" +
		"\x02\x02\x02\x9B\x9C\x07<\x02\x02\x9C\r\x03\x02\x02\x02\x9D\x9E\x07\x04" +
		"\x02\x02\x9E\x9F\x07@\x02\x02\x9F\xA0\x05B\"\x02\xA0\x0F\x03\x02\x02\x02" +
		"\xA1\xA2\x07\x05\x02\x02\xA2\xA3\x07@\x02\x02\xA3\xA4\x05B\"\x02\xA4\x11" +
		"\x03\x02\x02\x02\xA5\xA6\x07\b\x02\x02\xA6\xA7\x07@\x02\x02\xA7\xA8\x07" +
		"E\x02\x02\xA8\x13\x03\x02\x02\x02\xA9\xAA\x07\t\x02\x02\xAA\xAB\x07@\x02" +
		"\x02\xAB\xAC\x07E\x02\x02\xAC\x15\x03\x02\x02\x02\xAD\xAE\t\x02\x02\x02" +
		"\xAE\xAF\x07F\x02\x02\xAF\xB0\x07;\x02\x02\xB0\xB2\x05\x18\r\x02\xB1\xB3" +
		"\x077\x02\x02\xB2\xB1\x03\x02\x02\x02\xB2\xB3\x03\x02\x02\x02\xB3\xB4" +
		"\x03\x02\x02\x02\xB4\xB6\x05\x1A\x0E\x02\xB5\xB7\x077\x02\x02\xB6\xB5" +
		"\x03\x02\x02\x02\xB6\xB7\x03\x02\x02\x02\xB7\xB8\x03\x02\x02\x02\xB8\xBB" +
		"\x05\x1C\x0F\x02\xB9\xBC\x05@!\x02\xBA\xBC\x07\x11\x02\x02\xBB\xB9\x03" +
		"\x02\x02\x02\xBB\xBA\x03\x02\x02\x02\xBB\xBC\x03\x02\x02\x02\xBC\xBD\x03" +
		"\x02\x02\x02\xBD\xBE\x07<\x02\x02\xBE\x17\x03\x02\x02\x02\xBF\xC0\x07" +
		"\x0E\x02\x02\xC0\xC1\x07@\x02\x02\xC1\xC2\t\x03\x02\x02\xC2\x19\x03\x02" +
		"\x02\x02\xC3\xC4\x07\x0F\x02\x02\xC4\xC5\x07@\x02\x02\xC5\xC6\t\x04\x02" +
		"\x02\xC6\x1B\x03\x02\x02\x02\xC7\xC8\x07+\x02\x02\xC8\xDA\x07;\x02\x02" +
		"\xC9\xCB\x05\x1E\x10\x02\xCA\xCC\x077\x02\x02\xCB\xCA\x03\x02\x02\x02" +
		"\xCB\xCC\x03\x02\x02\x02\xCC\xDB\x03\x02\x02\x02\xCD\xCE\x079\x02\x02" +
		"\xCE\xD3\x05 \x11\x02\xCF\xD0\x07#\x02\x02\xD0\xD2\x05\x1E\x10\x02\xD1" +
		"\xCF\x03\x02\x02\x02\xD2\xD5\x03\x02\x02\x02\xD3\xD1\x03\x02\x02\x02\xD3" +
		"\xD4\x03\x02\x02\x02\xD4\xD6\x03\x02\x02\x02\xD5\xD3\x03\x02\x02\x02\xD6" +
		"\xD8\x07:\x02\x02\xD7\xD9\x077\x02\x02\xD8\xD7\x03\x02\x02\x02\xD8\xD9" +
		"\x03\x02\x02\x02\xD9\xDB\x03\x02\x02\x02\xDA\xC9\x03\x02\x02\x02\xDA\xCD" +
		"\x03\x02\x02\x02\xDB\xDC\x03\x02\x02\x02\xDC\xDA\x03\x02\x02\x02\xDC\xDD" +
		"\x03\x02\x02\x02\xDD\xDE\x03\x02\x02\x02\xDE\xDF\x07<\x02\x02\xDF\x1D" +
		"\x03\x02\x02\x02\xE0\xE3\x05 \x11\x02\xE1\xE3\x05$\x13\x02\xE2\xE0\x03" +
		"\x02\x02\x02\xE2\xE1\x03\x02\x02\x02\xE3\x1F\x03\x02\x02\x02\xE4\xEB\x05" +
		".\x18\x02\xE5\xEB\x050\x19\x02\xE6\xEB\x05,\x17\x02\xE7\xEB\x05(\x15\x02" +
		"\xE8\xEB\x05&\x14\x02\xE9\xEB\x05\"\x12\x02\xEA\xE4\x03\x02\x02\x02\xEA" +
		"\xE5\x03\x02\x02\x02\xEA\xE6\x03\x02\x02\x02\xEA\xE7\x03\x02\x02\x02\xEA" +
		"\xE8\x03\x02\x02\x02\xEA\xE9\x03\x02\x02\x02\xEB!\x03\x02\x02\x02\xEC" +
		"\xED\x07\x1E\x02\x02\xED\xEE\x079\x02\x02\xEE\xEF\x05R*\x02\xEF\xF0\t" +
		"\x05\x02\x02\xF0\xF1\x07:\x02\x02\xF1#\x03\x02\x02\x02\xF2\xF3\x072\x02" +
		"\x02\xF3\xF6\x079\x02\x02\xF4\xF7\x05\x1E\x10\x02\xF5\xF7\x07F\x02\x02" +
		"\xF6\xF4\x03\x02\x02\x02\xF6\xF5\x03\x02\x02\x02\xF7\xF8\x03\x02\x02\x02" +
		"\xF8\xF9\x07:\x02\x02\xF9\xFA\x073\x02\x02\xFA\xFB\x07;\x02\x02\xFB\xFC" +
		"\x05\x1E\x10\x02\xFC\xFD\x07<\x02\x02\xFD%\x03\x02\x02\x02\xFE\xFF\x07" +
		"\x1C\x02\x02\xFF\u0100\x079\x02\x02\u0100\u0101\x05R*\x02\u0101\u0102" +
		"\x07:\x02\x02\u0102\'\x03\x02\x02\x02\u0103\u0104\x07\x1D\x02\x02\u0104" +
		"\u0105\x079\x02\x02\u0105\u0106\x05D#\x02\u0106\u0107\x07\"\x02\x02\u0107" +
		"\u0108\x05D#\x02\u0108\u0109\x07:\x02\x02\u0109)\x03\x02\x02\x02\u010A" +
		"\u010B\t\x06\x02\x02\u010B+\x03\x02\x02\x02\u010C\u010D\x07\x1F\x02\x02" +
		"\u010D\u010E\x079\x02\x02\u010E\u010F\x05*\x16\x02\u010F\u0110\x07\"\x02" +
		"\x02\u0110\u0111\x05*\x16\x02\u0111\u0112\x07:\x02\x02\u0112-\x03\x02" +
		"\x02\x02\u0113\u0114\x07\x19\x02\x02\u0114\u0115\x079\x02\x02\u0115\u0116" +
		"\x05R*\x02\u0116\u0117\x07!\x02\x02\u0117\u0118\t\x07\x02\x02\u0118\u0119" +
		"\x07:\x02\x02\u0119/\x03\x02\x02\x02\u011A\u011B\x07\x1A\x02\x02\u011B" +
		"\u0136\x079\x02\x02\u011C\u0137\x052\x1A\x02\u011D\u0120\x052\x1A\x02" +
		"\u011E\u0121\x058\x1D\x02\u011F\u0121\x05:\x1E\x02\u0120\u011E\x03\x02" +
		"\x02\x02\u0120\u011F\x03\x02\x02\x02\u0121\u0122\x03\x02\x02\x02\u0122" +
		"\u0123\x052\x1A\x02\u0123\u0137\x03\x02\x02\x02\u0124\u012B\x054\x1B\x02" +
		"\u0125\u012C\x058\x1D\x02\u0126\u012C\x05:\x1E\x02\u0127\u012C\x05<\x1F" +
		"\x02\u0128\u012C\x05> \x02\u0129\u012C\x07B\x02\x02\u012A\u012C\x07C\x02" +
		"\x02\u012B\u0125\x03\x02\x02\x02\u012B\u0126\x03\x02\x02\x02\u012B\u0127" +
		"\x03\x02\x02\x02\u012B\u0128\x03\x02\x02\x02\u012B\u0129\x03\x02\x02\x02" +
		"\u012B\u012A\x03\x02\x02\x02\u012C\u012D\x03\x02\x02\x02\u012D\u012E\x05" +
		"4\x1B\x02\u012E\u0137\x03\x02\x02\x02\u012F\u0132\x056\x1C\x02\u0130\u0133" +
		"\x058\x1D\x02\u0131\u0133\x05:\x1E\x02\u0132\u0130\x03\x02\x02\x02\u0132" +
		"\u0131\x03\x02\x02\x02\u0133\u0134\x03\x02\x02\x02\u0134\u0135\x056\x1C" +
		"\x02\u0135\u0137\x03\x02\x02\x02\u0136\u011C\x03\x02\x02\x02\u0136\u011D" +
		"\x03\x02\x02\x02\u0136\u0124\x03\x02\x02\x02\u0136\u012F\x03\x02\x02\x02" +
		"\u0137\u0138\x03\x02\x02\x02\u0138\u0139\x07:\x02\x02\u01391\x03\x02\x02" +
		"\x02\u013A\u013B\x076\x02\x02\u013B\u013C\x079\x02\x02\u013C\u013D\t\b" +
		"\x02\x02\u013D\u013E\x07:\x02\x02\u013E3\x03\x02\x02\x02\u013F\u0140\x07" +
		"5\x02\x02\u0140\u0141\x079\x02\x02\u0141\u0142\t\b\x02\x02\u0142\u0145" +
		"\x07:\x02\x02\u0143\u0145\x05R*\x02\u0144\u013F\x03\x02\x02\x02\u0144" +
		"\u0143\x03\x02\x02\x02\u01455\x03\x02\x02\x02\u0146\u0147\x074\x02\x02" +
		"\u0147\u0148\x079\x02\x02\u0148\u0149\t\b\x02\x02\u0149\u014C\x07:\x02" +
		"\x02\u014A\u014C\x07E\x02\x02\u014B\u0146\x03\x02\x02\x02\u014B\u014A" +
		"\x03\x02\x02\x02\u014C7\x03\x02\x02\x02\u014D\u014E\x07@\x02\x02\u014E" +
		"\u014F\x07@\x02\x02\u014F9\x03\x02\x02\x02\u0150\u0151\x07A\x02\x02\u0151" +
		"\u0152\x07@\x02\x02\u0152;\x03\x02\x02\x02\u0153\u0154\x07B\x02\x02\u0154" +
		"\u0155\x07@\x02\x02\u0155=\x03\x02\x02\x02\u0156\u0157\x07C\x02\x02\u0157" +
		"\u0158\x07@\x02\x02\u0158?\x03\x02\x02\x02\u0159\u015A\x07\x10\x02\x02" +
		"\u015A\u015B\x079\x02\x02\u015B\u015C\x07\x1B\x02\x02\u015C\u015D\x07" +
		"9\x02\x02\u015D\u015E\x07E\x02\x02\u015E\u015F\x07:\x02\x02\u015F\u0160" +
		"\x07:\x02\x02\u0160A\x03\x02\x02\x02\u0161\u0162\x05P)\x02\u0162\u0163" +
		"\x07?\x02\x02\u0163\u0164\x05N(\x02\u0164\u0165\x07?\x02\x02\u0165\u0167" +
		"\x05L\'\x02\u0166\u0168\x05D#\x02\u0167\u0166\x03\x02\x02\x02\u0167\u0168" +
		"\x03\x02\x02\x02\u0168C\x03\x02\x02\x02\u0169\u016A\x05J&\x02\u016A\u016B" +
		"\x07=\x02\x02\u016B\u016E\x05H%\x02\u016C\u016D\x07=\x02\x02\u016D\u016F" +
		"\x05F$\x02\u016E\u016C\x03\x02\x02\x02\u016E\u016F\x03\x02\x02\x02\u016F" +
		"E\x03\x02\x02\x02\u0170\u0172\x07G\x02\x02\u0171\u0173\x07G\x02\x02\u0172" +
		"\u0171\x03\x02\x02\x02\u0172\u0173\x03\x02\x02\x02\u0173G\x03\x02\x02" +
		"\x02\u0174\u0176\x07G\x02\x02\u0175\u0177\x07G\x02\x02\u0176\u0175\x03" +
		"\x02\x02\x02\u0176\u0177\x03\x02\x02\x02\u0177I\x03\x02\x02\x02\u0178" +
		"\u017A\x07G\x02\x02\u0179\u017B\x07G\x02\x02\u017A\u0179\x03\x02\x02\x02" +
		"\u017A\u017B\x03\x02\x02\x02\u017BK\x03\x02\x02\x02\u017C\u017E\x07G\x02" +
		"\x02\u017D\u017F\x07G\x02\x02\u017E\u017D\x03\x02\x02\x02\u017E\u017F" +
		"\x03\x02\x02\x02\u017FM\x03\x02\x02\x02\u0180\u0182\x07G\x02\x02\u0181" +
		"\u0183\x07G\x02\x02\u0182\u0181\x03\x02\x02\x02\u0182\u0183\x03\x02\x02" +
		"\x02\u0183O\x03\x02\x02\x02\u0184\u0186\x07G\x02\x02\u0185\u0184\x03\x02" +
		"\x02\x02\u0186\u0187\x03\x02\x02\x02\u0187\u0185\x03\x02\x02\x02\u0187" +
		"\u0188\x03\x02\x02\x02\u0188Q\x03\x02\x02\x02\u0189\u018B\x07G\x02\x02" +
		"\u018A\u0189\x03\x02\x02\x02\u018B\u018C\x03\x02\x02\x02\u018C\u018A\x03" +
		"\x02\x02\x02\u018C\u018D\x03\x02\x02\x02\u018DS\x03\x02\x02\x02*[]ahr" +
		"x|~\x80\x88\x8C\x8E\x90\x99\xB2\xB6\xBB\xCB\xD3\xD8\xDA\xDC\xE2\xEA\xF6" +
		"\u0120\u012B\u0132\u0136\u0144\u014B\u0167\u016E\u0172\u0176\u017A\u017E" +
		"\u0182\u0187\u018C";
	public static __ATN: ATN;
	public static get _ATN(): ATN {
		if (!JabutiGrammarParser.__ATN) {
			JabutiGrammarParser.__ATN = new ATNDeserializer().deserialize(Utils.toCharArray(JabutiGrammarParser._serializedATN));
		}

		return JabutiGrammarParser.__ATN;
	}

}

export class ContractContext extends ParserRuleContext {
	public Contract(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Contract, 0); }
	public ID(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
	public OpenBrace(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.OpenBrace, 0); }
	public CloseBrace(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.CloseBrace, 0); }
	public variables(): VariablesContext[];
	public variables(i: number): VariablesContext;
	public variables(i?: number): VariablesContext | VariablesContext[] {
		if (i === undefined) {
			return this.getRuleContexts(VariablesContext);
		} else {
			return this.getRuleContext(i, VariablesContext);
		}
	}
	public dates(): DatesContext[];
	public dates(i: number): DatesContext;
	public dates(i?: number): DatesContext | DatesContext[] {
		if (i === undefined) {
			return this.getRuleContexts(DatesContext);
		} else {
			return this.getRuleContext(i, DatesContext);
		}
	}
	public parties(): PartiesContext[];
	public parties(i: number): PartiesContext;
	public parties(i?: number): PartiesContext | PartiesContext[] {
		if (i === undefined) {
			return this.getRuleContexts(PartiesContext);
		} else {
			return this.getRuleContext(i, PartiesContext);
		}
	}
	public clauses(): ClausesContext[];
	public clauses(i: number): ClausesContext;
	public clauses(i?: number): ClausesContext | ClausesContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ClausesContext);
		} else {
			return this.getRuleContext(i, ClausesContext);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_contract; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterContract) {
			listener.enterContract(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitContract) {
			listener.exitContract(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitContract) {
			return visitor.visitContract(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class VariablesContext extends ParserRuleContext {
	public Variables(): TerminalNode { return this.getToken(JabutiGrammarParser.Variables, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public variableStatement(): VariableStatementContext[];
	public variableStatement(i: number): VariableStatementContext;
	public variableStatement(i?: number): VariableStatementContext | VariableStatementContext[] {
		if (i === undefined) {
			return this.getRuleContexts(VariableStatementContext);
		} else {
			return this.getRuleContext(i, VariableStatementContext);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_variables; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterVariables) {
			listener.enterVariables(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitVariables) {
			listener.exitVariables(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitVariables) {
			return visitor.visitVariables(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class VariableStatementContext extends ParserRuleContext {
	public ID(): TerminalNode { return this.getToken(JabutiGrammarParser.ID, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public String(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.String, 0); }
	public digit(): DigitContext | undefined {
		return this.tryGetRuleContext(0, DigitContext);
	}
	public term(): TermContext | undefined {
		return this.tryGetRuleContext(0, TermContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_variableStatement; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterVariableStatement) {
			listener.enterVariableStatement(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitVariableStatement) {
			listener.exitVariableStatement(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitVariableStatement) {
			return visitor.visitVariableStatement(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DatesContext extends ParserRuleContext {
	public Dates(): TerminalNode { return this.getToken(JabutiGrammarParser.Dates, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public beginDate(): BeginDateContext[];
	public beginDate(i: number): BeginDateContext;
	public beginDate(i?: number): BeginDateContext | BeginDateContext[] {
		if (i === undefined) {
			return this.getRuleContexts(BeginDateContext);
		} else {
			return this.getRuleContext(i, BeginDateContext);
		}
	}
	public dueDate(): DueDateContext[];
	public dueDate(i: number): DueDateContext;
	public dueDate(i?: number): DueDateContext | DueDateContext[] {
		if (i === undefined) {
			return this.getRuleContexts(DueDateContext);
		} else {
			return this.getRuleContext(i, DueDateContext);
		}
	}
	public Comma(): TerminalNode[];
	public Comma(i: number): TerminalNode;
	public Comma(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Comma);
		} else {
			return this.getToken(JabutiGrammarParser.Comma, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_dates; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterDates) {
			listener.enterDates(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitDates) {
			listener.exitDates(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitDates) {
			return visitor.visitDates(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class PartiesContext extends ParserRuleContext {
	public Parties(): TerminalNode { return this.getToken(JabutiGrammarParser.Parties, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public application(): ApplicationContext[];
	public application(i: number): ApplicationContext;
	public application(i?: number): ApplicationContext | ApplicationContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ApplicationContext);
		} else {
			return this.getRuleContext(i, ApplicationContext);
		}
	}
	public process(): ProcessContext[];
	public process(i: number): ProcessContext;
	public process(i?: number): ProcessContext | ProcessContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ProcessContext);
		} else {
			return this.getRuleContext(i, ProcessContext);
		}
	}
	public Comma(): TerminalNode[];
	public Comma(i: number): TerminalNode;
	public Comma(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Comma);
		} else {
			return this.getToken(JabutiGrammarParser.Comma, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_parties; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterParties) {
			listener.enterParties(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitParties) {
			listener.exitParties(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitParties) {
			return visitor.visitParties(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ClausesContext extends ParserRuleContext {
	public Clauses(): TerminalNode { return this.getToken(JabutiGrammarParser.Clauses, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public clause(): ClauseContext[];
	public clause(i: number): ClauseContext;
	public clause(i?: number): ClauseContext | ClauseContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ClauseContext);
		} else {
			return this.getRuleContext(i, ClauseContext);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_clauses; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterClauses) {
			listener.enterClauses(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitClauses) {
			listener.exitClauses(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitClauses) {
			return visitor.visitClauses(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class BeginDateContext extends ParserRuleContext {
	public BeginDate(): TerminalNode { return this.getToken(JabutiGrammarParser.BeginDate, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public datetime(): DatetimeContext {
		return this.getRuleContext(0, DatetimeContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_beginDate; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterBeginDate) {
			listener.enterBeginDate(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitBeginDate) {
			listener.exitBeginDate(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitBeginDate) {
			return visitor.visitBeginDate(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DueDateContext extends ParserRuleContext {
	public DueDate(): TerminalNode { return this.getToken(JabutiGrammarParser.DueDate, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public datetime(): DatetimeContext {
		return this.getRuleContext(0, DatetimeContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_dueDate; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterDueDate) {
			listener.enterDueDate(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitDueDate) {
			listener.exitDueDate(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitDueDate) {
			return visitor.visitDueDate(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ApplicationContext extends ParserRuleContext {
	public Application(): TerminalNode { return this.getToken(JabutiGrammarParser.Application, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public String(): TerminalNode { return this.getToken(JabutiGrammarParser.String, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_application; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterApplication) {
			listener.enterApplication(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitApplication) {
			listener.exitApplication(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitApplication) {
			return visitor.visitApplication(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ProcessContext extends ParserRuleContext {
	public Process(): TerminalNode { return this.getToken(JabutiGrammarParser.Process, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public String(): TerminalNode { return this.getToken(JabutiGrammarParser.String, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_process; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterProcess) {
			listener.enterProcess(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitProcess) {
			listener.exitProcess(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitProcess) {
			return visitor.visitProcess(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ClauseContext extends ParserRuleContext {
	public ID(): TerminalNode { return this.getToken(JabutiGrammarParser.ID, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public rolePlayer(): RolePlayerContext {
		return this.getRuleContext(0, RolePlayerContext);
	}
	public operation(): OperationContext {
		return this.getRuleContext(0, OperationContext);
	}
	public terms(): TermsContext {
		return this.getRuleContext(0, TermsContext);
	}
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public Right(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Right, 0); }
	public Prohibition(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Prohibition, 0); }
	public Obligation(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Obligation, 0); }
	public Comma(): TerminalNode[];
	public Comma(i: number): TerminalNode;
	public Comma(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Comma);
		} else {
			return this.getToken(JabutiGrammarParser.Comma, i);
		}
	}
	public onBreach(): OnBreachContext | undefined {
		return this.tryGetRuleContext(0, OnBreachContext);
	}
	public OnSuccess(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.OnSuccess, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_clause; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterClause) {
			listener.enterClause(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitClause) {
			listener.exitClause(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitClause) {
			return visitor.visitClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RolePlayerContext extends ParserRuleContext {
	public RolePlayer(): TerminalNode { return this.getToken(JabutiGrammarParser.RolePlayer, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public Process(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Process, 0); }
	public Application(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Application, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_rolePlayer; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterRolePlayer) {
			listener.enterRolePlayer(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitRolePlayer) {
			listener.exitRolePlayer(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitRolePlayer) {
			return visitor.visitRolePlayer(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OperationContext extends ParserRuleContext {
	public Operation(): TerminalNode { return this.getToken(JabutiGrammarParser.Operation, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	public Push(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Push, 0); }
	public Poll(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Poll, 0); }
	public Read(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Read, 0); }
	public Write(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Write, 0); }
	public Request(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Request, 0); }
	public Response(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Response, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_operation; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterOperation) {
			listener.enterOperation(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitOperation) {
			listener.exitOperation(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitOperation) {
			return visitor.visitOperation(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TermsContext extends ParserRuleContext {
	public Terms(): TerminalNode { return this.getToken(JabutiGrammarParser.Terms, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public OpenParen(): TerminalNode[];
	public OpenParen(i: number): TerminalNode;
	public OpenParen(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.OpenParen);
		} else {
			return this.getToken(JabutiGrammarParser.OpenParen, i);
		}
	}
	public term(): TermContext[];
	public term(i: number): TermContext;
	public term(i?: number): TermContext | TermContext[] {
		if (i === undefined) {
			return this.getRuleContexts(TermContext);
		} else {
			return this.getRuleContext(i, TermContext);
		}
	}
	public CloseParen(): TerminalNode[];
	public CloseParen(i: number): TerminalNode;
	public CloseParen(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.CloseParen);
		} else {
			return this.getToken(JabutiGrammarParser.CloseParen, i);
		}
	}
	public termOrWhen(): TermOrWhenContext[];
	public termOrWhen(i: number): TermOrWhenContext;
	public termOrWhen(i?: number): TermOrWhenContext | TermOrWhenContext[] {
		if (i === undefined) {
			return this.getRuleContexts(TermOrWhenContext);
		} else {
			return this.getRuleContext(i, TermOrWhenContext);
		}
	}
	public Comma(): TerminalNode[];
	public Comma(i: number): TerminalNode;
	public Comma(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Comma);
		} else {
			return this.getToken(JabutiGrammarParser.Comma, i);
		}
	}
	public Or(): TerminalNode[];
	public Or(i: number): TerminalNode;
	public Or(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Or);
		} else {
			return this.getToken(JabutiGrammarParser.Or, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_terms; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterTerms) {
			listener.enterTerms(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitTerms) {
			listener.exitTerms(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitTerms) {
			return visitor.visitTerms(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TermOrWhenContext extends ParserRuleContext {
	public term(): TermContext | undefined {
		return this.tryGetRuleContext(0, TermContext);
	}
	public when(): WhenContext | undefined {
		return this.tryGetRuleContext(0, WhenContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_termOrWhen; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterTermOrWhen) {
			listener.enterTermOrWhen(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitTermOrWhen) {
			listener.exitTermOrWhen(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitTermOrWhen) {
			return visitor.visitTermOrWhen(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TermContext extends ParserRuleContext {
	public maxNumberOfOperation(): MaxNumberOfOperationContext | undefined {
		return this.tryGetRuleContext(0, MaxNumberOfOperationContext);
	}
	public messageContent(): MessageContentContext | undefined {
		return this.tryGetRuleContext(0, MessageContentContext);
	}
	public weekDaysInterval(): WeekDaysIntervalContext | undefined {
		return this.tryGetRuleContext(0, WeekDaysIntervalContext);
	}
	public timeInterval(): TimeIntervalContext | undefined {
		return this.tryGetRuleContext(0, TimeIntervalContext);
	}
	public timeout(): TimeoutContext | undefined {
		return this.tryGetRuleContext(0, TimeoutContext);
	}
	public sessionInterval(): SessionIntervalContext | undefined {
		return this.tryGetRuleContext(0, SessionIntervalContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_term; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterTerm) {
			listener.enterTerm(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitTerm) {
			listener.exitTerm(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitTerm) {
			return visitor.visitTerm(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SessionIntervalContext extends ParserRuleContext {
	public SessionInterval(): TerminalNode { return this.getToken(JabutiGrammarParser.SessionInterval, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public digit(): DigitContext {
		return this.getRuleContext(0, DigitContext);
	}
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	public Second(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Second, 0); }
	public Minute(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Minute, 0); }
	public Day(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Day, 0); }
	public Week(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Week, 0); }
	public Month(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Month, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_sessionInterval; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterSessionInterval) {
			listener.enterSessionInterval(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitSessionInterval) {
			listener.exitSessionInterval(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitSessionInterval) {
			return visitor.visitSessionInterval(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class WhenContext extends ParserRuleContext {
	public When(): TerminalNode { return this.getToken(JabutiGrammarParser.When, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	public Do(): TerminalNode { return this.getToken(JabutiGrammarParser.Do, 0); }
	public OpenBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenBrace, 0); }
	public termOrWhen(): TermOrWhenContext[];
	public termOrWhen(i: number): TermOrWhenContext;
	public termOrWhen(i?: number): TermOrWhenContext | TermOrWhenContext[] {
		if (i === undefined) {
			return this.getRuleContexts(TermOrWhenContext);
		} else {
			return this.getRuleContext(i, TermOrWhenContext);
		}
	}
	public CloseBrace(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseBrace, 0); }
	public ID(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_when; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterWhen) {
			listener.enterWhen(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitWhen) {
			listener.exitWhen(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitWhen) {
			return visitor.visitWhen(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeoutContext extends ParserRuleContext {
	public Timeout(): TerminalNode { return this.getToken(JabutiGrammarParser.Timeout, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public digit(): DigitContext {
		return this.getRuleContext(0, DigitContext);
	}
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_timeout; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterTimeout) {
			listener.enterTimeout(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitTimeout) {
			listener.exitTimeout(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitTimeout) {
			return visitor.visitTimeout(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeIntervalContext extends ParserRuleContext {
	public TimeInterval(): TerminalNode { return this.getToken(JabutiGrammarParser.TimeInterval, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public time(): TimeContext[];
	public time(i: number): TimeContext;
	public time(i?: number): TimeContext | TimeContext[] {
		if (i === undefined) {
			return this.getRuleContexts(TimeContext);
		} else {
			return this.getRuleContext(i, TimeContext);
		}
	}
	public To(): TerminalNode { return this.getToken(JabutiGrammarParser.To, 0); }
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_timeInterval; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterTimeInterval) {
			listener.enterTimeInterval(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitTimeInterval) {
			listener.exitTimeInterval(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitTimeInterval) {
			return visitor.visitTimeInterval(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class WeekDaysContext extends ParserRuleContext {
	public Monday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Monday, 0); }
	public Tuesday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Tuesday, 0); }
	public Wednesday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Wednesday, 0); }
	public Thursday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Thursday, 0); }
	public Friday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Friday, 0); }
	public Saturday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Saturday, 0); }
	public Sunday(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Sunday, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_weekDays; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterWeekDays) {
			listener.enterWeekDays(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitWeekDays) {
			listener.exitWeekDays(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitWeekDays) {
			return visitor.visitWeekDays(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class WeekDaysIntervalContext extends ParserRuleContext {
	public WeekDaysInterval(): TerminalNode { return this.getToken(JabutiGrammarParser.WeekDaysInterval, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public weekDays(): WeekDaysContext[];
	public weekDays(i: number): WeekDaysContext;
	public weekDays(i?: number): WeekDaysContext | WeekDaysContext[] {
		if (i === undefined) {
			return this.getRuleContexts(WeekDaysContext);
		} else {
			return this.getRuleContext(i, WeekDaysContext);
		}
	}
	public To(): TerminalNode { return this.getToken(JabutiGrammarParser.To, 0); }
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_weekDaysInterval; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterWeekDaysInterval) {
			listener.enterWeekDaysInterval(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitWeekDaysInterval) {
			listener.exitWeekDaysInterval(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitWeekDaysInterval) {
			return visitor.visitWeekDaysInterval(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MaxNumberOfOperationContext extends ParserRuleContext {
	public MaxNumberOfOperation(): TerminalNode { return this.getToken(JabutiGrammarParser.MaxNumberOfOperation, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public digit(): DigitContext {
		return this.getRuleContext(0, DigitContext);
	}
	public Per(): TerminalNode { return this.getToken(JabutiGrammarParser.Per, 0); }
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	public Second(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Second, 0); }
	public Hour(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Hour, 0); }
	public Minute(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Minute, 0); }
	public Day(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Day, 0); }
	public Week(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Week, 0); }
	public Month(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Month, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_maxNumberOfOperation; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMaxNumberOfOperation) {
			listener.enterMaxNumberOfOperation(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMaxNumberOfOperation) {
			listener.exitMaxNumberOfOperation(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMaxNumberOfOperation) {
			return visitor.visitMaxNumberOfOperation(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MessageContentContext extends ParserRuleContext {
	public MessageContent(): TerminalNode { return this.getToken(JabutiGrammarParser.MessageContent, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	public messageContentBoolean(): MessageContentBooleanContext[];
	public messageContentBoolean(i: number): MessageContentBooleanContext;
	public messageContentBoolean(i?: number): MessageContentBooleanContext | MessageContentBooleanContext[] {
		if (i === undefined) {
			return this.getRuleContexts(MessageContentBooleanContext);
		} else {
			return this.getRuleContext(i, MessageContentBooleanContext);
		}
	}
	public equal(): EqualContext | undefined {
		return this.tryGetRuleContext(0, EqualContext);
	}
	public notEqual(): NotEqualContext | undefined {
		return this.tryGetRuleContext(0, NotEqualContext);
	}
	public messageContentNumeric(): MessageContentNumericContext[];
	public messageContentNumeric(i: number): MessageContentNumericContext;
	public messageContentNumeric(i?: number): MessageContentNumericContext | MessageContentNumericContext[] {
		if (i === undefined) {
			return this.getRuleContexts(MessageContentNumericContext);
		} else {
			return this.getRuleContext(i, MessageContentNumericContext);
		}
	}
	public greaterThan(): GreaterThanContext | undefined {
		return this.tryGetRuleContext(0, GreaterThanContext);
	}
	public lassThan(): LassThanContext | undefined {
		return this.tryGetRuleContext(0, LassThanContext);
	}
	public Greater(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Greater, 0); }
	public Lass(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Lass, 0); }
	public messageContentText(): MessageContentTextContext[];
	public messageContentText(i: number): MessageContentTextContext;
	public messageContentText(i?: number): MessageContentTextContext | MessageContentTextContext[] {
		if (i === undefined) {
			return this.getRuleContexts(MessageContentTextContext);
		} else {
			return this.getRuleContext(i, MessageContentTextContext);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_messageContent; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMessageContent) {
			listener.enterMessageContent(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMessageContent) {
			listener.exitMessageContent(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMessageContent) {
			return visitor.visitMessageContent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MessageContentBooleanContext extends ParserRuleContext {
	public Boolean(): TerminalNode { return this.getToken(JabutiGrammarParser.Boolean, 0); }
	public OpenParen(): TerminalNode { return this.getToken(JabutiGrammarParser.OpenParen, 0); }
	public CloseParen(): TerminalNode { return this.getToken(JabutiGrammarParser.CloseParen, 0); }
	public ID(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
	public String(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.String, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_messageContentBoolean; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMessageContentBoolean) {
			listener.enterMessageContentBoolean(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMessageContentBoolean) {
			listener.exitMessageContentBoolean(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMessageContentBoolean) {
			return visitor.visitMessageContentBoolean(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MessageContentNumericContext extends ParserRuleContext {
	public Numeric(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Numeric, 0); }
	public OpenParen(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.OpenParen, 0); }
	public CloseParen(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.CloseParen, 0); }
	public digit(): DigitContext | undefined {
		return this.tryGetRuleContext(0, DigitContext);
	}
	public ID(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
	public String(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.String, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_messageContentNumeric; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMessageContentNumeric) {
			listener.enterMessageContentNumeric(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMessageContentNumeric) {
			listener.exitMessageContentNumeric(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMessageContentNumeric) {
			return visitor.visitMessageContentNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MessageContentTextContext extends ParserRuleContext {
	public Text(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.Text, 0); }
	public OpenParen(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.OpenParen, 0); }
	public CloseParen(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.CloseParen, 0); }
	public String(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.String, 0); }
	public ID(): TerminalNode | undefined { return this.tryGetToken(JabutiGrammarParser.ID, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_messageContentText; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMessageContentText) {
			listener.enterMessageContentText(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMessageContentText) {
			listener.exitMessageContentText(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMessageContentText) {
			return visitor.visitMessageContentText(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class EqualContext extends ParserRuleContext {
	public Assign(): TerminalNode[];
	public Assign(i: number): TerminalNode;
	public Assign(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Assign);
		} else {
			return this.getToken(JabutiGrammarParser.Assign, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_equal; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterEqual) {
			listener.enterEqual(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitEqual) {
			listener.exitEqual(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitEqual) {
			return visitor.visitEqual(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class NotEqualContext extends ParserRuleContext {
	public Exclamation(): TerminalNode { return this.getToken(JabutiGrammarParser.Exclamation, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_notEqual; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterNotEqual) {
			listener.enterNotEqual(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitNotEqual) {
			listener.exitNotEqual(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitNotEqual) {
			return visitor.visitNotEqual(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GreaterThanContext extends ParserRuleContext {
	public Greater(): TerminalNode { return this.getToken(JabutiGrammarParser.Greater, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_greaterThan; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterGreaterThan) {
			listener.enterGreaterThan(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitGreaterThan) {
			listener.exitGreaterThan(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitGreaterThan) {
			return visitor.visitGreaterThan(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class LassThanContext extends ParserRuleContext {
	public Lass(): TerminalNode { return this.getToken(JabutiGrammarParser.Lass, 0); }
	public Assign(): TerminalNode { return this.getToken(JabutiGrammarParser.Assign, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_lassThan; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterLassThan) {
			listener.enterLassThan(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitLassThan) {
			listener.exitLassThan(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitLassThan) {
			return visitor.visitLassThan(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OnBreachContext extends ParserRuleContext {
	public OnBreach(): TerminalNode { return this.getToken(JabutiGrammarParser.OnBreach, 0); }
	public OpenParen(): TerminalNode[];
	public OpenParen(i: number): TerminalNode;
	public OpenParen(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.OpenParen);
		} else {
			return this.getToken(JabutiGrammarParser.OpenParen, i);
		}
	}
	public Log(): TerminalNode { return this.getToken(JabutiGrammarParser.Log, 0); }
	public String(): TerminalNode { return this.getToken(JabutiGrammarParser.String, 0); }
	public CloseParen(): TerminalNode[];
	public CloseParen(i: number): TerminalNode;
	public CloseParen(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.CloseParen);
		} else {
			return this.getToken(JabutiGrammarParser.CloseParen, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_onBreach; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterOnBreach) {
			listener.enterOnBreach(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitOnBreach) {
			listener.exitOnBreach(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitOnBreach) {
			return visitor.visitOnBreach(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DatetimeContext extends ParserRuleContext {
	public year(): YearContext {
		return this.getRuleContext(0, YearContext);
	}
	public Minus(): TerminalNode[];
	public Minus(i: number): TerminalNode;
	public Minus(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Minus);
		} else {
			return this.getToken(JabutiGrammarParser.Minus, i);
		}
	}
	public month(): MonthContext {
		return this.getRuleContext(0, MonthContext);
	}
	public day(): DayContext {
		return this.getRuleContext(0, DayContext);
	}
	public time(): TimeContext | undefined {
		return this.tryGetRuleContext(0, TimeContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_datetime; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterDatetime) {
			listener.enterDatetime(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitDatetime) {
			listener.exitDatetime(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitDatetime) {
			return visitor.visitDatetime(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeContext extends ParserRuleContext {
	public hour(): HourContext {
		return this.getRuleContext(0, HourContext);
	}
	public Colon(): TerminalNode[];
	public Colon(i: number): TerminalNode;
	public Colon(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Colon);
		} else {
			return this.getToken(JabutiGrammarParser.Colon, i);
		}
	}
	public minute(): MinuteContext {
		return this.getRuleContext(0, MinuteContext);
	}
	public second(): SecondContext | undefined {
		return this.tryGetRuleContext(0, SecondContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_time; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterTime) {
			listener.enterTime(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitTime) {
			listener.exitTime(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitTime) {
			return visitor.visitTime(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SecondContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_second; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterSecond) {
			listener.enterSecond(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitSecond) {
			listener.exitSecond(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitSecond) {
			return visitor.visitSecond(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MinuteContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_minute; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMinute) {
			listener.enterMinute(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMinute) {
			listener.exitMinute(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMinute) {
			return visitor.visitMinute(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HourContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_hour; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterHour) {
			listener.enterHour(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitHour) {
			listener.exitHour(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitHour) {
			return visitor.visitHour(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DayContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_day; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterDay) {
			listener.enterDay(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitDay) {
			listener.exitDay(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitDay) {
			return visitor.visitDay(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MonthContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_month; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterMonth) {
			listener.enterMonth(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitMonth) {
			listener.exitMonth(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitMonth) {
			return visitor.visitMonth(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class YearContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_year; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterYear) {
			listener.enterYear(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitYear) {
			listener.exitYear(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitYear) {
			return visitor.visitYear(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DigitContext extends ParserRuleContext {
	public Digit(): TerminalNode[];
	public Digit(i: number): TerminalNode;
	public Digit(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(JabutiGrammarParser.Digit);
		} else {
			return this.getToken(JabutiGrammarParser.Digit, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return JabutiGrammarParser.RULE_digit; }
	// @Override
	public enterRule(listener: JabutiGrammarListener): void {
		if (listener.enterDigit) {
			listener.enterDigit(this);
		}
	}
	// @Override
	public exitRule(listener: JabutiGrammarListener): void {
		if (listener.exitDigit) {
			listener.exitDigit(this);
		}
	}
	// @Override
	public accept<Result>(visitor: JabutiGrammarVisitor<Result>): Result {
		if (visitor.visitDigit) {
			return visitor.visitDigit(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


