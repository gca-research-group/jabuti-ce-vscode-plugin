import { JabutiGrammarParser, MessageContentContext, DatetimeContext, ApplicationContext, ProcessContext, OperationContext, TermsContext, RolePlayerContext, TimeoutContext, BeginDateContext, DueDateContext, ClauseContext } from 'jabuti-dsl-grammar-antlr/JabutiGrammarParser';
import { JabutiGrammarListener } from 'jabuti-dsl-grammar-antlr/JabutiGrammarListener';
import { ParserRuleContext } from 'antlr4ts';

interface Formatter {
    format: (contract: string) => string;
}

interface Message {
    error: string;
    success: string;
}

interface Term {
    type: string | undefined;
    variable: string | undefined;
    symbol: string | undefined;
    value: string | undefined;
}

interface Variable {
    name: {
        pascal: string;
        camel: string;
        snake: string;
    };
    type: string;
}

interface Clause {
    name: {
        pascal: string;
        camel: string;
        snake: string;
    };
    type: string | undefined;
    rolePlayer: string | undefined;
    operation: string | undefined;
    terms: Term[];
    messages: Message;
    variables: Variable[];
}

interface Contract {
    name: string;
    beginDate: string;
    dueDate: string;
    application: string;
    process: string;
    variables: Variable[];
    clauses: Clause[];
}

interface Generator<T> {
    render: (template: string, data: Contract) => string;
    generate: (data: Contract) => T;
}

interface Factory<T = {
    content: string;
}> {
    transform: (contract: string) => T;
}

declare abstract class BaseGenerator {
    render(template: string, data: Contract): string;
}

declare class HyperledgerFabricGolangGenerator extends BaseGenerator implements Generator<{
    content: string;
    mod: string;
}> {
    generate(data: Contract): {
        content: string;
        mod: string;
        spydra: string;
    };
    private generateSpydraConfiguration;
    private prepareDate;
}

declare class EthereumSolidityGenerator extends BaseGenerator implements Generator<{
    content: string;
}> {
    generate(data: Contract): {
        content: string;
    };
}

declare class HyperledgerFabricGolangFormatter implements Formatter {
    format(content: string): string;
}

declare class CanonicalParser {
    parse(parser: JabutiGrammarParser): Contract;
    parseMessageContent(term: MessageContentContext, index: number): (string | {
        name: {
            pascal: string;
            camel: string;
            snake: string;
        };
        type: string;
    } | undefined)[] | undefined;
}

declare class GrammarParser {
    parse(contract: string): JabutiGrammarParser;
}

declare class HyperledgerFabricGolangFactory implements Factory {
    transform(contract: string): {
        content: string;
        mod: string;
        spydra: string;
    };
}

declare class EthereumSolidityFactory implements Factory {
    transform(contract: string): {
        content: string;
    };
}

declare const ETHEREUM_SOLIDITY_TEMPLATE = "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.0;\n\nuint8 constant SUNDAY=0;\nuint8 constant MONDAY=1;\nuint8 constant TUESDAY=2;\nuint8 constant WEDNESDAY=3;\nuint8 constant THURSDAY=4;\nuint8 constant FRIDAY=5;\nuint8 constant SATURDAY=6;\n\nuint8 constant SECOND = 0;\nuint8 constant MINUTE = 1;\nuint8 constant HOUR= 2;\nuint8 constant DAY= 3;\nuint8 constant WEEK= 4;\nuint8 constant MONTH= 5;\nuint8 constant YEAR= 6;\n\nstruct Party {\n    string name;\n    address walletAddress;\n    bool aware;\n}\n\nstruct Parties {\n    Party application;\n    Party proccess;\n}\n\nstruct Interval {\n    uint32 start;\n    uint32 end;\n}\n\nstruct Timeout {\n  uint32 increase;\n  uint32 end;\n}\n\nstruct MaxNumberOfOperation {\n    uint32 max;\n    uint32 used;\n    uint32 start;\n    uint32 end;\n    uint8 timeUnit;\n}\n\n<% clauses.forEach(clause => { %>\nstruct <%= clause.name.pascal %> {\n  <% clause.terms.forEach(term => { %>\n    <% if (term.type === 'weekdayInterval' || term.type === 'timeInterval') { %>\n      Interval <%= term.name.camel %>;\n    <% } %>\n\n    <% if (term.type === 'maxNumberOfOperation') { %>\n      MaxNumberOfOperation <%= term.name.camel %>;\n    <% } %>\n\n    <% if (term.type === 'timeout') { %>\n      Timeout <%= term.name.camel %>;\n    <% } %>\n\n    <% if (term.type === 'messageContent') { %>\n\n      <% if (term.arguments.type === 'BOOLEAN') { %>\n        bool <%= term.name.camel %>;\n      <% } else if (term.arguments.type === 'NUMBER') { %>\n        uint32 <%= term.name.camel %>;\n      <% } else if (term.arguments.type === 'TEXT') { %>\n        string <%= term.name.camel %>;\n      <% } %>\n      \n    <% } %>\n\n  <% }) %>\n}\n<% }) %>\n\ncontract <%= contractName %> {\n\n    Parties private parties;\n    bool private isActivated = false;\n\n    <% clauses.forEach(clause => { %>\n      <%= clause.name.pascal %> private <%= clause.name.camel %>;\n    <% }) %>\n\n    mapping (uint8 => uint32) private timeInSeconds;\n\n    event SuccessEvent(string _logMessage);\n\n    modifier onlyProcess() {\n        require(isActivated, \"This contract is deactivated\");\n        require(parties.proccess.walletAddress == msg.sender, \"Only the process can execute this operation\");\n        _;\n    }\n\n    modifier onlyParties() {\n        require(parties.application.walletAddress == msg.sender || parties.proccess.walletAddress == msg.sender, \"Only the process or the application can execute this operation\");\n        _;\n    }\n\n    constructor(Parties memory _parties, <%= clauses.map(clause => `${clause.name.pascal} memory _${clause.name.camel}`).join(', ') %>) {\n        parties = _parties;\n\n        parties.application.aware = false;\n        parties.proccess.aware = false;\n\n        <%= clauses.map(clause => `${clause.name.camel} = _${clause.name.camel};`).join('') %>\n\n        <% clauses.forEach(clause => { %>\n          <% clause.terms.forEach(term => { %>\n            <% if (term.type === 'maxNumberOfOperation') { %>\n              <%= clause.name.camel %>.<%= term.name.camel %>.used = 0;\n              <%= clause.name.camel %>.<%= term.name.camel %>.start = 0;\n              <%= clause.name.camel %>.<%= term.name.camel %>.end = 0;\n            <% } %>\n          <% }) %>\n        <% }) %>\n\n        timeInSeconds[SECOND]   = 1;\n        timeInSeconds[MINUTE]   = 1 * 60;\n        timeInSeconds[HOUR]     = 1 * 60 * 60;\n        timeInSeconds[DAY]      = 1 * 60 * 60 * 24;\n        timeInSeconds[WEEK]     = 1 * 60 * 60 * 24 * 7;\n        timeInSeconds[MONTH]    = 1 * 60 * 60 * 24 * 7 * 30;\n    }\n\n    <% clauses.forEach(clause => { %>\n    function clause<%= clause.name.pascal %> ( \n      <% clause.variables.map((variable, index) =>  { %>\n        <% if (variable.type === 'BOOLEAN') {%>\n          <%= `bool _${variable.name} ${index !== (clause.variables.length - 1) ? ',' : ''} ` %>\n        <% } else { %>\n          <%= `${['NUMBER', 'DATE', 'DATETIME', 'TIME'].includes(variable.type) ? 'uint32' : 'string memory'} _${variable.name} ${index !== (clause.variables.length - 1) ? ',' : ''} ` %>\n        <% } %>\n      <% }) %> \n    )\n     public onlyProcess returns (bool) {\n      bool isValid = true;\n\n      <% clause.terms.forEach((term, index) => { %>\n        <% if (term.type === 'weekdayInterval') { %>\n          isValid = isValid && _weekDay >= <%= clause.name.camel %>.<%= term.name.camel %>.start && _weekDay <= <%= clause.name.camel %>.<%= term.name.camel %>.end;\n        <% } %>\n\n        <% if (term.type === 'timeInterval') { %>\n          isValid = isValid && _accessTime >= <%= clause.name.camel %>.<%= term.name.camel %>.start && _accessTime <= <%= clause.name.camel %>.<%= term.name.camel %>.end;\n        <% } %>\n\n        <% if (term.type === 'timeout') { %>\n          isValid = isValid && _accessDateTime <= <%= clause.name.camel %>.<%= term.name.camel %>.end;\n        <% } %>\n\n        <% if (term.type === 'messageContent' && term.arguments.type === 'TEXT') { %>\n          isValid = isValid && keccak256(abi.encodePacked(<%= clause.name.camel %>.<%= term.name.camel %>)) <%- term.arguments.operator %> keccak256(abi.encodePacked(_<%= term.name.camel %>));\n        <% } %>\n\n        <% if (term.type === 'messageContent' && term.arguments.type !== 'TEXT') { %>\n          isValid = isValid && <%= clause.name.camel %>.<%= term.name.camel %> <%- term.arguments.operator %> _<%= term.name.camel %>;\n        <% } %>\n\n        <% if (term.type === 'maxNumberOfOperation') { %>\n          bool maxNumberOfOperationIsInitialized<%= index %> = <%= clause.name.camel %>.<%= term.name.camel %>.start == 0 && <%= clause.name.camel %>.<%= term.name.camel %>.end == 0;\n\n          bool endPeriodIsLassThanAccessDateTime<%= index %> = <%= clause.name.camel %>.<%= term.name.camel %>.end < _accessDateTime;\n\n          if (!maxNumberOfOperationIsInitialized<%= index %> || endPeriodIsLassThanAccessDateTime<%= index %>) {\n            <%= clause.name.camel %>.<%= term.name.camel %>.start  = _accessDateTime;\n            <%= clause.name.camel %>.<%= term.name.camel %>.end    = _accessDateTime + timeInSeconds[<%= clause.name.camel %>.<%= term.name.camel %>.timeUnit];\n            <%= clause.name.camel %>.<%= term.name.camel %>.used   = 0;\n          }\n\n          isValid = isValid && <%= clause.name.camel %>.<%= term.name.camel %>.used <= <%= clause.name.camel %>.<%= term.name.camel %>.max;\n\n        <% } %>\n\n      <% }) %>\n\n      <% if (clause.operation === 'request') { %>\n        <% timeoutTerms.forEach(timeout => { %>\n          <%= timeout.clauseName.camel %>.<%= timeout.termName.camel %>.end  = _accessDateTime + <%= timeout.clauseName.camel %>.<%= timeout.termName.camel %>.increase;\n        <% }) %>\n      <% } %>\n\n      <% if (clause.errorMessage) { %>\n        require(!isValid, <%- clause.errorMessage %>);\n      <% } else { %>\n        require(!isValid, \"Error executing clause: <%- clause.name.pascal %>\");\n      <% } %>\n\n      emit SuccessEvent(\"Successful execution!\");\n      return isValid;\n    }\n    <% }) %>\n\n    function signContract() public onlyParties returns(bool) {\n\n        if (parties.application.walletAddress == msg.sender) {\n            require(!parties.application.aware, \"The contract is already signed\");\n            parties.application.aware = true;\n        }\n\n        if (parties.proccess.walletAddress == msg.sender) {\n            require(!parties.proccess.aware, \"The contract is already signed\");\n            parties.proccess.aware = true;\n        }\n\n        isActivated = parties.application.aware && parties.proccess.aware;\n\n        return true;\n    }\n}\n";

declare const HYPERLEDGER_FABRIC_GOLANG_TEMPLATE = "\n/**\n * This file was generated by Jabuti Transformation Engine.\n * \n * Copyright: Applied Computing Research Group (GCA), Uniju\u00ED University, Ijui-RS, Brazil\n * SPDX-License-Identifier: MIT\n * Author: Mailson Teles Borges <mailson.borges@sou.unijui.edu.br>\n *\n * For more information about the Jabuti Transformation Engine, please visit:\n * https://github.com/gca-research-group/jabuti-ce-transformation-engine\n */\n\npackage main\n\nimport (\n\t\"encoding/json\"\n\t\"fmt\"\n  \t\"log\"\n\t\"time\"\n\n\t\"github.com/google/uuid\"\n\t\"github.com/hyperledger/fabric-contract-api-go/contractapi\"\n)\n\n<% if (clauses.some(clause => clause.terms.some(term => term.type == 'maxNumberOfOperation'))) { %>\nvar timeInSeconds = map[string]int{\n\t\"SECOND\": 1,\n\t\"MINUTE\": 1 * 60,\n\t\"HOUR\":   1 * 60 * 60,\n\t\"DAY\":    1 * 60 * 60 * 24,\n\t\"WEEK\":   1 * 60 * 60 * 24 * 7,\n\t\"MONTH\":  1 * 60 * 60 * 24 * 7 * 30,\n}\n<% }%>\n\ntype SmartContract struct {\n\tcontractapi.Contract\n}\n\ntype Party struct {\n\tId            string\n\tName          string\n\tIsSigned      bool\n\tSignatureDate time.Time\n}\n\ntype Parties struct {\n\tApplication Party\n\tProcess     Party\n}\n\ntype Interval struct {\n  Start time.Time   `json:\"start\"`\n  End   time.Time   `json:\"end\"`\n}\n\ntype Timeout struct {\n  Increase  int       `json:\"increase\"`\n  End       time.Time `json:\"end\"`\n}\n\ntype MaxNumberOfOperation struct {\n  Max       int       `json:\"max\"`\n  Used      int       `json:\"used\"`\n  Start     time.Time `json:\"start\"`\n  End       time.Time `json:\"end\"`\n  TimeUnit  string    `json:\"timeUnit\"`\n}\n\n<% clauses.forEach(clause => { %>\n  type <%= clause.name.pascal %> struct {\n    <% clause.terms.forEach(term => { %>\n      <% if (term.type === 'weekdayInterval' || term.type === 'timeInterval') { %>\n        <%= term.name.pascal %> Interval `json:\"<%= term.name.camel %>\"`\n      <% } %>\n  \n      <% if (term.type === 'maxNumberOfOperation') { %>\n        <%= term.name.pascal %> MaxNumberOfOperation `json:\"<%= term.name.camel %>\"`\n      <% } %>\n  \n      <% if (term.type === 'timeout') { %>\n        <%= term.name.pascal %> Timeout `json:\"<%= term.name.camel %>\"`\n      <% } %>\n  \n    <% }) %>\n  }\n\n  <% if (clause.variables?.length) { %>\n\t\ttype <%= clause.name.pascal %>Args struct {\n\t\t\t<% clause.variables.forEach(variable => { %>\n\t\t\t\t<%= variable.name.pascal %> <%= variable.type === 'TEXT' ? 'string' : (variable.type === 'BOOLEAN' ? 'bool' : 'int') %> `json:\"<%= variable.name.camel %>\"`\n\t\t\t<% }) %>\n\t\t}\n\t<% } %>\n\n<% }) %>\n\ntype Request struct {\n\tclientId string\n\tcreatedAt time.Time\n}\n\ntype Asset struct {\n\tParties   Parties\n\tBeginDate time.Time\n\tDueDate   time.Time\n\tIsSigned  bool\n\tCreatedAt time.Time\n\tUpdatedAt time.Time\n  Requests  map[string]Request\n\n  <% clauses.forEach(clause => { %>\n    <%= clause.name.pascal %> <%= clause.name.pascal %> \n  <% }) %>\n}\n\ntype PartyRequest struct {\n\tName string `json:\"name\"`\n\tId   string `json:\"id\"`\n}\n\ntype PartiesRequest struct {\n\tApplication PartyRequest `json:\"application\"`\n\tProcess     PartyRequest `json:\"process\"`\n}\n\ntype AssetRequest struct {\n\tBeginDate string         `json:\"beginDate\"`\n\tDueDate   string         `json:\"dueDate\"`\n\tParties   PartiesRequest `json:\"parties\"`\n}\n\nfunc (s *SmartContract) isParty(id string, asset *Asset) (bool, error) {\n\tvalue := id == asset.Parties.Process.Id || id == asset.Parties.Application.Id\n\n\tif !value {\n\t\treturn value, fmt.Errorf(\"only the process or the application can execute this operation\")\n\t}\n\n\treturn value, nil\n}\n\nfunc (s *SmartContract) isSigned(party Party) (bool, error) {\n\tif party.IsSigned {\n\t\treturn party.IsSigned, fmt.Errorf(\"the asset is already signed\")\n\t}\n\n\treturn party.IsSigned, nil\n}\n\nfunc (s *SmartContract) assetIsSigned(asset *Asset) error {\n\tif asset.IsSigned {\n\t\treturn nil\n\t}\n\n\treturn fmt.Errorf(\"asset is not signed\")\n}\n\nfunc (s *SmartContract) isBetweenBeginDateAndDueDate(asset *Asset) error {\n\tif asset.DueDate.Before(time.Now()) {\n\t\treturn fmt.Errorf(\"asset expired. The current date is after the due date\")\n\t}\n\n\tif asset.BeginDate.After(time.Now()) {\n\t\treturn fmt.Errorf(\"the current date is before the start date\")\n\t}\n\n\treturn nil\n}\n\nfunc (s *SmartContract) isApplicationIdValid(id string) error {\n\tif id == \"\" {\n\t\treturn fmt.Errorf(\"application id is required\")\n\t}\n\n\treturn nil\n}\n\nfunc (s *SmartContract) isProcessIdValid(id string) error {\n\tif id == \"\" {\n\t\treturn fmt.Errorf(\"process id is required\")\n\t}\n\n\treturn nil\n}\n\nfunc (s *SmartContract) isBeginDateValid(beginDate time.Time) error {\n\tif beginDate.IsZero() {\n\t\treturn fmt.Errorf(\"begin date is required\")\n\t}\n\n\treturn nil\n}\n\nfunc (s *SmartContract) isDueDateValid(dueDate time.Time) error {\n\tif dueDate.IsZero() {\n\t\treturn fmt.Errorf(\"due date is required\")\n\t}\n\n\treturn nil\n}\n\nfunc (s *SmartContract) isDueDateGreaterThanBeginDate(beginDate time.Time, dueDate time.Time) error {\n\tif beginDate.After(dueDate) {\n\t\treturn fmt.Errorf(\"begin date greater than due date\")\n\t}\n\n\treturn nil\n}\n\nfunc (s *SmartContract) string2Time(date string) (time.Time, error) {\n\tparsed, err := time.Parse(time.RFC3339, date)\n\n\tif err != nil {\n\t\treturn time.Time{}, fmt.Errorf(\"invalid date. Expected format 2006-01-02T15:04:05Z07:00. Recieved: %s\", err.Error())\n\t}\n\n\treturn parsed, nil\n}\n\nfunc (s *SmartContract) putState(ctx contractapi.TransactionContextInterface, assetId string, asset *Asset) error {\n\tcontractAsBytes, err := json.Marshal(asset)\n\n\tif err != nil {\n\t\treturn fmt.Errorf(\"marshal error: %s\", err.Error())\n\t}\n\n\tctx.GetStub().PutState(assetId, contractAsBytes)\n\n\treturn nil\n}\n\nfunc (s *SmartContract) Init(ctx contractapi.TransactionContextInterface, assetRequest AssetRequest) (string, error) {\n\tvar beginDate time.Time\n\tvar dueDate time.Time\n\tvar err error\n\n\tif beginDate, err = s.string2Time(assetRequest.BeginDate); err != nil {\n\t\treturn \"\", err\n\t}\n\n\tif dueDate, err = s.string2Time(assetRequest.DueDate); err != nil {\n\t\treturn \"\", err\n\t}\n\n  if err := s.isBeginDateValid(beginDate); err != nil {\n\t\treturn \"\", err\n\t}\n\n\tif err := s.isDueDateValid(dueDate); err != nil {\n\t\treturn \"\", err\n\t}\n\n\tif err := s.isDueDateGreaterThanBeginDate(beginDate, dueDate); err != nil {\n\t\treturn \"\", err\n\t}\n\n\tif err := s.isApplicationIdValid(assetRequest.Parties.Process.Id); err != nil {\n\t\treturn \"\", err\n\t}\n\n\tif err := s.isProcessIdValid(assetRequest.Parties.Process.Id); err != nil {\n\t\treturn \"\", err\n\t}\n\n\tasset := Asset{}\n\tparties := Parties{}\n\n\tasset.BeginDate = beginDate\n\tasset.DueDate = dueDate\n\n\tparties.Application.Id = assetRequest.Parties.Application.Id\n\tparties.Application.Name = assetRequest.Parties.Application.Name\n\tparties.Application.IsSigned = false\n\n\tparties.Process.Id = assetRequest.Parties.Process.Id\n\tparties.Process.Name = assetRequest.Parties.Process.Name\n\tparties.Process.IsSigned = false\n\n\tasset.Parties = parties\n\tasset.CreatedAt = time.Now()\n  asset.Requests = make(map[string]Request)\n\n  <% clauses.forEach(clause => { %>\n    <% clause.terms.forEach(term => { %>\n      <% if (term.type === 'maxNumberOfOperation') { %>\n        asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Used = 0\n      <% } %>\n    <% }) %>\n  <% }) %>\n\n\tassetId := uuid.New().String()\n\n\ts.putState(ctx, assetId, &asset)\n\n\treturn assetId, nil\n}\n\nfunc (s *SmartContract) Sign(ctx contractapi.TransactionContextInterface, assetId string) error {\n\n\tvar id string\n\tvar err error\n\tvar asset *Asset\n\n\tif id, err = s.QueryClientId(ctx); err != nil {\n\t\treturn err\n\t}\n\n\tif asset, err = s.QueryAsset(ctx, assetId); err != nil {\n\t\treturn err\n\t}\n\n\tif _, err := s.isParty(id, asset); err != nil {\n\t\treturn err\n\t}\n\n\tif err := s.isBetweenBeginDateAndDueDate(asset); err != nil {\n\t\treturn err\n\t}\n\n\tif asset.Parties.Application.Id == id {\n\n\t\tif _, err := s.isSigned(asset.Parties.Application); err != nil {\n\t\t\treturn err\n\t\t}\n\n\t\tasset.Parties.Application.IsSigned = true\n\t\tasset.Parties.Application.SignatureDate = time.Now()\n\t}\n\n\tif asset.Parties.Process.Id == id {\n\n\t\tif _, err := s.isSigned(asset.Parties.Process); err != nil {\n\t\t\treturn err\n\t\t}\n\n\t\tasset.Parties.Process.IsSigned = true\n\t\tasset.Parties.Process.SignatureDate = time.Now()\n\t}\n\n\tasset.IsSigned = asset.Parties.Application.IsSigned && asset.Parties.Process.IsSigned\n\n\ts.putState(ctx, assetId, asset)\n\n\treturn nil\n}\n\nfunc (s *SmartContract) QueryAsset(ctx contractapi.TransactionContextInterface, assetId string) (*Asset, error) {\n\n\tcontractAsBytes, err := ctx.GetStub().GetState(assetId)\n\n\tif err != nil {\n\t\treturn nil, fmt.Errorf(\"failed to read from state: %s\", err.Error())\n\t}\n\n\tif contractAsBytes == nil {\n\t\treturn nil, fmt.Errorf(\"asset %s does not exist\", assetId)\n\t}\n\n\tasset := new(Asset)\n\n\terr = json.Unmarshal(contractAsBytes, asset)\n\n\tif err != nil {\n\t\treturn nil, fmt.Errorf(\"marshal error: %s\", err.Error())\n\t}\n\n\treturn asset, nil\n}\n\nfunc (s *SmartContract) QueryClientId(ctx contractapi.TransactionContextInterface) (string, error) {\n\tclientIdentity := ctx.GetClientIdentity()\n\n\tif clientIdentity == nil {\n\t\treturn \"\", fmt.Errorf(\"failed to get client identity\")\n\t}\n\n\tclientID, err := clientIdentity.GetID()\n\n\tif err != nil {\n\t\treturn \"\", fmt.Errorf(\"failed to get client ID: %v\", err)\n\t}\n\n\treturn clientID, nil\n}\n\n<% clauses.forEach(clause => { %>\n  func (s *SmartContract) Clause<%= clause.name.pascal %> ( ctx contractapi.TransactionContextInterface, assetId string <%= clause.variables?.length ? `, args ${clause.name.pascal}Args` : '' %> <%= clause.terms.some(term => term.type === 'timeout') ? ', requestId string' : '' %>) (string, bool, error) {\n\n    var err error\n    var asset *Asset\n\n    executionId := uuid.New().String()\n\n    if asset, err = s.QueryAsset(ctx, assetId); err != nil {\n      return executionId, false, err\n    }\n\n    if err = s.isBetweenBeginDateAndDueDate(asset); err != nil {\n      return executionId, false, err\n    }\n\n    if err = s.assetIsSigned(asset); err != nil {\n      return executionId, false, err\n    }\n\n    <% if (clause.operation === 'request') { %>\n      createdAt := time.Now()\n\n      var clientId string\n\n      if clientId, err = s.QueryClientId(ctx); err != nil {\n        return executionId, false, err\n      }\n\n      asset.Requests[executionId] = Request{\n        clientId: clientId,\n        createdAt: createdAt,\n      }\n\n      s.putState(ctx, assetId, asset)\n    <% } %>\n\n    <% if (clause.terms.some(term => term.type === 'timeout')) { %>\n      request, exists := asset.Requests[requestId]\n\t\n      if !exists {\n        return \"\", false, fmt.Errorf(\"no request found for %s\", requestId)\n      }\n\n      accessDateTime := request.createdAt\n    <% } %>\n\n    isValid := true;\n\n    <% clause.terms.forEach((term, index) => { %>\n      <% if (term.type === 'weekdayInterval') { %>\n        isWeekDayIntervalAfterOrEqualStart := asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Start.After(weekDay) || asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Start.Equal(weekDay)\n        isWeekDayIntervalBeforeOrEqualEnd := asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End.Before(weekDay) || asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End.Equal(weekDay)\n        isValid = isValid && isWeekDayIntervalAfterOrEqualStart && isWeekDayIntervalBeforeOrEqualEnd\n      <% } %>\n\n      <% if (term.type === 'timeInterval') { %>\n        isTimeIntervalAfterOrEqualStart := asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Start.After(accessTime) || asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Start.Equal(accessTime)\n        isTimeIntervalBeforeOrEqualEnd := asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End.Before(accessTime) || asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End.Equal(accessTime)\n        isValid = isValid && isTimeIntervalAfterOrEqualStart && isTimeIntervalBeforeOrEqualEnd\n      <% } %>\n\n      <% if (term.type === 'timeout') { %>\n        isValid = isValid && (accessDateTime.Before(asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End) || accessDateTime.Equal(asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End))\n      <% } %>\n\n\t    <% if (term.type === 'messageContent' && term.variables.length == 1) { %>\n        isValid = isValid && args.<%= term.variables[0].name.pascal %>\n      <% } %>\n\n\t\t  <% if (term.type === 'messageContent' && term.variables.length == 2) { %>\n        isValid = isValid && <%- term.variables[0]?.name ? 'args.' + term.variables[0]?.name?.pascal : term.variables[0]  %> <%- term.comparator %> <%- term.variables[1]?.name?.pascal ? 'args.' + term.variables[1]?.name?.pascal : term.variables[1] %>\n      <% } %>\n\n      <% if (term.type === 'maxNumberOfOperation') { %>\n        maxNumberOfOperationIsInitialized<%= index %> := asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Start.IsZero() && asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End.IsZero()\n\n        endPeriodIsLassThanAccessDateTime<%= index %> := asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End.Before(accessDateTime);\n\n        if (!maxNumberOfOperationIsInitialized<%= index %> || endPeriodIsLassThanAccessDateTime<%= index %>) {\n          asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Start  = accessDateTime\n          asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.End    = accessDateTime.Add(time.Duration(timeInSeconds[asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.TimeUnit]) * time.Second)\n          asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Used   = 0\n        }\n\n        isValid = isValid && asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Used <= asset.<%= clause.name.pascal %>.<%= term.name.pascal %>.Max\n\n      <% } %>\n\n    <% }) %>\n\n    if !isValid { <% if (clause.messages?.error) { %>\n      return executionId, isValid, fmt.Errorf(<%- clause.messages.error %>) <% } else { %>\n      return executionId, isValid, fmt.Errorf(\"error executing clause: <%- clause.name.pascal %>\")<% } %>\n    }\n\n    return executionId, isValid, nil;\n  }\n  <% }) %>\n\nfunc main() {\n  chainconde, err := contractapi.NewChaincode(new(SmartContract))\n\n  if err != nil {\n    log.Panicf(\"error create chaincode: %s\", err.Error())\n    return\n  }\n\n  if err := chainconde.Start(); err != nil {\n    log.Panicf(\"error create chaincode: %s\", err.Error())\n  }\n}\n\n";

declare class ValidationError extends Error {
    range?: {
        start: {
            line: number;
            character: number;
        };
        end: {
            line?: number;
            character?: number;
        };
    };
    constructor(message: string, ctx: ParserRuleContext);
}
declare class JabutiGrammarListenerImpl implements JabutiGrammarListener {
    enterDate(ctx: DatetimeContext): void;
    enterApplication(ctx: ApplicationContext): void;
    enterProcess(ctx: ProcessContext): void;
    enterOperation(ctx: OperationContext): void;
    exitTerms(ctx: TermsContext): void;
    enterRolePlayer(ctx: RolePlayerContext): void;
    enterTimeout(ctx: TimeoutContext): void;
    enterBeginDate(ctx: BeginDateContext): void;
    enterDueDate(ctx: DueDateContext): void;
    exitMessageContent(ctx: MessageContentContext): void;
    enterClause(ctx: ClauseContext): void;
    enterEveryRule(): void;
    exitEveryRule(): void;
    visitErrorNode(): void;
    visitTerminal(): void;
}

export { CanonicalParser, type Clause, type Contract, ETHEREUM_SOLIDITY_TEMPLATE, EthereumSolidityFactory, EthereumSolidityGenerator, type Factory, type Formatter, type Generator, GrammarParser, HYPERLEDGER_FABRIC_GOLANG_TEMPLATE, HyperledgerFabricGolangFactory, HyperledgerFabricGolangFormatter, HyperledgerFabricGolangGenerator, JabutiGrammarListenerImpl, type Message, type Term, ValidationError, type Variable };
